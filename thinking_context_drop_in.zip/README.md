# thinking_context

Drop this folder into any FastAPI project. Your AI agents will remember
conversations, watch rooms, and speak unprompted when the conversation needs them.

Rear View Foresight LLC — Feic Mo Chroí

---

## What it does

- **Jeremy Cricket** watches your rooms. When a conversation goes quiet or loses
  energy, he calculates a stage direction and whispers it to your AI agent.
  The agent speaks unprompted. Nobody sees the whisper.

- **Universal Memory** gives each character a persistent memory bank. Memories
  survive restarts via JSON snapshot (or SQLite for production scale).

- **Session notice** — on startup, your app knows whether memory was restored
  or it's a fresh session.

---

## Folder structure

    thinking_context/
        __init__.py          ← clean public API — import from here
        protocols.py         ← the two-method interface your adapter implements
        mount.py             ← FastAPI integration — the entry point
        memory.py            ← UniversalMemorySystem, CharacterProfile, MemoryEntry
        jeremy.py            ← JeremyCricket — the watcher/whisper engine
        nudge_queue.py       ← optional event-queue decoupling (Approach B)
        sqlite_backend.py    ← optional SQLite persistence (production scale)
        circuit_breaker.py   ← fault-tolerance utility

---

## Integration — 3 steps

### Step 1 — Drop the folder in

Copy `thinking_context/` into your project root (next to `main.py`).

### Step 2 — Write your adapter

One class, two methods:

    class MyAdapter:

        async def get_recent_history(self, room: str, limit: int = 12):
            # Return recent messages as list of {"user_id", "text", "ts"} dicts
            return await your_hub.recent_messages(room, limit)

        async def nudge(self, room_id: str, hint: str) -> bool:
            # Inject hint and trigger your AI agent
            return await your_bots.inject_and_trigger(room_id, hint)

That's the entire contract. See `protocols.py` for the full spec.

### Step 3 — Mount

In your `main.py`:

    from fastapi import FastAPI
    from thinking_context import mount, CharacterProfile

    app = FastAPI()

    mount(
        app,
        MyAdapter(),
        characters = [
            CharacterProfile(character_id="bot-alice", name="Alice", role="host"),
            CharacterProfile(character_id="bot-bob",   name="Bob",   role="commentator"),
        ],
    )

Done. Jeremy starts on app startup, saves memory on shutdown.

---

## Feed messages to Jeremy

In your WebSocket handler or broadcast path, add one line after you send to clients:

    asyncio.create_task(tc.on_message(room_id, user_id, text))

Get `tc` from:

    tc = app.state.thinking_context

Or via FastAPI dependency injection:

    from thinking_context import get_thinking_context

    @app.post("/rooms/{room_id}")
    async def open_room(room_id: str, tc = Depends(get_thinking_context)):
        await tc.watch_room(room_id)

---

## Room lifecycle

    tc = app.state.thinking_context

    await tc.watch_room("lobby")     # Jeremy starts watching
    await tc.release_room("lobby")   # Jeremy stops watching

Call `watch_room` when a room opens, `release_room` when it closes.
Or pass `startup_rooms=["lobby"]` to `mount()` for rooms that always exist.

---

## mount() options

| Parameter | Default | Description |
|---|---|---|
| `characters` | `[]` | `CharacterProfile` list to register |
| `snapshot_path` | `"data/memory_snapshot.json"` | Memory save/load location |
| `poll_interval` | `5.0` | Seconds between Jeremy's room checks |
| `silence_threshold` | `45.0` | Seconds quiet before nudge is considered |
| `min_nudge_interval` | `90.0` | Minimum seconds between nudges per room |
| `drama_threshold` | `0.65` | Energy drop level (0–1) that triggers nudge |
| `include_router` | `True` | Mount `GET /thinking-context/status` |
| `startup_rooms` | `[]` | Rooms to watch immediately on startup |

---

## Status endpoint

If `include_router=True` (default), a status endpoint is available:

    GET /thinking-context/status

Returns uptime, active rooms, nudge counts, and memory stats.

---

## Memory persistence

**Default (JSON snapshot):** Memory saves to `data/memory_snapshot.json` on shutdown
and restores on startup. Works for most use cases.

**Production (SQLite):** Replace `UniversalMemorySystem` with `SQLiteMemorySystem`:

    from thinking_context import SQLiteMemorySystem, mount

    # Pass a custom memory system to mount via the adapter or build Jeremy manually
    # See sqlite_backend.py for full details

---

## Nudge delivery — how it reaches your agent

Jeremy calls `adapter.nudge(room_id, hint)`. Your adapter receives the hint
and must inject it into your agent's context and trigger a response.

The hint is a stage direction. Example:

    "The conversation has been quiet for 52 seconds. Alice knows about the
     topic of AI memory systems from a prior session. She might naturally
     pick up the thread about vector search she mentioned last time."

Your agent never sees "this is a Jeremy hint" — it just finds itself with
richer context and speaks in its own voice.

---

## Example

See `example_integration.py` for a complete working example.

---

## What's not included

- Your LLM adapter (bring your own — pass it via `adapter_registry` to `create_jeremy_cricket` directly for reflection features)
- Your WebSocket/room management (Jeremy watches; your app manages rooms)
- Vector search (Phase 3 — Ollama Qwen integration, flagged in `memory.py`)
