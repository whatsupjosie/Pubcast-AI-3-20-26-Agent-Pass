"""
universal_memory_system.py
═══════════════════════════════════════════════════
Universal Memory System — shared memory layer for AI conversation agents.
Provides CharacterMemoryBank, MemoryEntry, UniversalMemorySystem, CharacterProfile.
Full RAG/vector implementation is Phase 3 (Ollama Qwen integration).

Rear View Foresight LLC — Feic Mo Chroí
"""
from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


class MemoryType(str, Enum):
    EPISODIC    = "episodic"
    SEMANTIC    = "semantic"
    PROCEDURAL  = "procedural"
    EMOTIONAL   = "emotional"
    RELATIONAL  = "relational"


@dataclass
class MemoryEntry:
    content:      str
    memory_type:  MemoryType  = MemoryType.EPISODIC
    importance:   float        = 0.5
    timestamp:    float        = field(default_factory=time.time)
    memory_id:    str          = field(default_factory=lambda: uuid.uuid4().hex[:12])
    tags:         List[str]    = field(default_factory=list)
    source:       str          = "conversation"
    related_to:   Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "memory_id":   self.memory_id,
            "content":     self.content,
            "type":        self.memory_type.value,
            "importance":  self.importance,
            "timestamp":   self.timestamp,
            "tags":        self.tags,
        }


@dataclass
class CharacterProfile:
    character_id:  str
    name:          str
    role:          str            = "assistant"
    personality:   Dict[str, Any] = field(default_factory=dict)
    backstory:     str            = ""
    created_at:    float          = field(default_factory=time.time)


class CharacterMemoryBank:
    """Per-character in-memory store with recency + importance retrieval."""

    def __init__(self, character_id: str, max_entries: int = 500) -> None:
        self.character_id = character_id
        self.max_entries  = max_entries
        self._memories: List[MemoryEntry] = []

    def add(self, entry: MemoryEntry) -> None:
        self._memories.append(entry)
        if len(self._memories) > self.max_entries:
            self._memories.sort(key=lambda m: (m.importance, m.timestamp), reverse=True)
            self._memories = self._memories[:self.max_entries]

    def search(self, query: str, *, limit: int = 10,
               memory_type: Optional[MemoryType] = None) -> List[MemoryEntry]:
        results = self._memories
        if memory_type:
            results = [m for m in results if m.memory_type == memory_type]
        query_lower = query.lower()
        scored = [
            (sum(1 for w in query_lower.split() if w in m.content.lower()), m)
            for m in results
        ]
        scored.sort(key=lambda t: (t[0], t[1].importance, t[1].timestamp), reverse=True)
        return [m for _, m in scored[:limit]]

    def recent(self, limit: int = 20) -> List[MemoryEntry]:
        return sorted(self._memories, key=lambda m: m.timestamp, reverse=True)[:limit]

    def clear(self) -> None:
        self._memories.clear()


class UniversalMemorySystem:
    """Multi-character memory system with cross-character event awareness."""

    def __init__(self) -> None:
        self._banks:    Dict[str, CharacterMemoryBank] = {}
        self._profiles: Dict[str, CharacterProfile]   = {}
        self._global:   List[MemoryEntry]              = []

    def get_or_create_bank(self, character_id: str) -> CharacterMemoryBank:
        if character_id not in self._banks:
            self._banks[character_id] = CharacterMemoryBank(character_id)
        return self._banks[character_id]

    def register_character(self, profile: CharacterProfile) -> None:
        self._profiles[profile.character_id] = profile
        self.get_or_create_bank(profile.character_id)

    def add_global_event(self, entry: MemoryEntry) -> None:
        self._global.append(entry)
        if len(self._global) > 1000:
            self._global = sorted(
                self._global, key=lambda m: (m.importance, m.timestamp), reverse=True
            )[:800]

    def broadcast_to_all(self, entry: MemoryEntry) -> None:
        self.add_global_event(entry)
        for bank in self._banks.values():
            bank.add(entry)

    def global_context(self, limit: int = 30) -> List[MemoryEntry]:
        return sorted(self._global, key=lambda m: m.timestamp, reverse=True)[:limit]
