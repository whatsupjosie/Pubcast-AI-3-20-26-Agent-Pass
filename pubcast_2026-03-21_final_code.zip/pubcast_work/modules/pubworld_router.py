"""
modules/pubworld_router.py — FastAPI router for PubWorld map clients.

Mounts WebSocket endpoint at /ws/pubworld that receives real-time
production state updates and distributes them to connected map viewers.

Exports:
    router                          — APIRouter to include in main app
    push_production_state_to_pubworld(state: dict) — broadcast to all connected clients
"""
from __future__ import annotations

"""
modules/pubworld_router.py
-------------------------

PubWorld router for the 2.5D map surface. This module handles both real-time
connections via WebSocket and HTTP fallbacks for clients that cannot hold a
WebSocket. It also exposes a lightweight broadcast helper used by other
services (e.g. the studio control module) to push the current production state
to connected world clients.

Key features implemented here:

* Client registration and per-client presence/state tracking
* Room change handling with acknowledgements and player-moved broadcasts
* Hotspot action handling with placeholder results
* REST API fallbacks for room change and hotspot actions
* Production-state broadcast integration via push_production_state_to_pubworld()

Note: This implementation uses in-process data structures protected by an
asyncio lock. A future version could move this state into Redis or another
shared store to support multi-worker deployments.
"""

import asyncio
import logging
import json
from pathlib import Path
from typing import Any, Dict, Optional, Set

from fastapi import APIRouter, Request, WebSocket, WebSocketDisconnect
from starlette.websockets import WebSocketState

logger = logging.getLogger(__name__)

# Prefix / tags applied when mounting this router in the main application
router = APIRouter(prefix="/pubworld", tags=["pubworld"])

# ---------------------------------------------------------------------------
# Connection registries
# ---------------------------------------------------------------------------
# Clients connected over WebSocket to receive production state updates
_connected: Set[WebSocket] = set()
# Map from client_id → WebSocket connection for the world map
_client_sockets: Dict[str, WebSocket] = {}
# Per-client state: room ID and last x position
_client_states: Dict[str, Dict[str, Any]] = {}

# Protects access to all registries above
_lock = asyncio.Lock()


async def _register_ws(ws: WebSocket) -> None:
    """Add a WebSocket to the production-state broadcast set."""
    async with _lock:
        _connected.add(ws)
    logger.debug("PubWorld client connected for production state. Total: %d", len(_connected))


async def _unregister_ws(ws: WebSocket) -> None:
    """Remove a WebSocket from the production-state broadcast set."""
    async with _lock:
        _connected.discard(ws)
    logger.debug("PubWorld client disconnected from production state. Total: %d", len(_connected))


async def push_production_state_to_pubworld(state: Dict[str, Any]) -> None:
    """
    Broadcast the current production state to all connected PubWorld WebSocket
    clients. Dead connections are pruned automatically. This helper is
    imported by main.py and used when the control room changes production
    state.
    """
    async with _lock:
        clients = list(_connected)
    if not clients:
        return

    payload = {"type": "production_state", "payload": state}
    dead: list[WebSocket] = []
    for ws in clients:
        try:
            if ws.application_state != WebSocketState.CONNECTED:
                dead.append(ws)
                continue
            await ws.send_json(payload)
        except Exception as exc:
            logger.debug("PubWorld broadcast failed to client: %s", exc)
            dead.append(ws)
    if dead:
        async with _lock:
            for ws in dead:
                _connected.discard(ws)


def _initial_state_for(client_id: str) -> Dict[str, Any]:
    """
    Produce a default state record for a newly joined client. The world map
    always starts in the lobby and at x=50. Over time, these defaults could
    be looked up from a persisted profile.
    """
    return {"room": "lobby", "x": 50}


# ---------------------------------------------------------------------------
# WebSocket endpoint for world clients
# ---------------------------------------------------------------------------

@router.websocket("/ws/{client_id}")
async def pubworld_ws_client(websocket: WebSocket, client_id: str) -> None:
    """
    Primary WebSocket endpoint for PubWorld clients. The client_id is a
    unique identifier generated in the frontend. On connect, the server
    registers the connection, sends a welcome message with the current
    production state (if available), and handles incoming events such as
    room_change and hotspot actions. When a client moves rooms, other
    connected clients receive player_moved notifications.
    """
    # Accept the WebSocket connection
    await websocket.accept()
    # Add this WebSocket to the production-state broadcast registry
    await _register_ws(websocket)
    # Register per-client state
    async with _lock:
        # Ensure stale sockets for the same ID are removed
        old_ws = _client_sockets.get(client_id)
        if old_ws is not None and old_ws is not websocket:
            try:
                await old_ws.close()
            except Exception:
                pass
        _client_sockets[client_id] = websocket
        _client_states.setdefault(client_id, _initial_state_for(client_id))
        current_state = dict(_client_states[client_id])
    # Read the current production state from disk. This file is written
    # whenever the control room toggles on_air, camera, lighting, etc. If
    # reading fails (e.g. file missing), default to an empty dict so the
    # frontend still connects gracefully. This avoids sending an empty
    # production state and leaving the client UI out-of-date.
    production_state: Dict[str, Any] = {}
    try:
        prod_path = Path(__file__).resolve().parents[1] / "data" / "global" / "production.json"
        with open(prod_path, "r", encoding="utf-8") as f:
            production_state = json.load(f) or {}
    except Exception:
        production_state = {}
    # Send welcome message with the latest production state
    try:
        await websocket.send_json({"type": "welcome", "payload": {"production_state": production_state}})
    except Exception as exc:
        logger.debug("Failed to send welcome to %s: %s", client_id, exc)
    try:
        while True:
            data = await websocket.receive_json()
            mtype: Optional[str] = data.get("type")
            if not mtype:
                continue
            if mtype == "ping":
                # Respond to keepalive pings
                await websocket.send_json({"type": "pong"})
            elif mtype == "room_change":
                # Client moved rooms — update state and broadcast
                room = data.get("room") or ""
                x = data.get("x") or 0
                async with _lock:
                    _client_states[client_id] = {"room": room, "x": x}
                # Acknowledge to the moving client
                try:
                    await websocket.send_json({"type": "room_ack", "payload": {"room": room}})
                except Exception:
                    pass
                # Broadcast move to other clients
                async with _lock:
                    other_clients = [(cid, ws) for cid, ws in _client_sockets.items() if cid != client_id]
                for cid, ws in other_clients:
                    try:
                        if ws.application_state == WebSocketState.CONNECTED:
                            await ws.send_json({"type": "player_moved", "payload": {"uid": client_id, "room": room, "x": x}})
                    except Exception:
                        # drop errors silently; stale sockets cleaned up elsewhere
                        pass
            elif mtype == "hotspot":
                # Frontend requested a hotspot action; return a placeholder result
                action = data.get("action") or ""
                result: Dict[str, Any] = {}
                # Provide very simple stub handling for known actions. In a future
                # implementation, this would delegate to a handler in another module.
                if action == "typewriter":
                    result = {"draft_id": "draft-" + client_id[:4]}
                elif action == "scripts":
                    result = {"scripts": []}
                elif action == "phone":
                    result = {"session_token": "", "join_url": ""}
                elif action == "camera_remote":
                    result = {"camera_status": "unavailable"}
                else:
                    result = {"status": "unavailable"}
                try:
                    await websocket.send_json({"type": "hotspot_result", "payload": {"action": action, "result": result}})
                except Exception:
                    pass
            else:
                # Unknown message types are ignored
                logger.debug("Unknown PubWorld message type from %s: %s", client_id, mtype)
    except WebSocketDisconnect:
        pass
    except Exception as exc:
        logger.warning("PubWorld WS error for %s: %s", client_id, exc)
    finally:
        # Remove this client from registries. We deliberately do not erase
        # the per-client state record on disconnect so that if a user
        # refreshes or reconnects they retain their last known room and x
        # position. This allows room state to persist across page reloads.
        async with _lock:
            # Only remove the socket mapping if this exact socket is stored
            if _client_sockets.get(client_id) is websocket:
                _client_sockets.pop(client_id, None)
        await _unregister_ws(websocket)


# ---------------------------------------------------------------------------
# HTTP fallback API
# ---------------------------------------------------------------------------

@router.post("/api/room-change")
async def pubworld_room_change(req: Request) -> Dict[str, Any]:
    """
    HTTP fallback for clients that cannot hold a WebSocket. Updates the
    server-side record of a client's current room and broadcasts the move
    to other connected clients. Accepts JSON with client_id, room, and x.
    """
    try:
        body: Dict[str, Any] = await req.json()
    except Exception:
        return {"status": "error", "error": "invalid_json"}
    client_id: Optional[str] = body.get("client_id")
    room: str = body.get("room") or ""
    x: int = body.get("x") or 0
    if not client_id:
        return {"status": "error", "error": "missing_client_id"}
    async with _lock:
        _client_states[client_id] = {"room": room, "x": x}
        # Attempt to broadcast to connected sockets
        sockets = list(_client_sockets.items())
    for cid, ws in sockets:
        if cid != client_id and ws.application_state == WebSocketState.CONNECTED:
            try:
                await ws.send_json({"type": "player_moved", "payload": {"uid": client_id, "room": room, "x": x}})
            except Exception:
                pass
    return {"status": "ok"}


@router.post("/api/hotspot")
async def pubworld_hotspot(req: Request) -> Dict[str, Any]:
    """
    HTTP fallback for hotspot actions. Accepts JSON with client_id, room, action,
    and data. Returns a placeholder result similar to the WebSocket handler.
    """
    try:
        body: Dict[str, Any] = await req.json()
    except Exception:
        return {"status": "error", "error": "invalid_json"}
    action: str = body.get("action") or ""
    # Provide stub responses for known actions
    result: Dict[str, Any] = {}
    if action == "typewriter":
        result = {"draft_id": "draft-rest"}
    elif action == "scripts":
        result = {"scripts": []}
    elif action == "phone":
        result = {"session_token": "", "join_url": ""}
    elif action == "camera_remote":
        result = {"camera_status": "unavailable"}
    else:
        result = {"status": "unavailable"}
    return {"status": "ok", "result": result}


@router.get("/state")
async def pubworld_state(_: Any = None) -> Dict[str, Any]:
    """
    Returns a snapshot of the current world state. This includes the number of
    connected clients and a mapping of client IDs to their current room and
    position. Clients that cannot hold a WebSocket may poll this endpoint.
    """
    async with _lock:
        states = dict(_client_states)
        connected_count = len(_client_sockets)
    return {
        "connected_clients": connected_count,
        "clients": states,
    }


__all__ = ["router", "push_production_state_to_pubworld"]
