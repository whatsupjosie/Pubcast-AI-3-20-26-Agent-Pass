"""modules/projects.py — Autosave/restore for builder sessions."""
from __future__ import annotations
import asyncio, json, logging, time, uuid
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

def _autosave_dir(data_dir: Path, slug: str) -> Path:
    d = Path(data_dir) / "projects" / slug / "autosaves"
    d.mkdir(parents=True, exist_ok=True)
    return d

def list_autosaves(data_dir: Path, slug: str) -> List[Dict[str, Any]]:
    results = []
    for f in sorted(_autosave_dir(data_dir, slug).glob("*.json"), reverse=True)[:20]:
        try:
            data = json.loads(f.read_text(encoding="utf-8"))
            results.append({"path": str(f), "ts": data.get("ts", 0), "id": f.stem})
        except Exception as exc:
            logger.warning("projects: skipping corrupt autosave %s: %s", f.name, exc)
    return results

async def save_autosave_snapshot(data_dir: Path, slug: str, payload: Dict[str, Any]) -> Path:
    d = _autosave_dir(data_dir, slug)
    ts = time.time()
    path = d / f"{int(ts)}_{uuid.uuid4().hex[:8]}.json"
    payload_with_ts = {"ts": ts, **payload}
    path.write_text(json.dumps(payload_with_ts, indent=2), encoding="utf-8")
    # Keep only last 20 autosaves
    files = sorted(d.glob("*.json"))
    for old in files[:-20]: old.unlink(missing_ok=True)
    return path

def latest_autosave_path(data_dir: Path, slug: str) -> Optional[Path]:
    files = sorted(_autosave_dir(data_dir, slug).glob("*.json"), reverse=True)
    return files[0] if files else None

__all__ = ["list_autosaves", "save_autosave_snapshot", "latest_autosave_path"]
