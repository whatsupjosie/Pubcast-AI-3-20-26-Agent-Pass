"""modules/inference.py — LLM/STT/TTS inference manager using Ollama."""
from __future__ import annotations
import asyncio, logging, os, time
from typing import Any, Dict, Optional
import httpx

logger = logging.getLogger("pubcast.inference")
OLLAMA_HOST  = os.getenv("OLLAMA_HOST",  "http://localhost:11434")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "mistral")

class InferenceManager:
    def __init__(self):
        self._worker_alive = False
        self._started_at: Optional[float] = None

    def status(self) -> Dict[str, Any]:
        return {"worker_alive": self._worker_alive, "provider": "ollama",
                "model": OLLAMA_MODEL, "host": OLLAMA_HOST,
                "started_at": self._started_at}

    async def startup(self):
        try:
            async with httpx.AsyncClient(timeout=5) as c:
                r = await c.get(OLLAMA_HOST)
                if r.status_code == 200:
                    self._worker_alive = True
                    self._started_at = time.time()
        except Exception as e:
            logger.warning("Ollama not reachable: %s", e)
            self._worker_alive = False

    async def generate_text(self, prompt: str, temperature: float = 0.7,
                             max_tokens: int = 256) -> Dict[str, Any]:
        async with httpx.AsyncClient(timeout=60) as c:
            r = await c.post(f"{OLLAMA_HOST}/api/generate",
                json={"model": OLLAMA_MODEL, "prompt": prompt, "stream": False,
                      "options": {"temperature": temperature, "num_predict": max_tokens}})
            r.raise_for_status()
            text = r.json().get("response", "")
            return {"text": text, "model": OLLAMA_MODEL, "provider": "ollama"}

    async def synthesize_speech(self, text: str, voice: str = "default") -> Dict[str, Any]:
        return {"status": "tts_not_implemented", "text": text, "voice": voice,
                "note": "Connect a TTS service via OLLAMA_HOST or external API"}

__all__ = ["InferenceManager"]
