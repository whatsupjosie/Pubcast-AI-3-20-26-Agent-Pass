"""
universal_memory_system.py
═══════════════════════════════════════════════════
Universal Memory System — shared memory layer for AI conversation agents.
Provides CharacterMemoryBank, MemoryEntry, UniversalMemorySystem, CharacterProfile.
Full RAG/vector implementation is Phase 3 (Ollama Qwen integration).

Rear View Foresight LLC — Feic Mo Chroí
"""
from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


class MemoryType(str, Enum):
    EPISODIC    = "episodic"
    SEMANTIC    = "semantic"
    PROCEDURAL  = "procedural"
    EMOTIONAL   = "emotional"
    RELATIONAL  = "relational"


@dataclass
class MemoryEntry:
    content:      str
    memory_type:  MemoryType  = MemoryType.EPISODIC
    importance:   float        = 0.5
    timestamp:    float        = field(default_factory=time.time)
    memory_id:    str          = field(default_factory=lambda: uuid.uuid4().hex[:12])
    tags:         List[str]    = field(default_factory=list)
    source:       str          = "conversation"
    related_to:   Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "memory_id":   self.memory_id,
            "content":     self.content,
            "type":        self.memory_type.value,
            "importance":  self.importance,
            "timestamp":   self.timestamp,
            "tags":        self.tags,
        }


@dataclass
class CharacterProfile:
    character_id:  str
    name:          str
    role:          str            = "assistant"
    personality:   Dict[str, Any] = field(default_factory=dict)
    backstory:     str            = ""
    created_at:    float          = field(default_factory=time.time)


class CharacterMemoryBank:
    """Per-character in-memory store with recency + importance retrieval."""

    def __init__(self, character_id: str, max_entries: int = 500) -> None:
        self.character_id = character_id
        self.max_entries  = max_entries
        self._memories: List[MemoryEntry] = []

    def add(self, entry: MemoryEntry) -> None:
        self._memories.append(entry)
        if len(self._memories) > self.max_entries:
            self._memories.sort(key=lambda m: (m.importance, m.timestamp), reverse=True)
            self._memories = self._memories[:self.max_entries]

    def search(self, query: str, *, limit: int = 10,
               memory_type: Optional[MemoryType] = None) -> List[MemoryEntry]:
        results = self._memories
        if memory_type:
            results = [m for m in results if m.memory_type == memory_type]
        query_lower = query.lower()
        scored = [
            (sum(1 for w in query_lower.split() if w in m.content.lower()), m)
            for m in results
        ]
        scored.sort(key=lambda t: (t[0], t[1].importance, t[1].timestamp), reverse=True)
        return [m for _, m in scored[:limit]]

    def recent(self, limit: int = 20) -> List[MemoryEntry]:
        return sorted(self._memories, key=lambda m: m.timestamp, reverse=True)[:limit]

    def clear(self) -> None:
        self._memories.clear()


class UniversalMemorySystem:
    """Multi-character memory system with cross-character event awareness."""

    def __init__(self) -> None:
        self._banks:    Dict[str, CharacterMemoryBank] = {}
        self._profiles: Dict[str, CharacterProfile]   = {}
        self._global:   List[MemoryEntry]              = []

    def get_or_create_bank(self, character_id: str) -> CharacterMemoryBank:
        if character_id not in self._banks:
            self._banks[character_id] = CharacterMemoryBank(character_id)
        return self._banks[character_id]

    def register_character(self, profile: CharacterProfile) -> None:
        self._profiles[profile.character_id] = profile
        self.get_or_create_bank(profile.character_id)

    def add_global_event(self, entry: MemoryEntry) -> None:
        self._global.append(entry)
        if len(self._global) > 1000:
            self._global = sorted(
                self._global, key=lambda m: (m.importance, m.timestamp), reverse=True
            )[:800]

    def broadcast_to_all(self, entry: MemoryEntry) -> None:
        self.add_global_event(entry)
        for bank in self._banks.values():
            bank.add(entry)

    def global_context(self, limit: int = 30) -> List[MemoryEntry]:
        return sorted(self._global, key=lambda m: m.timestamp, reverse=True)[:limit]

    def serialize(self) -> Dict[str, Any]:
        """
        Dump all character memory banks to a JSON-serializable dict.
        Called on app shutdown to persist memory across restarts.
        Never raises — skips any entry that fails to serialize.
        """
        banks_out: Dict[str, Any] = {}
        for char_id, bank in self._banks.items():
            profile = self._profiles.get(char_id)
            profile_dict: Dict[str, Any] = {}
            if profile:
                try:
                    profile_dict = {
                        "character_id": profile.character_id,
                        "name":         profile.name,
                        "role":         profile.role,
                        "personality":  profile.personality,
                        "backstory":    profile.backstory,
                        "created_at":   profile.created_at,
                    }
                except Exception:
                    profile_dict = {"character_id": char_id, "name": char_id}
            memories_out = []
            for entry in bank._memories:
                try:
                    memories_out.append({
                        "id":          entry.memory_id,
                        "content":     entry.content,
                        "memory_type": entry.memory_type.value,
                        "importance":  float(entry.importance),
                        "tags":        list(entry.tags),
                        "source":      entry.source,
                        "timestamp":   float(entry.timestamp),
                    })
                except Exception:
                    pass  # skip malformed entry
            banks_out[char_id] = {
                "profile":  profile_dict,
                "memories": memories_out,
            }
        return {"version": 1, "banks": banks_out}

    def restore(self, data: Dict[str, Any]) -> None:
        """
        Restore banks from a dict produced by serialize().
        Silently skips malformed entries.
        Does not clear existing banks — merges into current state.
        Never raises.
        """
        try:
            banks_data = data.get("banks", {})
            if not isinstance(banks_data, dict):
                return
            for char_id, bank_data in banks_data.items():
                if not isinstance(bank_data, dict):
                    continue
                # Restore profile
                profile_data = bank_data.get("profile", {})
                if profile_data and char_id not in self._profiles:
                    try:
                        self._profiles[char_id] = CharacterProfile(
                            character_id = profile_data.get("character_id", char_id),
                            name         = profile_data.get("name", char_id),
                            role         = profile_data.get("role", "assistant"),
                            personality  = profile_data.get("personality", {}),
                            backstory    = profile_data.get("backstory", ""),
                            created_at   = float(profile_data.get("created_at", 0.0)),
                        )
                    except Exception:
                        pass
                # Restore memories
                bank = self.get_or_create_bank(char_id)
                for mem_data in bank_data.get("memories", []):
                    try:
                        mem_type_str = mem_data.get("memory_type", "episodic")
                        try:
                            mem_type = MemoryType(mem_type_str)
                        except ValueError:
                            mem_type = MemoryType.EPISODIC
                        entry = MemoryEntry(
                            content     = str(mem_data["content"]),
                            memory_type = mem_type,
                            importance  = float(mem_data.get("importance", 0.5)),
                            timestamp   = float(mem_data.get("timestamp", 0.0)),
                            memory_id   = str(mem_data.get("id", "")),
                            tags        = list(mem_data.get("tags", [])),
                            source      = str(mem_data.get("source", "restored")),
                        )
                        bank.add(entry)
                    except Exception:
                        pass  # skip malformed memory entry
        except Exception:
            pass  # never raise from restore

