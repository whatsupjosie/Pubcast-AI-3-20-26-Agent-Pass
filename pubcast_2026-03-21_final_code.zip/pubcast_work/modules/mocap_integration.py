#!/usr/bin/env python3
"""
MOTION CAPTURE INTEGRATION FOR PUBCAST AI v7.0
===============================================
Real-time motion capture data streaming and avatar animation

Supports:
- Live mocap streaming (UDP/WebSocket)
- Multiple rig formats
- Avatar skeleton mapping
- Studio Control integration (mocap-triggered recording)
- Rust engine coordination via Pete Enhanced

Data Format (from frame-example.json):
{
  "ts": 1700000000000,          # Timestamp (ms)
  "rigId": "rig-01",            # Rig identifier
  "joints": {
    "hips": {"x": 0, "y": 0, "z": 0},
    "spine": {"x": 0, "y": 0.2, "z": 0},
    "left_knee": {"x": 0.15, "y": -0.4, "z": 0},
    ...
  }
}

Usage:
    from modules.mocap_integration import MocapStreamManager
    
    mocap = MocapStreamManager(hub, pete_enhanced)
    await mocap.start_stream("udp://localhost:9001")
    
    # Stream will automatically:
    # - Apply joint data to avatars
    # - Trigger Studio Control recording
    # - Send to Rust engine for rendering
"""

from __future__ import annotations

import asyncio
import json
import logging
import time
from pathlib import Path
from typing import Dict, List, Optional, Set, Any, TYPE_CHECKING
from dataclasses import dataclass, field
from enum import Enum
import socket

import numpy as np

if TYPE_CHECKING:
    from modules.hub import Hub
    from modules.avatar_performer import AvatarPerformerManager, JointPose, PrecisionMocapFrame, Quaternion
    from modules.studio_control import StudioControl

logger = logging.getLogger("pubcast.mocap")


# ─────────────────────────────────────────────
# ENUMS AND DATA CLASSES
# ─────────────────────────────────────────────

class MocapStreamStatus(Enum):
    """Motion capture stream status"""
    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    CONNECTED = "connected"
    STREAMING = "streaming"
    ERROR = "error"


class MocapQuality(Enum):
    """Motion capture quality levels"""
    LOW = "low"           # 30 fps, basic joints
    MEDIUM = "medium"     # 60 fps, full skeleton
    HIGH = "high"         # 120 fps, full skeleton + fingers
    ULTRA = "ultra"       # 240 fps, full body + facial


@dataclass
class Joint:
    """3D joint position"""
    x: float
    y: float
    z: float
    
    # Optional rotation (quaternion)
    qx: Optional[float] = None
    qy: Optional[float] = None
    qz: Optional[float] = None
    qw: Optional[float] = None
    
    # Confidence (0.0 - 1.0)
    confidence: float = 1.0
    
    def to_dict(self) -> Dict[str, float]:
        """Convert to dictionary"""
        d = {"x": self.x, "y": self.y, "z": self.z}
        if self.qx is not None:
            d.update({"qx": self.qx, "qy": self.qy, "qz": self.qz, "qw": self.qw})
        if self.confidence < 1.0:
            d["confidence"] = self.confidence
        return d


@dataclass
class MocapFrame:
    """Complete motion capture frame"""
    timestamp: int  # Milliseconds since epoch
    rig_id: str
    joints: Dict[str, Joint]
    
    # Frame metadata
    frame_number: Optional[int] = None
    fps: Optional[float] = None
    quality: MocapQuality = MocapQuality.MEDIUM
    
    # Additional tracking
    hands: Optional[Dict[str, Any]] = None
    face: Optional[Dict[str, Any]] = None
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'MocapFrame':
        """Parse from JSON dict"""
        joints = {}
        for joint_name, joint_data in data.get("joints", {}).items():
            joints[joint_name] = Joint(**joint_data)
        
        return cls(
            timestamp=data.get("ts", int(time.time() * 1000)),
            rig_id=data.get("rigId", "unknown"),
            joints=joints,
            frame_number=data.get("frameNumber"),
            fps=data.get("fps"),
            quality=MocapQuality(data.get("quality", "medium"))
        )
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "ts": self.timestamp,
            "rigId": self.rig_id,
            "joints": {name: joint.to_dict() for name, joint in self.joints.items()},
            "frameNumber": self.frame_number,
            "fps": self.fps,
            "quality": self.quality.value
        }


@dataclass
class MocapStreamMetrics:
    """Mocap stream performance metrics"""
    frames_received: int = 0
    frames_dropped: int = 0
    avg_fps: float = 0.0
    avg_latency_ms: float = 0.0
    last_frame_time: float = 0.0
    
    # Quality
    avg_joint_confidence: float = 1.0
    tracking_quality: MocapQuality = MocapQuality.MEDIUM


# ─────────────────────────────────────────────
# SKELETON MAPPINGS
# ─────────────────────────────────────────────

# Standard skeleton joint names
STANDARD_SKELETON = [
    # Core
    "hips", "spine", "chest", "neck", "head",
    # Left arm
    "left_shoulder", "left_elbow", "left_wrist", "left_hand",
    # Right arm
    "right_shoulder", "right_elbow", "right_wrist", "right_hand",
    # Left leg
    "left_hip", "left_knee", "left_ankle", "left_foot",
    # Right leg
    "right_hip", "right_knee", "right_ankle", "right_foot"
]

# Avatar mapping (maps mocap joints to avatar bones)
AVATAR_SKELETON_MAPPING = {
    # Mocap joint name → Avatar bone name
    "hips": "root",
    "spine": "spine1",
    "chest": "spine2",
    "neck": "neck",
    "head": "head",
    "left_shoulder": "l_shoulder",
    "left_elbow": "l_elbow",
    "left_wrist": "l_wrist",
    "right_shoulder": "r_shoulder",
    "right_elbow": "r_elbow",
    "right_wrist": "r_wrist",
    "left_knee": "l_knee",
    "right_knee": "r_knee",
    # Add more mappings as needed
}


# Maps standard MocapFrame joint names → UE5 PascalCase landmark names
# used by AvatarRetargeter.BONE_LANDMARK_PAIRS.
# Spine_02 has no direct mocap joint; we synthesise it as the midpoint
# between Spine_01 (spine) and Spine_03 (chest) during frame conversion.
MOCAP_TO_UE5_LANDMARKS: Dict[str, str] = {
    "hips":           "Pelvis",
    "spine":          "Spine_01",
    "chest":          "Spine_03",
    "neck":           "Neck_01",
    "head":           "Head",
    "left_shoulder":  "Clavicle_L",
    "left_elbow":     "UpperArm_L",
    "left_wrist":     "LowerArm_L",
    "left_hand":      "Hand_L",
    "right_shoulder": "Clavicle_R",
    "right_elbow":    "UpperArm_R",
    "right_wrist":    "LowerArm_R",
    "right_hand":     "Hand_R",
    "left_hip":       "Thigh_L",
    "left_knee":      "Calf_L",
    "left_ankle":     "Foot_L",
    "right_hip":      "Thigh_R",
    "right_knee":     "Calf_R",
    "right_ankle":    "Foot_R",
}


# ─────────────────────────────────────────────
# MOCAP STREAM RECEIVERS
# ─────────────────────────────────────────────

class UDPMocapReceiver:
    """
    Receives mocap frames via UDP
    
    Perfect for low-latency local streaming from mocap software
    """
    
    def __init__(self, host: str = "127.0.0.1", port: int = 9001):
        self.host = host
        self.port = port
        self.socket: Optional[socket.socket] = None
        self._running = False
    
    async def start(self, frame_callback):
        """Start receiving frames"""
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.socket.bind((self.host, self.port))
        self.socket.setblocking(False)
        
        self._running = True
        logger.info(f"📡 UDP mocap receiver listening on {self.host}:{self.port}")
        
        while self._running:
            try:
                # Non-blocking receive
                data, addr = await asyncio.get_running_loop().sock_recvfrom(self.socket, 65536)
                
                # Parse JSON frame
                frame_data = json.loads(data.decode('utf-8'))
                frame = MocapFrame.from_dict(frame_data)
                
                # Call frame handler
                await frame_callback(frame)
                
            except asyncio.CancelledError:
                break
            except json.JSONDecodeError as e:
                logger.error(f"Invalid mocap frame JSON: {e}")
            except Exception as e:
                logger.error(f"UDP receive error: {e}")
                await asyncio.sleep(0.01)
    
    async def stop(self):
        """Stop receiving"""
        self._running = False
        if self.socket:
            self.socket.close()
        logger.info("📡 UDP mocap receiver stopped")


class WebSocketMocapReceiver:
    """
    Receives mocap frames via WebSocket
    
    Perfect for streaming from web-based mocap systems or remote sources
    """
    
    def __init__(self, url: str):
        self.url = url
        self.websocket = None
        self._running = False
    
    async def start(self, frame_callback):
        """Start receiving frames"""
        import websockets
        
        self._running = True
        logger.info(f"📡 WebSocket mocap receiver connecting to {self.url}")
        
        try:
            async with websockets.connect(self.url) as websocket:
                self.websocket = websocket
                logger.info("📡 WebSocket mocap connected")
                
                while self._running:
                    try:
                        # Receive frame
                        data = await websocket.recv()
                        
                        # Parse JSON
                        frame_data = json.loads(data)
                        frame = MocapFrame.from_dict(frame_data)
                        
                        # Call frame handler
                        await frame_callback(frame)
                        
                    except asyncio.CancelledError:
                        break
                    except json.JSONDecodeError as e:
                        logger.error(f"Invalid mocap frame JSON: {e}")
                    except Exception as e:
                        logger.error(f"WebSocket receive error: {e}")
                        await asyncio.sleep(0.01)
        
        except Exception as e:
            logger.error(f"WebSocket connection error: {e}")
    
    async def stop(self):
        """Stop receiving"""
        self._running = False
        if self.websocket:
            await self.websocket.close()
        logger.info("📡 WebSocket mocap receiver stopped")


# ─────────────────────────────────────────────
# MAIN MOCAP MANAGER
# ─────────────────────────────────────────────

class MocapStreamManager:
    """
    Manages motion capture streaming for PubCast AI
    
    Responsibilities:
    - Receive mocap frames from various sources
    - Apply joint data to avatars
    - Integrate with Studio Control (trigger recording on movement)
    - Send frames to Pete/Rust engine for rendering
    - Track stream quality and performance
    
    Integration Points:
    - Hub: Broadcast frames to WebSocket clients
    - Pete Enhanced: Send to Rust engine for rendering
    - Studio Control: Auto-trigger recording when mocap starts
    - Avatar System: Map joints to avatar skeleton
    """
    
    def __init__(
        self,
        hub: 'Hub',
        pete: Optional[Any] = None,
        config: Optional[Dict[str, Any]] = None,
        performer_mgr: Optional[Any] = None,
        studio_ctrl: Optional[Any] = None,
    ):
        self.hub = hub
        self.pete = pete                  # Legacy; Rust is now reached via performer_mgr
        self.performer_mgr = performer_mgr
        self.studio_ctrl = studio_ctrl
        self.config = config or {}
        
        # Stream state
        self.status = MocapStreamStatus.DISCONNECTED
        self.receiver: Optional[Any] = None
        self.current_rig_id: Optional[str] = None
        
        # Frame buffer
        self._frame_buffer: List[MocapFrame] = []
        self._max_buffer_size = self.config.get("max_buffer_size", 60)  # 1 second at 60fps
        
        # Metrics
        self.metrics = MocapStreamMetrics()
        
        # Avatar mapping
        self._active_avatar_id: Optional[str] = None
        self._skeleton_mapping = AVATAR_SKELETON_MAPPING.copy()
        
        # Recording integration
        self._auto_start_recording = self.config.get("auto_start_recording", True)
        self._recording_started = False
        
        logger.info("🎭 Mocap Stream Manager initialized")
    
    # ─────────────────────────────────────────────
    # STREAM CONTROL
    # ─────────────────────────────────────────────
    
    async def start_stream(self, source_url: str) -> bool:
        """
        Start receiving mocap stream
        
        Supported URLs:
        - udp://localhost:9001
        - ws://localhost:8080/mocap
        - wss://remote-server.com/mocap
        """
        if self.status == MocapStreamStatus.STREAMING:
            logger.warning("Mocap stream already active")
            return False
        
        logger.info(f"🎭 Starting mocap stream: {source_url}")
        self.status = MocapStreamStatus.CONNECTING
        
        try:
            # Parse URL
            if source_url.startswith("udp://"):
                # UDP stream
                parts = source_url.replace("udp://", "").split(":")
                host = parts[0]
                port = int(parts[1]) if len(parts) > 1 else 9001
                
                self.receiver = UDPMocapReceiver(host, port)
                
            elif source_url.startswith("ws://") or source_url.startswith("wss://"):
                # WebSocket stream
                self.receiver = WebSocketMocapReceiver(source_url)
                
            else:
                logger.error(f"Unsupported mocap source URL: {source_url}")
                self.status = MocapStreamStatus.ERROR
                return False
            
            # Start receiver
            self._receive_task = asyncio.create_task(self.receiver.start(self._on_frame_received))
            
            self.status = MocapStreamStatus.STREAMING
            logger.info("🎭 Mocap stream started successfully")
            
            return True
            
        except Exception as e:
            logger.error(f"Failed to start mocap stream: {e}", exc_info=True)
            self.status = MocapStreamStatus.ERROR
            return False
    
    async def stop_stream(self) -> None:
        """Stop mocap stream"""
        if self.receiver:
            await self.receiver.stop()
            self.receiver = None
        
        self.status = MocapStreamStatus.DISCONNECTED
        self._frame_buffer.clear()
        self._recording_started = False
        
        logger.info("🎭 Mocap stream stopped")
    
    # ─────────────────────────────────────────────
    # FRAME PROCESSING
    # ─────────────────────────────────────────────
    
    async def _on_frame_received(self, frame: MocapFrame) -> None:
        """
        Handle received mocap frame
        
        This is called for every frame received from the stream.
        """
        # Update metrics
        self.metrics.frames_received += 1
        current_time = time.time()
        
        if self.metrics.last_frame_time > 0:
            frame_delta = current_time - self.metrics.last_frame_time
            if frame_delta > 0:
                instant_fps = 1.0 / frame_delta
                # Exponential moving average
                self.metrics.avg_fps = (self.metrics.avg_fps * 0.9) + (instant_fps * 0.1)
        
        self.metrics.last_frame_time = current_time
        
        # Calculate latency
        latency_ms = (current_time * 1000) - frame.timestamp
        self.metrics.avg_latency_ms = (self.metrics.avg_latency_ms * 0.9) + (latency_ms * 0.1)
        
        # Update current rig
        self.current_rig_id = frame.rig_id
        
        # Add to buffer
        self._frame_buffer.append(frame)
        if len(self._frame_buffer) > self._max_buffer_size:
            self._frame_buffer.pop(0)
        
        # Auto-start recording on first movement
        if self._auto_start_recording and not self._recording_started:
            await self._trigger_recording_start()
        
        # Apply to avatar
        if self._active_avatar_id:
            await self._apply_frame_to_avatar(frame, self._active_avatar_id)
        
        # Send to Rust engine via Pete
        if self.pete:
            await self._send_frame_to_rust_engine(frame)
        
        # Broadcast to WebSocket clients
        await self._broadcast_frame(frame)
    
    async def _trigger_recording_start(self) -> None:
        """Trigger Studio Control to start recording when first mocap movement is detected."""
        logger.info("🎭 Mocap movement detected — triggering preflight sequence")
        self._recording_started = True

        if self.studio_ctrl is not None:
            try:
                ok = await self.studio_ctrl.run_preflight_sequence()
                if ok:
                    logger.info("🎬 Studio preflight passed — recording armed")
                else:
                    logger.warning("🎬 Studio preflight returned False — check hardware/routing")
            except Exception as exc:
                logger.warning("🎬 Studio preflight raised: %s — continuing anyway", exc)
    
    async def _apply_frame_to_avatar(self, frame: MocapFrame, avatar_id: str) -> None:
        """
        Convert a MocapFrame into a PrecisionMocapFrame and route it to the
        correct AvatarPerformer via performer_mgr.

        Joint name translation:
          Standard snake_case mocap names → UE5 PascalCase landmark names
          (see MOCAP_TO_UE5_LANDMARKS).  Spine_02 is synthesised as the
          midpoint between Spine_01 (spine) and Spine_03 (chest).
        """
        if self.performer_mgr is None:
            return

        # ── late imports (avoid circular at module level) ────────────────────
        from modules.avatar_performer import (
            JointPose, PrecisionMocapFrame as PrecFrame, Quaternion as Quat,
        )

        # ── build UE5-keyed joint_poses dict ─────────────────────────────────
        joint_poses: Dict[str, Any] = {}

        for mocap_name, ue5_name in MOCAP_TO_UE5_LANDMARKS.items():
            joint = frame.joints.get(mocap_name)
            if joint is None:
                continue

            position = np.array([joint.x, joint.y, joint.z], dtype=np.float32)

            if joint.qx is not None:
                rotation = Quat(
                    x=float(joint.qx),
                    y=float(joint.qy),
                    z=float(joint.qz),
                    w=float(joint.qw) if joint.qw is not None else 1.0,
                )
            else:
                rotation = Quat.identity()

            joint_poses[ue5_name] = JointPose(
                position=position,
                rotation=rotation,
                confidence=float(joint.confidence),
            )

        # ── synthesise Spine_02 as midpoint of Spine_01 and Spine_03 ─────────
        sp1 = joint_poses.get("Spine_01")
        sp3 = joint_poses.get("Spine_03")
        if sp1 is not None and sp3 is not None:
            mid_pos = (sp1.position + sp3.position) * 0.5
            conf    = min(sp1.confidence, sp3.confidence)
            joint_poses["Spine_02"] = JointPose(
                position=mid_pos,
                rotation=Quat.identity(),
                confidence=conf,
            )

        if not joint_poses:
            logger.debug("_apply_frame_to_avatar: no mappable joints in frame")
            return

        # ── wrap in PrecisionMocapFrame and route ─────────────────────────────
        precision_frame = PrecFrame(
            avatar_id=avatar_id,
            timestamp=frame.timestamp / 1000.0,    # ms → seconds
            frame_index=frame.frame_number or 0,
            joint_poses=joint_poses,
            blendshapes=frame.face or {},
            global_confidence=float(
                sum(j.confidence for j in joint_poses.values()) / len(joint_poses)
            ),
        )

        await self.performer_mgr.route_frame(precision_frame)

        # Feed coarse character position to Pete so POSITION_CROSS cues can fire
        # during live mocap-driven takes.  Prefer the pelvis/hips landmark if present.
        if self.pete is not None:
            try:
                pelvis = joint_poses.get("Pelvis")
                if pelvis is not None:
                    pos = pelvis.position
                    self.pete.notify_position(
                        avatar_id,
                        (float(pos[0]), float(pos[1]), float(pos[2])),
                    )
            except Exception as exc:
                logger.debug("Pete position notify skipped: %s", exc)

        logger.debug(
            "Routed frame to avatar %s — %d joints mapped", avatar_id, len(joint_poses)
        )
    
    async def _send_frame_to_rust_engine(self, frame: MocapFrame) -> None:
        """
        Rust rendering is now handled entirely by AvatarPerformer via performer_mgr.
        AvatarPerformer.feed_frame() → PerformerStreamer → ws://localhost:8765 (Rust).
        This method is intentionally a no-op; it exists so the call-site in
        _on_frame_received remains readable without a conditional.
        """

    async def _broadcast_frame(self, frame: MocapFrame) -> None:
        """Broadcast frame to all WebSocket clients via hub."""
        if not self.hub:
            return

        message = {
            "type": "mocap_frame",
            "frame": frame.to_dict(),
            "metrics": {
                "fps":        round(self.metrics.avg_fps, 1),
                "latency_ms": round(self.metrics.avg_latency_ms, 1),
            },
        }
        await self.hub.broadcast_system_event(message)

    # ─────────────────────────────────────────────
    # AVATAR CONTROL
    # ─────────────────────────────────────────────

    def set_active_avatar(self, avatar_id: str, preset: str = "MANNY") -> None:
        """
        Set which avatar receives mocap data.
        Also ensures a performer exists for this avatar in performer_mgr so
        the first frame isn't silently dropped with a "no performer" warning.
        """
        self._active_avatar_id = avatar_id
        if self.performer_mgr is not None:
            if self.performer_mgr.get_performer(avatar_id) is None:
                self.performer_mgr.create_performer(avatar_id, preset=preset)
                logger.info("🎭 Created performer for avatar %s (preset=%s)", avatar_id, preset)
        logger.info("🎭 Active mocap avatar: %s", avatar_id)
    
    def update_skeleton_mapping(self, mapping: Dict[str, str]) -> None:
        """Update mocap joint → avatar bone mapping"""
        self._skeleton_mapping.update(mapping)
        logger.info(f"🎭 Skeleton mapping updated: {len(mapping)} joints")
    
    # ─────────────────────────────────────────────
    # STATUS AND METRICS
    # ─────────────────────────────────────────────
    
    def get_status(self) -> Dict[str, Any]:
        """Get complete mocap status"""
        return {
            "status": self.status.value,
            "rig_id": self.current_rig_id,
            "active_avatar": self._active_avatar_id,
            "recording_started": self._recording_started,
            "metrics": {
                "frames_received": self.metrics.frames_received,
                "frames_dropped": self.metrics.frames_dropped,
                "avg_fps": round(self.metrics.avg_fps, 1),
                "avg_latency_ms": round(self.metrics.avg_latency_ms, 1),
                "buffer_size": len(self._frame_buffer)
            }
        }
    
    def get_latest_frame(self) -> Optional[MocapFrame]:
        """Get most recent frame from buffer"""
        return self._frame_buffer[-1] if self._frame_buffer else None
    
    def get_frame_buffer(self, max_frames: int = 60) -> List[MocapFrame]:
        """Get recent frames from buffer"""
        return self._frame_buffer[-max_frames:]
