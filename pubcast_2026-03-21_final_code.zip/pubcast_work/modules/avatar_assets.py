"""modules/avatar_assets.py — GLB avatar asset manifest management."""
from __future__ import annotations
import json, time
from pathlib import Path
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field

class AssetPack(BaseModel):
    pack_id:     str
    name:        str
    description: str = ""
    assets:      List[Dict[str, Any]] = Field(default_factory=list)
    refreshed_at: float = Field(default_factory=time.time)

class AvatarManifest(BaseModel):
    packs:       List[AssetPack] = Field(default_factory=list)
    generated_at: float = Field(default_factory=time.time)

_manifest_cache: Optional[AvatarManifest] = None

def load_manifest(data_dir: Path) -> AvatarManifest:
    global _manifest_cache
    if _manifest_cache: return _manifest_cache
    manifest_path = Path(data_dir) / "avatars" / "manifest.json"
    if manifest_path.exists():
        try:
            _manifest_cache = AvatarManifest(**json.loads(manifest_path.read_text()))
            return _manifest_cache
        except Exception as exc:
            logger.warning("avatar_assets: corrupt manifest at %s, using defaults: %s", manifest_path, exc)
    # Default pack
    _manifest_cache = AvatarManifest(packs=[
        AssetPack(pack_id="default", name="Default Avatars",
                  description="Built-in holographic energy beings",
                  assets=[{"id": p, "name": p.title(), "type": "hologram"}
                          for p in ["MANNY","SHELA","MAN_LARGE","MAN_SMALL","CHILD","BABY","DOG","GHOST"]])
    ])
    return _manifest_cache

def refresh_manifest_cache():
    global _manifest_cache
    _manifest_cache = None

__all__ = ["AssetPack", "AvatarManifest", "load_manifest", "refresh_manifest_cache"]
