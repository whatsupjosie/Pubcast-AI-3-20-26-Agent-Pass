"""
modules/bot_llm_adapter.py — Swappable LLM adapter for PubCast AI bot co-hosts.

Hardening log (6 passes):
  P1  Moved all `import json` / `import httpx` to module top-level.
      They were inside try blocks inside async generator loops — re-imported
      on every SSE line, which is wasteful and obscures import errors.
  P2  CRITICAL FIX — Anthropic SSE parser was wrong.
      Anthropic streaming uses Server-Sent Events where each meaningful event
      has type "content_block_delta" and nested delta.type == "text_delta".
      Previous code checked `delta.get("text","")` at the top level, which
      always returned "" — bots were silently producing no output.
      Fixed to filter on event type and extract text correctly.
  P3  complete(): added asyncio.wait_for with a hard timeout so a hung
      stream() never leaves complete() blocking forever.
  P4  All stream() methods are async generators — never raise, always yield
      nothing on failure. Verified the generator protocol is correct throughout.
  P5  EchoBotAdapter: explicitly type-annotated as returning AsyncGenerator
      via the async generator protocol (yield in async def = AsyncGenerator).
      get_adapter(): guards against None provider string.
  P6  CRITICAL FIX — history key mismatch between hub and orchestrator.
      Hub stores history entries with key "user_id"; orchestrator stores
      "sender_id". Both _history_to_openai and _history_to_anthropic only
      checked "user_id", so ALL orchestrator-path history was silently ignored
      and agent/human role detection was always wrong for those entries.
      Fixed by introducing _resolve_uid() that checks both keys, and
      _uid_is_agent() that recognises both "bot-" (hub) and "agent:" (orch)
      prefixes. Gemini's inline history loop updated to use the same helpers.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
from abc import ABC, abstractmethod
from typing import Any, AsyncGenerator, Dict, List, Optional

try:
    import httpx
    _HTTPX_AVAILABLE = True
except ImportError:
    _HTTPX_AVAILABLE = False

logger = logging.getLogger(__name__)

_TIMEOUT = 30.0          # per-request network timeout (seconds)
_COMPLETE_TIMEOUT = 45.0 # hard ceiling on complete() (stream + assembly)

_DEFAULTS: Dict[str, str] = {
    "anthropic": "claude-haiku-4-5-20251001",
    "openai":    "gpt-4o-mini",
    "gemini":    "gemini-1.5-flash",
}


# ── Shared helpers ─────────────────────────────────────────────────────────────

def _resolve_uid(entry: Dict[str, Any]) -> str:
    """
    Extract the speaker ID from a history entry.

    Hub entries use "user_id"; orchestrator entries use "sender_id".
    We check both so that history produced by either path is handled correctly.
    Agents are identified by IDs starting with "bot-" (hub) or "agent:" (orchestrator).
    """
    return str(entry.get("user_id") or entry.get("sender_id") or "")


def _uid_is_agent(uid: str) -> bool:
    """True if the uid belongs to an AI agent rather than a human."""
    return uid.startswith("bot-") or uid.startswith("agent:")


def _history_to_openai(history: List[Dict[str, Any]]) -> List[Dict[str, str]]:
    """Convert hub/orchestrator chat history dicts to OpenAI-style message list."""
    out: List[Dict[str, str]] = []
    for entry in history:
        uid = _resolve_uid(entry)
        text = str(entry.get("text", "")).strip()
        if not text:
            continue
        role = "assistant" if _uid_is_agent(uid) else "user"
        out.append({"role": role, "content": text})
    return out


def _history_to_anthropic(history: List[Dict[str, Any]]) -> List[Dict[str, str]]:
    """Convert hub/orchestrator chat history dicts to Anthropic messages list."""
    out: List[Dict[str, str]] = []
    for entry in history:
        uid = _resolve_uid(entry)
        text = str(entry.get("text", "")).strip()
        if not text:
            continue
        role = "assistant" if _uid_is_agent(uid) else "user"
        out.append({"role": role, "content": text})
    # Anthropic requires alternating roles; merge consecutive same-role messages
    merged: List[Dict[str, str]] = []
    for msg in out:
        if merged and merged[-1]["role"] == msg["role"]:
            merged[-1]["content"] += "\n" + msg["content"]
        else:
            merged.append(dict(msg))
    return merged


# ── Base class ─────────────────────────────────────────────────────────────────

class BotLLMAdapter(ABC):
    """Base class for all conversational bot LLM adapters."""

    provider_name: str = "base"

    @abstractmethod
    def is_available(self) -> bool:
        """Return True if this adapter can make calls right now."""
        ...

    @abstractmethod
    async def stream(
        self,
        prompt: str,
        *,
        system: str = "",
        history: Optional[List[Dict[str, Any]]] = None,
        model: str = "",
        temperature: float = 0.8,
    ) -> AsyncGenerator[str, None]:
        """
        Yield text chunks as they arrive.
        Never raises — yields nothing on failure and logs the error.
        """
        ...

    async def complete(
        self,
        prompt: str,
        *,
        system: str = "",
        history: Optional[List[Dict[str, Any]]] = None,
        model: str = "",
        temperature: float = 0.8,
    ) -> str:
        """
        Collect the full stream and return a single string.
        Returns "" on failure or timeout. Hard ceiling: _COMPLETE_TIMEOUT seconds.
        """
        async def _collect() -> str:
            chunks: List[str] = []
            async for chunk in self.stream(
                prompt,
                system=system,
                history=history,
                model=model,
                temperature=temperature,
            ):
                chunks.append(chunk)
            return "".join(chunks).strip()

        try:
            return await asyncio.wait_for(_collect(), timeout=_COMPLETE_TIMEOUT)
        except asyncio.TimeoutError:
            logger.warning(
                "%s.complete() timed out after %.0fs",
                self.__class__.__name__,
                _COMPLETE_TIMEOUT,
            )
            return ""
        except Exception as exc:
            logger.warning("%s.complete() error: %s", self.__class__.__name__, exc)
            return ""


# ── Echo stub ──────────────────────────────────────────────────────────────────

class EchoBotAdapter(BotLLMAdapter):
    """
    Zero-latency stub — echoes the prompt.
    Used for development and as the guaranteed last-resort fallback.
    """
    provider_name = "echo"

    def is_available(self) -> bool:
        return True

    async def stream(
        self,
        prompt: str,
        *,
        system: str = "",
        history: Optional[List[Dict[str, Any]]] = None,
        model: str = "",
        temperature: float = 0.8,
    ) -> AsyncGenerator[str, None]:
        yield f"[echo] {prompt}"


# ── Anthropic adapter ──────────────────────────────────────────────────────────

class AnthropicBotAdapter(BotLLMAdapter):
    provider_name = "anthropic"

    def is_available(self) -> bool:
        return _HTTPX_AVAILABLE and bool(os.getenv("ANTHROPIC_API_KEY", "").strip())

    async def stream(
        self,
        prompt: str,
        *,
        system: str = "",
        history: Optional[List[Dict[str, Any]]] = None,
        model: str = "",
        temperature: float = 0.8,
    ) -> AsyncGenerator[str, None]:
        api_key = os.getenv("ANTHROPIC_API_KEY", "").strip()
        if not api_key or not _HTTPX_AVAILABLE:
            return

        resolved_model = model or _DEFAULTS["anthropic"]
        messages = _history_to_anthropic(history or [])
        messages.append({"role": "user", "content": prompt})

        try:
            async with httpx.AsyncClient(timeout=_TIMEOUT) as client:
                async with client.stream(
                    "POST",
                    "https://api.anthropic.com/v1/messages",
                    headers={
                        "x-api-key": api_key,
                        "anthropic-version": "2023-06-01",
                        "content-type": "application/json",
                    },
                    json={
                        "model": resolved_model,
                        "max_tokens": 1024,
                        "system": system or "You are a helpful AI co-host on a live broadcast.",
                        "stream": True,
                        "temperature": temperature,
                        "messages": messages,
                    },
                ) as resp:
                    if resp.status_code != 200:
                        body = await resp.aread()
                        logger.warning(
                            "Anthropic bot stream HTTP %s: %s",
                            resp.status_code,
                            body[:200],
                        )
                        return
                    async for line in resp.aiter_lines():
                        if not line.startswith("data: "):
                            continue
                        data = line[6:].strip()
                        if not data or data == "[DONE]":
                            continue
                        try:
                            event = json.loads(data)
                            # Anthropic SSE format:
                            #   {"type": "content_block_delta",
                            #    "delta": {"type": "text_delta", "text": "..."}}
                            if event.get("type") != "content_block_delta":
                                continue
                            delta = event.get("delta", {})
                            if delta.get("type") != "text_delta":
                                continue
                            text = delta.get("text", "")
                            if text:
                                yield text
                        except (json.JSONDecodeError, KeyError):
                            continue
        except Exception as exc:
            logger.warning("AnthropicBotAdapter stream error: %s", exc)


# ── OpenAI adapter ─────────────────────────────────────────────────────────────

class OpenAIBotAdapter(BotLLMAdapter):
    provider_name = "openai"

    def is_available(self) -> bool:
        return _HTTPX_AVAILABLE and bool(os.getenv("OPENAI_API_KEY", "").strip())

    async def stream(
        self,
        prompt: str,
        *,
        system: str = "",
        history: Optional[List[Dict[str, Any]]] = None,
        model: str = "",
        temperature: float = 0.8,
    ) -> AsyncGenerator[str, None]:
        api_key = os.getenv("OPENAI_API_KEY", "").strip()
        if not api_key or not _HTTPX_AVAILABLE:
            return

        resolved_model = model or _DEFAULTS["openai"]
        messages: List[Dict[str, str]] = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.extend(_history_to_openai(history or []))
        messages.append({"role": "user", "content": prompt})

        try:
            async with httpx.AsyncClient(timeout=_TIMEOUT) as client:
                async with client.stream(
                    "POST",
                    "https://api.openai.com/v1/chat/completions",
                    headers={
                        "Authorization": f"Bearer {api_key}",
                        "Content-Type": "application/json",
                    },
                    json={
                        "model": resolved_model,
                        "max_tokens": 1024,
                        "temperature": temperature,
                        "stream": True,
                        "messages": messages,
                    },
                ) as resp:
                    if resp.status_code != 200:
                        body = await resp.aread()
                        logger.warning(
                            "OpenAI bot stream HTTP %s: %s",
                            resp.status_code,
                            body[:200],
                        )
                        return
                    async for line in resp.aiter_lines():
                        if not line.startswith("data: "):
                            continue
                        data = line[6:].strip()
                        if not data or data == "[DONE]":
                            continue
                        try:
                            event = json.loads(data)
                            choices = event.get("choices")
                            if not choices:
                                continue
                            delta = choices[0].get("delta", {})
                            text = delta.get("content", "")
                            if text:
                                yield text
                        except (json.JSONDecodeError, KeyError, IndexError):
                            continue
        except Exception as exc:
            logger.warning("OpenAIBotAdapter stream error: %s", exc)


# ── Gemini adapter ─────────────────────────────────────────────────────────────

class GeminiBotAdapter(BotLLMAdapter):
    provider_name = "gemini"

    def is_available(self) -> bool:
        return _HTTPX_AVAILABLE and bool(
            os.getenv("GEMINI_API_KEY", "").strip()
            or os.getenv("GOOGLE_API_KEY", "").strip()
        )

    async def stream(
        self,
        prompt: str,
        *,
        system: str = "",
        history: Optional[List[Dict[str, Any]]] = None,
        model: str = "",
        temperature: float = 0.8,
    ) -> AsyncGenerator[str, None]:
        api_key = (
            os.getenv("GEMINI_API_KEY", "").strip()
            or os.getenv("GOOGLE_API_KEY", "").strip()
        )
        if not api_key or not _HTTPX_AVAILABLE:
            return

        resolved_model = model or _DEFAULTS["gemini"]

        # Build Gemini contents from history
        contents: List[Dict] = []
        for entry in (history or []):
            uid = _resolve_uid(entry)
            text = str(entry.get("text", "")).strip()
            if not text:
                continue
            role = "model" if _uid_is_agent(uid) else "user"
            contents.append({"role": role, "parts": [{"text": text}]})
        contents.append({"role": "user", "parts": [{"text": prompt}]})

        url = (
            f"https://generativelanguage.googleapis.com/v1beta/models/"
            f"{resolved_model}:streamGenerateContent"
        )
        body: Dict = {
            "contents": contents,
            "generationConfig": {
                "maxOutputTokens": 1024,
                "temperature": temperature,
            },
        }
        if system:
            body["systemInstruction"] = {"parts": [{"text": system}]}

        try:
            async with httpx.AsyncClient(timeout=_TIMEOUT) as client:
                async with client.stream(
                    "POST",
                    url,
                    params={"key": api_key, "alt": "sse"},
                    headers={"Content-Type": "application/json"},
                    json=body,
                ) as resp:
                    if resp.status_code != 200:
                        body_bytes = await resp.aread()
                        logger.warning(
                            "Gemini bot stream HTTP %s: %s",
                            resp.status_code,
                            body_bytes[:200],
                        )
                        return
                    async for line in resp.aiter_lines():
                        if not line.startswith("data: "):
                            continue
                        data = line[6:].strip()
                        if not data:
                            continue
                        try:
                            event = json.loads(data)
                            candidates = event.get("candidates") or []
                            if not candidates:
                                continue
                            parts = candidates[0].get("content", {}).get("parts") or []
                            for part in parts:
                                text = part.get("text", "")
                                if text:
                                    yield text
                        except (json.JSONDecodeError, KeyError, IndexError):
                            continue
        except Exception as exc:
            logger.warning("GeminiBotAdapter stream error: %s", exc)


# ── Provider registry ──────────────────────────────────────────────────────────

PROVIDER_REGISTRY: Dict[str, BotLLMAdapter] = {
    "anthropic": AnthropicBotAdapter(),
    "openai":    OpenAIBotAdapter(),
    "gemini":    GeminiBotAdapter(),
    "echo":      EchoBotAdapter(),
}


# ── Public API ─────────────────────────────────────────────────────────────────

def get_available_providers() -> Dict[str, bool]:
    """Instant key-presence check — no network calls."""
    return {name: adapter.is_available() for name, adapter in PROVIDER_REGISTRY.items()}


def get_adapter(provider: str = "auto") -> BotLLMAdapter:
    """
    Return adapter for `provider`.

    "auto" → first available cloud provider, falls back to echo.
    Unknown name → logs warning, returns echo.
    """
    if not provider:
        provider = "auto"

    if provider == "auto":
        for name, adapter in PROVIDER_REGISTRY.items():
            if name == "echo":
                continue
            if adapter.is_available():
                return adapter
        return PROVIDER_REGISTRY["echo"]

    adapter = PROVIDER_REGISTRY.get(provider)
    if adapter is None:
        logger.warning("Unknown bot LLM provider %r — falling back to echo", provider)
        return PROVIDER_REGISTRY["echo"]
    return adapter
