"""modules/avatar_motion.py — Avatar motion-capture presets for PubCast."""
from enum import Enum

class AvatarPreset(str, Enum):
    IDLE        = "idle"
    TALKING     = "talking"
    LISTENING   = "listening"
    GESTURING   = "gesturing"
    WALKING     = "walking"
    DANCING     = "dancing"
    PRESENTING  = "presenting"
    REACTING    = "reacting"

__all__ = ["AvatarPreset"]
