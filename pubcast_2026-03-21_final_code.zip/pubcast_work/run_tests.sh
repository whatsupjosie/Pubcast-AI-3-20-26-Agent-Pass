#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════════════════
# PubCast AI — Startup Reliability Test Suite
# ═══════════════════════════════════════════════════════════════════════════════
# Usage:  ./run_tests.sh
#         ./run_tests.sh --fast          (skip slow WS tests)
#         ./run_tests.sh -k test_name    (run specific test)
#         ./run_tests.sh --no-install    (skip dep install, already done)
#
# Exit code 0 = all tests passed. Non-zero = something is broken.
# ═══════════════════════════════════════════════════════════════════════════════

set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

CYAN='\033[0;36m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
RED='\033[0;31m'; BOLD='\033[1m'; NC='\033[0m'

# ── Parse flags ───────────────────────────────────────────────────────────────
SKIP_INSTALL=0
FAST=0
EXTRA_ARGS=()
while [[ $# -gt 0 ]]; do
  case $1 in
    --no-install) SKIP_INSTALL=1; shift ;;
    --fast)       FAST=1; shift ;;
    *)            EXTRA_ARGS+=("$1"); shift ;;
  esac
done

echo -e "${CYAN}"
echo "  ╔══════════════════════════════════════════════════════╗"
echo "  ║       PubCast AI  —  Startup Reliability Tests       ║"
echo "  ║           Rear View Foresight LLC · Feic Mo Chroí    ║"
echo "  ╚══════════════════════════════════════════════════════╝"
echo -e "${NC}"

# ── Dependency check / install ────────────────────────────────────────────────
if [[ $SKIP_INSTALL -eq 0 ]]; then
  echo -e "${YELLOW}▶ Installing test dependencies...${NC}"
  pip install -q -r requirements.txt
  pip install -q -r tests/requirements-test.txt
  echo -e "${GREEN}  ✓ Dependencies ready${NC}"
  echo ""
fi

# ── Build pytest args ─────────────────────────────────────────────────────────
PYTEST_ARGS=(
  "tests/"
  "--tb=short"
  "--no-header"
  "-v"
  "--color=yes"
)

if [[ $FAST -eq 1 ]]; then
  # Skip WebSocket connectivity tests in fast mode (they need full boot)
  PYTEST_ARGS+=("--ignore=tests/test_04_websockets.py")
  echo -e "${YELLOW}  ⚡ Fast mode: skipping WebSocket connectivity tests${NC}"
fi

PYTEST_ARGS+=("${EXTRA_ARGS[@]+"${EXTRA_ARGS[@]}"}")

# ── Run ───────────────────────────────────────────────────────────────────────
echo -e "${CYAN}▶ Running tests...${NC}"
echo ""

set +e
python -m pytest "${PYTEST_ARGS[@]}"
EXIT_CODE=$?
set -e

# ── Result summary ────────────────────────────────────────────────────────────
echo ""
if [[ $EXIT_CODE -eq 0 ]]; then
  echo -e "${GREEN}${BOLD}"
  echo "  ╔══════════════════════════════════════════════╗"
  echo "  ║   ✓  All startup tests passed. Ship it.      ║"
  echo "  ╚══════════════════════════════════════════════╝"
  echo -e "${NC}"
else
  echo -e "${RED}${BOLD}"
  echo "  ╔══════════════════════════════════════════════╗"
  echo "  ║   ✗  Tests FAILED. Do not ship.              ║"
  echo "  ╚══════════════════════════════════════════════╝"
  echo -e "${NC}"
  echo -e "${YELLOW}Run with -v for verbose output, or -k <test_name> to isolate.${NC}"
fi

exit $EXIT_CODE
