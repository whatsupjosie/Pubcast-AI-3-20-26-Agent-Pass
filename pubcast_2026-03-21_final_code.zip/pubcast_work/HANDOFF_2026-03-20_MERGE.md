# PubCast AI — Merge Handoff
## Session: 2026-03-20 | Stable base + Pete + VoxelStudio + Mocap wiring

This package starts from the stable merged build:
- `pubcast_merged_final_2026-03-19_pete_repeat_registry_fixed.zip`

Then integrates the session work that was still orphaned or branch-only:
- `modules/pete.py`
- `modules/voxel_studio.py`
- patched `modules/mocap_integration.py`
- `pubcast_asset_spec_v1_1.html`
- `slate_to_cut.html`
- voxel primitive GLBs

## What is now integrated

### 1. Pete is live in the program
- `modules/pete.py` added
- `main.py` now initializes Pete during lifespan
- Pete routes are registered under `/api/pete/*`
- Auto-cut / auto-action callbacks broadcast to the hub
- Pete surfaces 5-second **tail** and 5-second **handle** discipline in status

### 2. VoxelStudio is live in the program
- `modules/voxel_studio.py` added
- `main.py` now initializes VoxelStudio during lifespan
- VoxelStudio routes are registered under `/api/vs/*`
- Session primitives copied into `data/voxel_studio/primitives/`
- VoxelStudio status and primitive catalogue are live and returning data

### 3. Mocap backend is wired
- `modules/mocap_integration.py` replaced with the patched version
- `main.py` now initializes `MocapStreamManager`
- Mocap routes are registered under `/api/mocap/*`
- Mocap now routes frames through `AvatarPerformerManager`
- Studio preflight trigger is wired
- `set_active_avatar()` creates performer instances if missing

### 4. Position-cross cues now actually have data
One extra cleanup was applied beyond the branch notes:
- mocap frame routing now notifies Pete of the avatar's coarse pelvis position
- this means Pete's `POSITION_CROSS` cue type can fire during live mocap-driven takes

## Session assets included
- `docs/pubcast_asset_spec_v1_1.html`
- `static/art/slate_to_cut.html`
- `data/voxel_studio/primitives/*.glb`

## Validation run

### Python compile
Passed:
- `main.py`
- `modules/pete.py`
- `modules/voxel_studio.py`
- `modules/mocap_integration.py`

### Tests
Passed:
- `tests/test_00_integrity.py`
- `tests/test_02_routing.py`
- `tests/test_03_health.py`

Result: **193 passed**

### Live startup smoke
With app lifespan active, these all returned `200`:
- `/api/mocap/status`
- `/api/vs/status`
- `/api/vs/primitives`
- `/api/pete/status`

## Known remaining gaps
These are still real and not pretended away:

1. **bots.js / bot frontend remains the biggest product gap**
   The backend exists; the user-facing bot management experience still needs work.

2. **Mocap frontend UI is still missing**
   Backend routes exist, but there is no proper control surface yet for:
   - start/stop stream
   - select active avatar
   - view mocap status in the interface

3. **VoxelStudio does not yet have its own visual browser/editor page**
   The backend exists; the production-facing UI still needs to be built.

4. **Voxel asset library still starts empty**
   Existing warning remains:
   `data/voxel_library` has no populated asset library yet.
   This does not block startup.

## Recommended next move
Start from this package as the new stable base.
Then do one focused frontend pass on either:
- mocap controls
- bot management UI
- voxel studio UI

This package is stable enough to be the master branch baseline.


---

## 2026-03-20 Repair Pass

Applied a follow-up repair pass after merge packaging:

- Added a placeholder `data/voxel_library` JSON so startup no longer logs `Asset library not found`.
- Preserved executable permissions on `start_pubcast.sh` and `run_tests.sh` for direct shell use after extraction.
- Re-ran full test suite and startup smoke.

Verification after repair:
- `pytest -q` → 286 passed
- `bash start_pubcast.sh` boots cleanly with Pete, VoxelStudio, and mocap initialised

Still intentionally unfinished:
- bots frontend
- mocap frontend control UI
- voxel studio visual browser/editor
- populated voxel asset library content (placeholder exists so startup is clean)
