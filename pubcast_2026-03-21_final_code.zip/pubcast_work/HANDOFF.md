# PubCast AI — Merged Handoff
## Session: 2026-03-19 | Rear View Foresight LLC

---

## What this package is

A complete merged build combining:
- **GPT Part 1**: Full codebase with 2.5D world map, all rooms, assets, all systems
- **GPT Part 2**: Polish pass — mic system, purfluous, jeremy cricket, room detail assets
- **Claude startup fixes**: Four critical bugs patched, test suite, clean shutdown

This is the definitive current state of PubCast AI.

---

## Critical bugs fixed (Claude 2026-03-18, reapplied to merge)

### BUG-001 — CRITICAL: WebSocket route shadowing
`/ws/unity` and `/ws/studio` were registered **after** the catch-all `/ws/{room}`.
Starlette matches in registration order — Unity Bridge and Studio Control Room
were silently broken. Fixed: specific routes moved before the catch-all.

### BUG-002 — lighting_apply null guard
`hub.broadcast_system_event()` called without checking `if hub is not None`.
Fixed: null guard added, consistent with every other hub call.

### BUG-003 — audio_devices.py OSError
`sounddevice` raises `OSError: PortAudio library not found` when the system
audio library is missing. Was only catching `ImportError`. Fixed: `(ImportError, OSError)`.

### BUG-004 — bridge_bulletproof.py posix_ipc guard
`posix_ipc.ExistentialError` referenced before handling the ImportError.
Fixed: ImportError caught first, returns cleanly.

---

## Bugs found in GPT's work (fixed in this merge)

### world.html patchImagePaths double-slash
`'/pubworld/assets/' + '/assets/rooms/lobby.jpg'` → double slash broken URL.
Fixed: `'/pubworld' + room.bg` (bg already starts with `/assets/`).

### world_script_check.js hallway wrong background
Hallway room used `lobby_polish.jpg` instead of `hallway_polish.jpg`.
Fixed: correct image path restored.

---

## GPT's work quality assessment

**Excellent — production grade:**
- `purfluous.py` — Scene director with sigmoid drama necessity, phase tracking,
  plot point detection. Genuinely beautiful architecture.
- `jeremy_cricket.py` — SQLite persistent memory, keyword + recency + importance
  scoring, async-safe, CricketKeeper factory. No external deps.
- `mic_routes.py` — Clean FastAPI router, profile persistence, cough broadcast.
- `mic_device_picker.js` — Proper browser audio: permission unlock → enumerate
  → store by label (not deviceId) → hot-plug detection.
- `world.html` — Full 2.5D studio game: 8 rooms, sprite, minimap, ambient FX,
  proximity doors, WS backend integration, portal to 3D. On-brand throughout.
- All room connections correct and complete.
- WS URL matches backend route (`/pubworld/ws/{client_id}` ✅).

---

## Additional improvements in this merge

- Dead imports removed: ConversationOrchestrator, Participant, Room, ParticipantRole
- BYOK double-mount guard restored for `--reload` dev cycles
- Shutdown now cleanly stops: purfluous_mgr, cricket_keeper, performer_mgr
- cv2/mediapipe wrapped in try/except with `_VISION_AVAILABLE` flag
- Test suite included (132 tests)

---

## How to run

```bash
pip install -r requirements.txt
pip install -r tests/requirements-test.txt
./run_tests.sh          # All 132 tests should pass
./start_pubcast.sh      # Start the server
```

Then open http://localhost:8000 — you land in the 2.5D Dressing Room.

---

*Feic Mo Chroí™ — Rear View Foresight LLC*
