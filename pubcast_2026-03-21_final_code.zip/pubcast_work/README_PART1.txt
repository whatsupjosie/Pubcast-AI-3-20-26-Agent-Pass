PubCast full polish package - Part 1 (Core Program)

This zip contains the runnable updated program.
If you also want the detailed handoff and changed-files copy set, extract Part 2 into the same parent folder.
