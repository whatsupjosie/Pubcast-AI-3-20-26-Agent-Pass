# PubCast AI — Full Merge Handoff
## Session: 2026-03-21 | Three-source merge + FPR toolchain
## Packaged by: Claude Sonnet 4.6

Base: `pubcast_merged_final_2026-03-20_repaired.zip` (286 tests passing)
Sources merged: pubcast session 2026-03-21 + Everything_We_Worked_On + code_collector_memory_layer
Output: `pubcast_merged_final_2026-03-21.zip`

---

## Test result

```
pytest -q → 286 passed, 41 warnings
```

Zero regressions. Same count as repaired baseline.

---

## What was merged

### 1. Bug fixes (from 2026-03-21 session)

**`modules/models.py`**
- Added `owner_id: str = ""` to `BotConfig`
- It was missing entirely. Every bot API route referenced it.
  Every request to `/api/bots` would have crashed at runtime.

**`modules/bots.py`**
- Fixed `cfg.enabled_rooms` → `cfg.rooms` in 3 places
  (line 118, line 146, line 159)
- Bot routing and nudge were silently broken. Now they work.

**`main.py`**
- Added `POST /api/bots/{bot_id}/nudge` endpoint
- Added None guard to list_bots (returns 503 cleanly before lifespan, not a crash)
- Added page routes: `/bots`, `/mocap`, `/voxels`
- Removed orphaned duplicate lines after mocap_set_avatar

---

### 2. New frontend pages

**`static/bots.js`** — was 0 bytes, now 667 lines
- Full bot management panel. Self-contained, call `BotsPanel.mount(el)`
- Bot card grid, live polling (8s), edit modal, nudge button, delete with confirm
- Provider/model selectors, room chips, behaviour toggles, temperature slider
- Error banners inline — no alert()

**`static/bots.html`** — new page at `/bots`
- Neo-Deco header, nav to all major sections

**`static/mocap.html`** — new page at `/mocap`
- Status strip with animated orb, FPS bar chart canvas (60-bar, live at 1.5s poll)
- 4 metrics tiles, stream control form, active performer panel, event log (200-line rolling)

**`static/voxels.html`** — new page at `/voxels`
- Primitives tab with SVG previews, LOD filter toolbar
- Objects tab with bake/delete actions
- Scene control tab: Slate/Action/Cut with correct state gating

---

### 3. Code Collector memory layer

`code_collector_memory_layer/` added at project root.

| File | Status |
|------|--------|
| `jeremy_cricket.py` | ✅ 798 lines. Room watcher, drama calculator, nudge orchestrator |
| `universal_memory_system.py` | ✅ Works. In-memory only — add serialize/restore for persistence |
| `circuit_breaker.py` | ✅ Production-grade |
| `irm.py` | ⚠️ Stub — throttle() is a no-op |
| `nudge_patch.py` | ⚠️ Wrong object structure — see HANDOFF.md in this folder |
| `HANDOFF.md` | ✅ READ IT FIRST. 4 documented breaks, fixes, architecture options |

**4 known breaks before Jeremy Cricket integrates into PubCast.**
All mechanical. All documented. Read `code_collector_memory_layer/HANDOFF.md`.

---

### 4. FPR toolchain

`tools/fpr/` added at project root.

| File | What it is |
|------|------------|
| `fpr_autogen.py` | Scans project folder, drafts FPR JSON report |
| `fpr_desktop_tool.py` | Tkinter desktop wrapper for the above |
| `functional_purpose_report.schema.json` | Machine-readable validation schema |
| `Run_FPR_Tool.bat` | Windows launcher |
| `test_draft_fpr.json` | Example output |
| `docs/` | Full reconstructed spec docs from GPT session |
| `DETAILED_HANDOFF.md` | Complete context for the FPR toolchain |

The FPR (Functional Purpose Report) standard is a cross-AI handoff protocol —
a structured JSON report that any AI can consume to understand a project's
architecture without re-reading all the source. Designed to integrate with
PubCast's session-boundary handoff system.

---

## What's still NOT done (honest list)

1. **Bone converter** — avatar rig mapping to PubCast's 89-bone naming.
   Called "soon" multiple sessions ago. Still zero progress. Do this next.

2. **Jeremy Cricket integration into main.py** — 4 mechanical fixes needed.
   Read `code_collector_memory_layer/HANDOFF.md`. Approach A first (direct
   references), Approach B later (event queue decoupling).

3. **Bot live busy-state** — status dot is permanently idle.
   Backend needs `is_busy` per bot in the `/api/bots` list response.
   Client-side logic is already in bots.js waiting for it.

4. **UniversalMemorySystem persistence** — in-memory only.
   Server restart wipes all bot character memory.
   Add `serialize()`/`restore()` methods, call on shutdown/startup.
   One afternoon.

5. **Voxel asset library content** — `data/voxel_library` is a placeholder.
   Startup is clean. No authored assets exist.

6. **irm.py** — throttle() is a no-op stub in both PubCast and Code Collector.

---

## Directory structure

```
pubcast_work/
├── main.py                          ← FastAPI app
├── modules/                         ← All backend modules
├── static/                          ← Frontend (HTML/JS/CSS)
│   ├── bots.html                    ← NEW
│   ├── bots.js                      ← NEW (667 lines, was 0)
│   ├── mocap.html                   ← NEW
│   ├── voxels.html                  ← NEW
│   └── ...
├── tests/                           ← 286 passing
├── rust_crate/                      ← Rust animation/rendering layer
├── unity_devkit/                    ← Unity C# bridge scripts
├── data/                            ← Runtime data
├── assets/                          ← Visual concept images
├── docs/                            ← Asset spec HTML
├── code_collector_memory_layer/     ← Jeremy Cricket + memory system
│   ├── HANDOFF.md                   ← READ BEFORE TOUCHING
│   └── ...
└── tools/
    └── fpr/                         ← FPR toolchain
        ├── fpr_autogen.py
        ├── fpr_desktop_tool.py
        ├── functional_purpose_report.schema.json
        └── docs/
```

---

## Critical rules that must never break

- `/ws/unity` and `/ws/studio` routes stay BEFORE `/ws/{room}` in main.py.
  If they move after it, Unity Bridge and Studio Control go silent.
  This was a real bug that was fixed. Do not reintroduce it.
- `world.html` room asset paths — fragile. Don't touch image paths.
- Pete's `notify_position()` call in `mocap_integration.py` — makes
  position-cross cues fire. Don't remove it.
- Dressing room foundry is on the wooden stage in front of the full-length
  mirror. NOT the makeup vanity. Corrected explicitly once already.

---

## Next session recommended order

1. Bone converter — Josie has been waiting
2. Jeremy Cricket integration (4 mechanical fixes, HANDOFF.md has all of them)
3. Bot busy-state (tiny backend change to `/api/bots` list endpoint)
4. Memory persistence for UniversalMemorySystem

---

Feic Mo Chroí™ — Rear View Foresight LLC

---

## Update: Jeremy Cricket (Room Conductor) — integrated this session

### What was done

Added the Room Conductor — Jeremy Cricket's room-watching, drama-calculating,
nudge-firing layer — which was previously unintegrated.

**Note:** The HANDOFF.md in `code_collector_memory_layer/` describes 4 breaks
to fix in `bots.py`. That was written assuming nothing was wired. It was wrong.
`bots.py` and `main.py` were already in a cleaner state than described.
The integration was cleaner than feared.

### New files added

**`modules/universal_memory_system.py`**
- Per-character in-memory store with keyword search and importance scoring
- Used by RoomConductor for building stage directions
- Clean stdlib-only imports, no external deps

**`modules/room_conductor.py`**
- The room-watching drama director (renamed from JeremyCricket to avoid
  collision with the existing per-character SQLite CricketKeeper)
- Watches active rooms on 5s poll, calculates drama necessity via sigmoid,
  composes stage directions from character memory, fires nudge() to BotManager
- `bot_` → `bot-` user_id prefix bug fixed from source
- Import paths fixed to use relative `.universal_memory_system`
- Syntax verified, imports clean

### Files modified

**`modules/hub.py`**
- Added `asyncio` import
- `get_recent_history()` now uses `loop.run_in_executor()` — file I/O
  dispatched to thread pool, event loop never blocked
- Added `_read_history_sync()` helper (runs in thread)

**`main.py`** — 6 changes:
1. Import `RoomConductor`, `create_room_conductor`, `RoomConductorConfig`
2. Import `UniversalMemorySystem`, `CharacterProfile`
3. Added `room_conductor` to global declarations
4. Added `room_conductor` to lifespan global statement
5. Init block after cricket_keeper: constructs `UniversalMemorySystem`,
   calls `create_room_conductor(memory, bot_mgr, hub)`
6. `_chat_callback` now fires `room_conductor.watch_room()` and
   `room_conductor.on_message()` as async tasks on every chat message
7. Shutdown block calls `room_conductor.shutdown()`

### How Jeremy works now

Every chat message triggers two async tasks:
- `room_conductor.watch_room(room_id)` — idempotent, starts the 5s watcher
  loop for this room if not already running
- `room_conductor.on_message(room_id, user_id, text)` — updates scene state,
  records to character memory if speaker is a registered character

The watcher loop runs independently. Every 5 seconds per room it:
1. Reads recent history via `hub.get_recent_history()` (non-blocking)
2. Calculates energy, silence pressure, plot-point age
3. If drama necessity crosses threshold AND nudge cooldown elapsed:
   composes a stage direction and calls `bot_mgr.nudge(room_id, hint)`
4. BotManager picks the least-recently-idle bot, whispers the hint into
   its system prompt, fires a synthetic trigger
5. Bot replies in its own voice. Nobody sees the whisper.

### What's still not done

- **Character registration** — bots need to be registered with the
  UniversalMemorySystem to get personal memory. Currently `_memory_system`
  starts empty. Wire registration when a bot is created via `upsert_config()`.
  One-liner: `_memory_system.register_character(CharacterProfile(character_id=cfg.bot_id, name=cfg.name))`
  This can be done in BotManager.upsert_config() or in lifespan after reload().

- **Memory persistence** — UniversalMemorySystem is in-memory. Server restart
  wipes character memory. Add serialize()/restore() — one afternoon. See
  `code_collector_memory_layer/HANDOFF.md` Option A.

- **LLM adapters for reflection** — `adapter_registry=None` right now.
  Without adapters, reflection features skip gracefully. Wire when needed.

### Tests

286 passed, 41 warnings — same as before. Zero regressions.

---
Feic Mo Chroí™
