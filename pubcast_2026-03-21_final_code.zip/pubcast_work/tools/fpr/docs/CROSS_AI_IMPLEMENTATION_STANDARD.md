# Functional Purpose Report (FPR)
## Cross-AI Implementation Standard

Purpose:
This protocol is SOP for all features, systems, and implementations.

When to run:
- at 60–75% completion
- before declaring completion
- before major updates or architectural changes

Execution requirement:
When instructed to "Run an FPR on [feature/system]" return a fully completed report in the standard format.

Behavioral requirements:
- be direct
- avoid false positives
- ground in reality
- distinguish intended, claimed, and actual behavior
- prioritize outcome over effort

Enforcement rule:
If alignment is not achieved, do not proceed with further development.
