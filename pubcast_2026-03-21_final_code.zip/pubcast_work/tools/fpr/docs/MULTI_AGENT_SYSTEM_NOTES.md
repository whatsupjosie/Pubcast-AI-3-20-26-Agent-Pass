# Multi-Agent System Notes

Agents were reframed as distinct roles, not magical personalities.

Core roles:
- builder
- critic
- archivist
- planner
- producer
- narrator
- integrator

Practical guidance:
- do not let all agents run all the time
- use one generator, one reviewer, one integrator, archivist at the end
- archivist records final state only after integration
