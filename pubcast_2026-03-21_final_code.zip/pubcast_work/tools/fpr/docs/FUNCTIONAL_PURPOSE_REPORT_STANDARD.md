# Functional Purpose Report (FPR)

## FPR Summary
Status: [Aligned / Partial / Misaligned]
Confidence: [High / Medium / Low]
Primary Issue: [one sentence]
Recommended Action: [one sentence]

## Feature / System
[Name]

## Date
[Timestamp]

## 1. Desired Purpose (Why)
What need or problem led to this being created?

## 2. Stated Purpose (What Was Claimed)
How this feature/system was described or intended to behave.

## 3. Functional Purpose (What It Actually Does)
Observed real behavior.

## 4. Evidence
What observable behavior proves this is working?

## 5. Impact
What changed because of this?

## 6. Alignment Status
Desired = Stated = Functional ?

## 7. Confidence Level
High / Medium / Low

## 8. Drift Type
None / Design Drift / Implementation Drift / False Success

## 9. Gaps
What is missing between current reality and intended outcome?

## 10. Failure Cost
If left misaligned, what breaks, degrades, or propagates?

## 11. Signal Role
Primary / Secondary / Fallback / Not a signal

## 12. Cost vs Benefit
Complexity added / Benefit gained / Worth it?

## 13. Required Actions
1.
2.
3.

## 14. Final Decision
Continue / Reinforce / Recalibrate / Combine / Remove

## 15. Final Test
If this feature were removed, what real capability would be lost?
