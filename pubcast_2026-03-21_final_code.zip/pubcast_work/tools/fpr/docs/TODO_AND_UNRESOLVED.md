# Incomplete / Unresolved Items

These were discussed but not fully built into exact files during the conversation:
- full production-grade mode_resolver.py
- full session core scripts with lifecycle state machine
- event normalization layer
- fully operational multi-agent orchestration
- FPR markdown/DOCX export from GUI
- single-file mode in every wrapper variant
- one-click Windows executable packaging
- full PubCast integration hooks for FPR checkpoints

These are included because the user explicitly asked for finished or not.
