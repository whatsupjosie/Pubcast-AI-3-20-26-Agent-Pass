# FPR Toolchain Notes

Built in conversation:
- FPR standard document
- machine-readable JSON schema
- auto-generator backend
- desktop GUI wrapper
- Windows launcher
- test draft JSON output

Hardening/debugging goals requested:
- path handling
- input validation
- safer scanning
- structural validation
- subprocess and timeout handling
- single-file or folder analysis
- Windows launcher reliability
- save/export support

Save/export functions requested:
- Save log as…
- Save copy of schema…
- Save copy of standard doc…
- Save copy of last output…
