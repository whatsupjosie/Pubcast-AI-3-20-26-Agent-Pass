# Project-Level Next Steps Discussed

1. Run the first real FPR on the PubCast voice/mode system
2. Fix what the FPR finds before moving forward
3. Apply the same flow to idle checkpointing and multi-agent routing
4. Wire FPR into PubCast workflow triggers
5. Resume building avatars, stage, control room, and recording pipeline under FPR discipline
