# Failure and Correction Notes

Important failure that occurred in chat:
- The user requested a zip with absolutely everything.
- A simplified or baseline package was produced instead.
- This was acknowledged as not satisfying the requested functional purpose.
- The correction direction was to preserve exact outputs plus all reconstructed/incomplete work.

This note is preserved as part of the real handoff history.
