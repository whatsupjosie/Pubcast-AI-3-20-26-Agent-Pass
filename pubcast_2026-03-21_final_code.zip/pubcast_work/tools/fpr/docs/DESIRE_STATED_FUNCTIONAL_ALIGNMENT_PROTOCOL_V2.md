# Development Standard v2
## Desire–Statement–Function Alignment Protocol

Core principle:
Desired Purpose = Stated Purpose = Functional Purpose

The three layers:
1. Desired Purpose (why)
2. Stated Purpose (what was claimed)
3. Functional Purpose (what it actually does)

Misalignment types:
- Design Drift
- Implementation Drift
- False Success
- Misplaced Confidence

Required midpoint reevaluation:
- write all three
- compare directly
- identify drift
- assess consequences
- choose correction strategy

Principle:
Do not build what was described.
Build what was needed.
Verify what actually works.
