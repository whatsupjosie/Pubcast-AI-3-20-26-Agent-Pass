# Development Standard
## Midpoint Reevaluation Protocol

Purpose: prevent false progress.

A feature is not successful because it exists.
A feature is successful only if it reliably fulfills the original desire it was created to serve.

Required midpoint check at roughly 60–75% completion:
1. Recall original desire
2. Define intended function
3. Assess current reality
4. Validate success
5. Identify false positives
6. Analyze gaps
7. Define required actions
8. Check feasibility
9. Reclassify role
10. Decide whether to continue, reinforce, recalibrate, combine, or remove

Core rule:
Build for outcome, not appearance.
