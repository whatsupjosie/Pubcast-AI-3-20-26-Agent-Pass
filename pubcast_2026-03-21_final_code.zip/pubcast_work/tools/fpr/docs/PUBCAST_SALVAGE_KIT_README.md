# PubCast Salvage Kit

Purpose:
Capture unfinished work into real files instead of leaving it stranded in chat.

Included concepts:
- session recovery checklist
- file intake template
- handoff template

Practical sequence:
1. fill out recovery checklist
2. create one intake entry per missing or unfinished file
3. save reconstructed files to disk
4. package them into the next zip
