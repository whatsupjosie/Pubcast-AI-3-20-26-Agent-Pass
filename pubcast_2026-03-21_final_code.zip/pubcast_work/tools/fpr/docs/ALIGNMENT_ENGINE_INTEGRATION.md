# PubCast Integration: Alignment Engine

Internal name:
- Alignment Engine
- Purpose Alignment Check (PAC)

Intended placement:
1. Checkup tools
2. Update tools
3. Installation/setup tools

Required project files:
- ALIGNMENT_CHECK.md
- ALIGNMENT_LOGS/
- CURRENT_STATE.md
- DECISIONS.md

Standard lifecycle:
START PROJECT -> alignment baseline created
BUILD FEATURE -> work normally
MIDPOINT -> required alignment check
PRE-COMPLETION -> required alignment check
END / CHECKPOINT -> summary logged
