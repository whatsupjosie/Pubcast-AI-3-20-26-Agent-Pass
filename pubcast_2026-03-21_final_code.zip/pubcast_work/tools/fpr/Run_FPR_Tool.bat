@echo off
set SCRIPT_DIR=%~dp0
python "%SCRIPT_DIR%fpr_desktop_tool.py"
