"""tests/test_15_api_coverage.py
Comprehensive API coverage for bots, mocap, voxel studio, and general endpoints.
Uses conftest fixtures (client / client_no_lifespan) for proper isolation.
A 503 from an uninitialized service is CORRECT behavior.
"""
import pytest


NEVER = (404, 500)


def _json_ok(resp):
    """Assert response is valid JSON and return parsed data."""
    ct = resp.headers.get("content-type", "")
    assert "application/json" in ct, f"Expected JSON, got {ct!r}"
    data = resp.json()
    assert isinstance(data, (dict, list))
    return data


# ── Bot Management API ────────────────────────────────────────────────────────

class TestBotAPI:
    def test_get_bots_status(self, client_no_lifespan):
        resp = client_no_lifespan.get("/api/bots")
        assert resp.status_code in (200, 503)
        _json_ok(resp)

    def test_get_bots_with_lifespan(self, client):
        resp = client.get("/api/bots")
        assert resp.status_code == 200
        data = _json_ok(resp)
        assert "bots" in data

    def test_get_bots_not_server_error(self, client_no_lifespan):
        resp = client_no_lifespan.get("/api/bots")
        assert resp.status_code not in NEVER

    def test_create_bot_valid_payload(self, client):
        import time as _t
        resp = client.post("/api/bots", json={
            "bot_id":        f"coverage_bot_{int(_t.time() * 1000) % 999999}",
            "name":          "Coverage Bot",
            "provider":      "openai",
            "model":         "gpt-4o",
            "api_key_env":   "OPENAI_API_KEY",
            "rooms":         ["room_a"],
            "system_prompt": "You are a test bot.",
        })
        assert resp.status_code in (200, 400, 409)
        _json_ok(resp)

    def test_get_single_bot_unknown_id(self, client):
        resp = client.get("/api/bots/nonexistent_bot_id_xyz_123")
        assert resp.status_code in (404, 403)
        _json_ok(resp)

    def test_delete_bot_unknown_id(self, client):
        resp = client.delete("/api/bots/nonexistent_bot_id_xyz_123")
        assert resp.status_code in (200, 404, 403)
        _json_ok(resp)

    def test_nudge_unknown_bot(self, client):
        resp = client.post("/api/bots/nonexistent_bot_xyz/nudge",
                           json={"room": "room_a"})
        assert resp.status_code not in (500,), f"Server error: {resp.text[:200]}"
        _json_ok(resp)

    def test_bots_response_has_structure(self, client):
        resp = client.get("/api/bots")
        assert resp.status_code == 200
        assert isinstance(resp.json().get("bots"), list)


# ── Mocap API ─────────────────────────────────────────────────────────────────

class TestMocapAPI:
    def test_mocap_status_acceptable(self, client_no_lifespan):
        resp = client_no_lifespan.get("/api/mocap/status")
        assert resp.status_code in (200, 503)
        _json_ok(resp)

    def test_mocap_status_not_server_error(self, client_no_lifespan):
        resp = client_no_lifespan.get("/api/mocap/status")
        assert resp.status_code not in NEVER

    def test_mocap_status_keys_when_live(self, client):
        resp = client.get("/api/mocap/status")
        assert resp.status_code == 200
        data = resp.json()
        # Key names from MocapStreamManager.get_status() actual response
        for key in ("active_avatar", "rig_id", "metrics"):
            assert key in data, f"missing mocap status key: {key} — got {list(data.keys())}"

    def test_mocap_start_acceptable(self, client_no_lifespan):
        resp = client_no_lifespan.post("/api/mocap/start",
                           json={"source_url": "udp://localhost:9999",
                                 "avatar_id": "test_avatar"})
        assert resp.status_code in (200, 400, 503)
        _json_ok(resp)

    def test_mocap_stop_acceptable(self, client_no_lifespan):
        resp = client_no_lifespan.post("/api/mocap/stop")
        assert resp.status_code in (200, 503)
        _json_ok(resp)


# ── Voxel Studio API ──────────────────────────────────────────────────────────

class TestVoxelStudioAPI:
    def test_vs_status_acceptable(self, client_no_lifespan):
        resp = client_no_lifespan.get("/api/vs/status")
        assert resp.status_code in (200, 503)
        _json_ok(resp)

    def test_vs_status_not_server_error(self, client_no_lifespan):
        resp = client_no_lifespan.get("/api/vs/status")
        assert resp.status_code not in NEVER

    def test_vs_primitives_returns_list(self, client):
        resp = client.get("/api/vs/primitives")
        assert resp.status_code == 200
        data = resp.json()
        assert isinstance(data, (list, dict))

    def test_vs_objects_returns_list(self, client):
        resp = client.get("/api/vs/objects")
        assert resp.status_code == 200
        data = resp.json()
        assert isinstance(data, (list, dict))

    def test_vs_scene_create_acceptable(self, client_no_lifespan):
        resp = client_no_lifespan.post("/api/vs/scene",
                                       params={"name": "coverage_test_scene"})
        assert resp.status_code in (200, 503)
        _json_ok(resp)

    def test_vs_scene_slate_acceptable(self, client_no_lifespan):
        resp = client_no_lifespan.post("/api/vs/scene/slate",
                                       json={"director": "Pete", "take": 1})
        assert resp.status_code in (200, 400, 503)
        _json_ok(resp)


# ── General API ───────────────────────────────────────────────────────────────

class TestGeneralAPI:
    def test_health_returns_200(self, client):
        resp = client.get("/api/health")
        assert resp.status_code == 200
        data = _json_ok(resp)
        assert isinstance(data, dict)
        assert len(data) > 0

    def test_jeremy_status_not_404_or_500(self, client_no_lifespan):
        resp = client_no_lifespan.get("/api/jeremy/status")
        assert resp.status_code not in NEVER

    def test_memory_status_not_404_or_500(self, client_no_lifespan):
        resp = client_no_lifespan.get("/api/memory/status")
        assert resp.status_code not in NEVER

    def test_jeremy_status_returns_json(self, client_no_lifespan):
        resp = client_no_lifespan.get("/api/jeremy/status")
        _json_ok(resp)

    def test_memory_status_returns_json(self, client_no_lifespan):
        resp = client_no_lifespan.get("/api/memory/status")
        _json_ok(resp)

    def test_root_returns_200(self, client):
        resp = client.get("/")
        assert resp.status_code == 200

    def test_pete_status_acceptable(self, client_no_lifespan):
        resp = client_no_lifespan.get("/api/pete/status")
        assert resp.status_code in (200, 503)
        _json_ok(resp)

    def test_jeremy_status_with_lifespan(self, client):
        resp = client.get("/api/jeremy/status")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "ok"
        assert isinstance(data["rooms_watched"], int)

    def test_memory_status_with_lifespan(self, client):
        resp = client.get("/api/memory/status")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "ok"
        assert isinstance(data["total_banks"], int)
