"""tests/test_13_conductor_status.py
Uses conftest fixtures so we don't fight the session-scoped lifespan client.
"""
import pytest


class TestJeremyStatus:
    def test_returns_503_or_200(self, client_no_lifespan):
        resp = client_no_lifespan.get("/api/jeremy/status")
        assert resp.status_code in (200, 503)

    def test_has_status_key(self, client_no_lifespan):
        resp = client_no_lifespan.get("/api/jeremy/status")
        assert "status" in resp.json()

    def test_503_body_is_unavailable(self, client_no_lifespan):
        resp = client_no_lifespan.get("/api/jeremy/status")
        if resp.status_code == 503:
            assert resp.json()["status"] == "unavailable"

    def test_200_has_required_keys(self, client):
        resp = client.get("/api/jeremy/status")
        assert resp.status_code == 200
        data = resp.json()
        assert "rooms_watched" in data
        assert "scenes" in data
        assert isinstance(data["rooms_watched"], int)
        assert isinstance(data["scenes"], list)

    def test_scene_items_have_all_keys(self, client):
        resp = client.get("/api/jeremy/status")
        assert resp.status_code == 200
        for scene in resp.json()["scenes"]:
            for key in ("room_id", "phase", "silence_seconds", "last_nudge_age",
                        "drama_necessity", "plot_points_open", "energy_recent"):
                assert key in scene, f"missing key: {key}"

    def test_drama_necessity_range(self, client):
        resp = client.get("/api/jeremy/status")
        assert resp.status_code == 200
        for scene in resp.json()["scenes"]:
            dn = scene["drama_necessity"]
            assert 0.0 <= dn <= 1.0, f"drama_necessity out of range: {dn}"

    def test_not_404_or_500(self, client_no_lifespan):
        resp = client_no_lifespan.get("/api/jeremy/status")
        assert resp.status_code not in (404, 500)

    def test_response_is_json(self, client_no_lifespan):
        resp = client_no_lifespan.get("/api/jeremy/status")
        assert resp.headers["content-type"].startswith("application/json")


class TestMemoryStatus:
    def test_returns_503_or_200(self, client_no_lifespan):
        resp = client_no_lifespan.get("/api/memory/status")
        assert resp.status_code in (200, 503)

    def test_has_status_key(self, client_no_lifespan):
        resp = client_no_lifespan.get("/api/memory/status")
        assert "status" in resp.json()

    def test_503_body_correct(self, client_no_lifespan):
        resp = client_no_lifespan.get("/api/memory/status")
        if resp.status_code == 503:
            assert resp.json()["status"] == "unavailable"

    def test_200_has_required_keys(self, client):
        resp = client.get("/api/memory/status")
        assert resp.status_code == 200
        data = resp.json()
        assert "total_banks" in data
        assert "banks" in data
        assert isinstance(data["total_banks"], int)
        assert isinstance(data["banks"], list)

    def test_bank_entries_have_required_keys(self, client):
        resp = client.get("/api/memory/status")
        assert resp.status_code == 200
        for bank in resp.json()["banks"]:
            for key in ("character_id", "name", "memory_count", "last_activity"):
                assert key in bank, f"missing key: {key}"

    def test_total_banks_matches_list_length(self, client):
        resp = client.get("/api/memory/status")
        assert resp.status_code == 200
        data = resp.json()
        assert data["total_banks"] == len(data["banks"])

    def test_not_404_or_500(self, client_no_lifespan):
        resp = client_no_lifespan.get("/api/memory/status")
        assert resp.status_code not in (404, 500)

    def test_response_is_json(self, client_no_lifespan):
        resp = client_no_lifespan.get("/api/memory/status")
        assert resp.headers["content-type"].startswith("application/json")
