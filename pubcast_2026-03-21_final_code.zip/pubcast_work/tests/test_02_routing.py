"""
test_02_routing.py — Route registration, ordering, and conflict detection
══════════════════════════════════════════════════════════════════════════
The most critical test in this file is the WebSocket route ordering check.

KNOWN BUG (fixed in main.py): /ws/{room} is a catch-all. If /ws/unity and
/ws/studio are registered AFTER it, Starlette matches them to the catch-all
first and the dedicated Unity/Studio handlers are never reached.

These tests enforce that the correct ordering is maintained permanently —
if someone reorders routes in main.py, a test will catch it before it ships.
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest
from starlette.routing import Route, WebSocketRoute, Mount

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _get_routes(raw_app):
    """Flatten the app route list into (path, methods/type) tuples."""
    return raw_app.routes


def _websocket_routes(raw_app):
    """Return only WebSocketRoute objects with their paths, in registration order."""
    return [r for r in raw_app.routes if isinstance(r, WebSocketRoute)]


def _ws_path_order(raw_app):
    """Return WebSocket route paths in registration order."""
    return [r.path for r in _websocket_routes(raw_app)]


# ─────────────────────────────────────────────────────────────────────────────
# 1. WebSocket route ordering — THE critical test
# ─────────────────────────────────────────────────────────────────────────────

def test_ws_unity_registered_before_catchall(raw_app):
    """/ws/unity must appear in the route list BEFORE /ws/{room}.

    If /ws/{room} comes first, Starlette matches /ws/unity to the catch-all
    and the UnityBridge handler is never reached.
    """
    order = _ws_path_order(raw_app)
    assert "/ws/unity" in order, "/ws/unity is not registered at all"
    assert "/ws/{room}" in order, "/ws/{room} is not registered at all"

    unity_idx  = order.index("/ws/unity")
    catchall_idx = order.index("/ws/{room}")
    assert unity_idx < catchall_idx, (
        f"/ws/unity is at position {unity_idx} but /ws/{{room}} is at {catchall_idx}. "
        f"The catch-all will shadow /ws/unity — Unity Bridge WebSocket will be broken."
    )


def test_ws_studio_registered_before_catchall(raw_app):
    """/ws/studio must appear in the route list BEFORE /ws/{room}.

    Same shadowing issue as /ws/unity — Studio Control Room WebSocket
    will silently connect to the hub instead of the studio handler.
    """
    order = _ws_path_order(raw_app)
    assert "/ws/studio" in order, "/ws/studio is not registered at all"

    studio_idx   = order.index("/ws/studio")
    catchall_idx = order.index("/ws/{room}")
    assert studio_idx < catchall_idx, (
        f"/ws/studio is at position {studio_idx} but /ws/{{room}} is at {catchall_idx}. "
        f"The catch-all will shadow /ws/studio — Studio Control Room will be broken."
    )


def test_specific_ws_routes_all_before_catchall(raw_app):
    """Comprehensive: every named WS route must precede the catch-all."""
    order = _ws_path_order(raw_app)
    if "/ws/{room}" not in order:
        pytest.skip("/ws/{room} not registered — nothing to check")

    catchall_idx = order.index("/ws/{room}")
    specific = [p for p in order if "{" not in p]  # literal paths only

    for path in specific:
        idx = order.index(path)
        assert idx < catchall_idx, (
            f"Specific WS route {path!r} (pos {idx}) comes AFTER catch-all "
            f"/ws/{{room}} (pos {catchall_idx}) — it will never be reached."
        )


# ─────────────────────────────────────────────────────────────────────────────
# 2. All expected routes are registered
# ─────────────────────────────────────────────────────────────────────────────

EXPECTED_HTTP_ROUTES = [
    "/api/health",
    "/api/health/breakers",
    "/api/me",
    "/api/state/user",
    "/api/state/production",
    "/api/cameras",
    "/api/cameras/program",
    "/api/cameras/preview",
    "/api/cameras/cut",
    "/api/recording/profiles",
    "/api/recording/sessions",
    "/api/avatars/presets",
    "/api/avatars/me",
    "/api/bots",
    "/api/pubworld/scenes",
    "/api/pubworld/props",
    "/api/pubworld/prototypes",
    "/api/pubworld/generate",
    "/api/pubworld/generate/status",
    "/api/lighting/presets",
    "/api/lighting/active",
    "/api/bridge/status",
    "/api/bridge/connect",
    "/api/choreo/status",
    "/api/performer/status",
    "/api/engine/status",
    "/api/jeremy/health",
    "/api/purfluous/scenes",
    "/api/studio/status",
    "/api/unity/status",
    "/api/voxel/assets",
    "/api/voxel/scenes",
    # Audio device routes (registered directly on app, not via router)
    "/api/audio/devices",
    "/api/audio/devices/refresh",
    "/api/audio/devices/active",
    # Page routes
    "/", "/control", "/stage", "/dressing", "/bar", "/world",
    "/builder", "/gallery", "/analytics", "/launch", "/byok", "/studio",
]

EXPECTED_WS_ROUTES = ["/ws/unity", "/ws/studio", "/ws/{room}"]

# Router-mounted routes (prefixed)
EXPECTED_ROUTER_ROUTES = [
    "/api/mic/cough",
    "/api/mic/cough/status",
    "/api/mic/profiles",
    "/pubworld/ws/{client_id}",
    "/pubworld/api/room-change",
    "/pubworld/state",
]


def _all_route_paths(raw_app):
    """Collect all registered route paths from the app and included routers."""
    paths = set()
    for route in raw_app.routes:
        if hasattr(route, "path"):
            paths.add(route.path)
        # Mounted sub-apps (StaticFiles)
        if isinstance(route, Mount) and hasattr(route, "path"):
            paths.add(route.path)
    return paths


@pytest.mark.parametrize("path", EXPECTED_HTTP_ROUTES)
def test_http_route_registered(raw_app, path):
    paths = _all_route_paths(raw_app)
    assert path in paths, f"Expected route {path!r} is not registered"


@pytest.mark.parametrize("path", EXPECTED_WS_ROUTES)
def test_ws_route_registered(raw_app, path):
    ws_paths = {r.path for r in _websocket_routes(raw_app)}
    assert path in ws_paths, f"Expected WebSocket route {path!r} is not registered"


@pytest.mark.parametrize("path", EXPECTED_ROUTER_ROUTES)
def test_router_route_registered(raw_app, path):
    paths = _all_route_paths(raw_app)
    assert path in paths, (
        f"Expected router-mounted route {path!r} is not registered. "
        "Check that the router is included in main.py."
    )


# ─────────────────────────────────────────────────────────────────────────────
# 3. Static file mounts
# ─────────────────────────────────────────────────────────────────────────────

def test_static_mount_registered(raw_app):
    mount_paths = {r.path for r in raw_app.routes if isinstance(r, Mount)}
    assert "/static" in mount_paths, "/static is not mounted — all JS/CSS will 404"


def test_assets_mount_registered(raw_app):
    mount_paths = {r.path for r in raw_app.routes if isinstance(r, Mount)}
    assert "/assets" in mount_paths, "/assets is not mounted — GLB models and VOD will 404"


# ─────────────────────────────────────────────────────────────────────────────
# 4. No duplicate route definitions
# ─────────────────────────────────────────────────────────────────────────────

def test_no_duplicate_websocket_routes(raw_app):
    """Each WebSocket path should appear exactly once."""
    ws_paths = [r.path for r in _websocket_routes(raw_app)]
    seen = {}
    duplicates = []
    for p in ws_paths:
        seen[p] = seen.get(p, 0) + 1
        if seen[p] == 2:
            duplicates.append(p)
    assert not duplicates, (
        f"Duplicate WebSocket route(s) detected: {duplicates}. "
        "The later definition is dead code."
    )


def test_no_duplicate_http_routes(raw_app):
    """No HTTP path+method combination should be registered twice."""
    from starlette.routing import Route as StarletteRoute
    seen: dict[tuple, int] = {}
    duplicates = []
    for route in raw_app.routes:
        if not isinstance(route, StarletteRoute):
            continue
        for method in (route.methods or {"GET"}):
            key = (route.path, method)
            seen[key] = seen.get(key, 0) + 1
            if seen[key] == 2:
                duplicates.append(key)
    assert not duplicates, f"Duplicate HTTP route(s): {duplicates}"
