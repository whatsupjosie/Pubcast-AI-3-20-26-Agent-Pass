"""tests/test_10_bot_busystate.py"""
import pytest
from fastapi.testclient import TestClient
from main import app

client = TestClient(app, raise_server_exceptions=False)


class TestBotBusyState:
    def test_get_bots_returns_list_structure(self):
        resp = client.get("/api/bots")
        # 503 without lifespan is correct; 200 with bots also valid
        assert resp.status_code in (200, 503)
        if resp.status_code == 200:
            data = resp.json()
            assert "bots" in data
            assert isinstance(data["bots"], list)

    def test_each_bot_has_is_busy(self):
        resp = client.get("/api/bots")
        if resp.status_code != 200:
            pytest.skip("lifespan not active")
        for bot in resp.json()["bots"]:
            assert "is_busy" in bot
            assert isinstance(bot["is_busy"], bool)

    def test_each_bot_has_last_reply_at(self):
        resp = client.get("/api/bots")
        if resp.status_code != 200:
            pytest.skip("lifespan not active")
        for bot in resp.json()["bots"]:
            assert "last_reply_at" in bot
            assert isinstance(bot["last_reply_at"], float)

    def test_is_busy_not_null(self):
        resp = client.get("/api/bots")
        if resp.status_code != 200:
            pytest.skip("lifespan not active")
        for bot in resp.json()["bots"]:
            assert bot["is_busy"] is not None

    def test_503_without_lifespan_is_valid(self):
        resp = client.get("/api/bots")
        # Without lifespan, 503 is correct behavior — not a bug
        assert resp.status_code in (200, 503)

    def test_response_is_valid_json(self):
        resp = client.get("/api/bots")
        assert resp.headers["content-type"].startswith("application/json")
        data = resp.json()
        assert isinstance(data, dict)


class TestBotStatusModel:
    def test_botstatus_model_defaults(self):
        from modules.models import BotStatus
        bs = BotStatus(
            bot_id="test", name="Test", provider="openai",
            model="gpt-4o", rooms=[]
        )
        assert bs.is_busy is False
        assert bs.last_reply_at == 0.0
        assert bs.enabled is True

    def test_botstatus_is_busy_settable(self):
        from modules.models import BotStatus
        bs = BotStatus(
            bot_id="b", name="B", provider="gemini",
            model="gemini-pro", rooms=["r1"], is_busy=True
        )
        assert bs.is_busy is True

    def test_botstatus_last_reply_at_settable(self):
        from modules.models import BotStatus
        bs = BotStatus(
            bot_id="b", name="B", provider="openai",
            model="gpt-4o", rooms=[], last_reply_at=1234567890.0
        )
        assert bs.last_reply_at == 1234567890.0
