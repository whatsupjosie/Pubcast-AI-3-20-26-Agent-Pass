"""tests/test_08_memory_persistence.py"""
import pytest
from modules.universal_memory_system import (
    UniversalMemorySystem, CharacterProfile, MemoryEntry, MemoryType
)


def _populated_system():
    ms = UniversalMemorySystem()
    ms.register_character(CharacterProfile(character_id="pete", name="Pete"))
    ms.register_character(CharacterProfile(character_id="jeremy", name="Jeremy Cricket"))
    bank = ms.get_or_create_bank("pete")
    bank.add(MemoryEntry(content="Host likes wide shots", importance=0.8, source="observation"))
    bank.add(MemoryEntry(content="Show starts at 9pm", importance=0.6, tags=["schedule"]))
    bank2 = ms.get_or_create_bank("jeremy")
    bank2.add(MemoryEntry(content="Room energy was high tonight", memory_type=MemoryType.EMOTIONAL))
    return ms


class TestSerialize:
    def test_empty_system_structure(self):
        ms = UniversalMemorySystem()
        data = ms.serialize()
        assert data == {"version": 1, "banks": {}}

    def test_populated_captures_banks(self):
        ms = _populated_system()
        data = ms.serialize()
        assert data["version"] == 1
        assert "pete" in data["banks"]
        assert "jeremy" in data["banks"]

    def test_memory_count_preserved(self):
        ms = _populated_system()
        data = ms.serialize()
        assert len(data["banks"]["pete"]["memories"]) == 2
        assert len(data["banks"]["jeremy"]["memories"]) == 1

    def test_profile_fields_present(self):
        ms = _populated_system()
        data = ms.serialize()
        pete_profile = data["banks"]["pete"]["profile"]
        assert pete_profile["name"] == "Pete"
        assert pete_profile["character_id"] == "pete"

    def test_memory_fields_complete(self):
        ms = _populated_system()
        data = ms.serialize()
        mem = data["banks"]["pete"]["memories"][0]
        for key in ("id", "content", "memory_type", "importance", "tags", "source", "timestamp"):
            assert key in mem, f"missing key: {key}"

    def test_never_raises(self):
        ms = UniversalMemorySystem()
        try:
            ms.serialize()
        except Exception as e:
            pytest.fail(f"serialize() raised: {e}")


class TestRestore:
    def test_restores_banks(self):
        ms = _populated_system()
        data = ms.serialize()
        ms2 = UniversalMemorySystem()
        ms2.restore(data)
        assert "pete" in ms2._banks
        assert "jeremy" in ms2._banks

    def test_restores_memory_count(self):
        ms = _populated_system()
        data = ms.serialize()
        ms2 = UniversalMemorySystem()
        ms2.restore(data)
        assert len(ms2._banks["pete"]._memories) == 2
        assert len(ms2._banks["jeremy"]._memories) == 1

    def test_restores_profiles(self):
        ms = _populated_system()
        data = ms.serialize()
        ms2 = UniversalMemorySystem()
        ms2.restore(data)
        assert "pete" in ms2._profiles
        assert ms2._profiles["pete"].name == "Pete"

    def test_malformed_data_does_not_raise(self):
        ms = UniversalMemorySystem()
        for bad in [None, {}, {"version": 1}, {"banks": "notadict"},
                    {"version": 1, "banks": {"x": "notadict"}},
                    {"version": 1, "banks": {"x": {"memories": [None, "bad", 42]}}}]:
            try:
                ms.restore(bad)
            except Exception as e:
                pytest.fail(f"restore() raised on {bad!r}: {e}")

    def test_partial_bad_entries_skipped(self):
        data = {
            "version": 1,
            "banks": {
                "good_char": {
                    "profile": {"character_id": "good_char", "name": "Good"},
                    "memories": [
                        {"content": "valid memory", "memory_type": "episodic",
                         "importance": 0.5, "timestamp": 1.0, "id": "abc", "tags": [], "source": "test"},
                        {"BROKEN": True},  # malformed — should be skipped
                        None,              # malformed — should be skipped
                    ]
                }
            }
        }
        ms = UniversalMemorySystem()
        ms.restore(data)
        assert "good_char" in ms._banks
        assert len(ms._banks["good_char"]._memories) == 1

    def test_merges_not_clears(self):
        ms = UniversalMemorySystem()
        ms.register_character(CharacterProfile(character_id="existing", name="Existing"))
        ms.get_or_create_bank("existing").add(MemoryEntry(content="pre-existing memory"))
        data = {"version": 1, "banks": {"new_char": {
            "profile": {"character_id": "new_char", "name": "New"},
            "memories": [{"content": "new memory", "memory_type": "episodic",
                          "importance": 0.5, "timestamp": 1.0, "id": "x", "tags": [], "source": "test"}]
        }}}
        ms.restore(data)
        assert "existing" in ms._banks
        assert "new_char" in ms._banks


class TestRoundTrip:
    def test_full_round_trip(self):
        ms1 = _populated_system()
        data1 = ms1.serialize()
        ms2 = UniversalMemorySystem()
        ms2.restore(data1)
        data2 = ms2.serialize()
        assert data1["version"] == data2["version"]
        for char_id in data1["banks"]:
            assert char_id in data2["banks"]
            assert len(data1["banks"][char_id]["memories"]) == \
                   len(data2["banks"][char_id]["memories"])

    def test_memory_content_preserved(self):
        ms = UniversalMemorySystem()
        ms.register_character(CharacterProfile(character_id="c1", name="C1"))
        ms.get_or_create_bank("c1").add(
            MemoryEntry(content="unique content xyz", importance=0.9, tags=["test_tag"])
        )
        data = ms.serialize()
        ms2 = UniversalMemorySystem()
        ms2.restore(data)
        memories = ms2._banks["c1"]._memories
        assert len(memories) == 1
        assert memories[0].content == "unique content xyz"
        assert "test_tag" in memories[0].tags
