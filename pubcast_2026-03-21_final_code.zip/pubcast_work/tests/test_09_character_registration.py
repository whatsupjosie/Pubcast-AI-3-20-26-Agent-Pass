"""tests/test_09_character_registration.py"""
import pytest
from pathlib import Path
from unittest.mock import MagicMock
from modules.universal_memory_system import UniversalMemorySystem, CharacterProfile
from modules.bots import BotManager
from modules.models import BotConfig, BotProvider


def _make_bot_config(bot_id="test_bot_01", name="TestBot"):
    return BotConfig(
        bot_id=bot_id,
        name=name,
        owner_id="owner_123",
        provider=BotProvider.OPENAI,
        model="gpt-4o",
        api_key_env="OPENAI_API_KEY",
        rooms=["room_a"],
    )


def _make_manager(tmp_path: Path):
    hub = MagicMock()
    hub.is_user_in_room = MagicMock(return_value=False)
    hub.get_recent_history = MagicMock(return_value=[])
    hub.invalidate_user_cache = MagicMock()
    hub.post_chat_message = MagicMock()
    return BotManager(tmp_path, hub)


class TestSetMemorySystem:
    def test_wires_reference(self, tmp_path):
        mgr = _make_manager(tmp_path)
        ms = UniversalMemorySystem()
        assert mgr._memory_system is None
        mgr.set_memory_system(ms)
        assert mgr._memory_system is ms

    def test_set_none_is_safe(self, tmp_path):
        mgr = _make_manager(tmp_path)
        try:
            mgr.set_memory_system(None)
        except Exception as e:
            pytest.fail(f"set_memory_system(None) raised: {e}")

    def test_registers_existing_bots(self, tmp_path):
        mgr = _make_manager(tmp_path)
        cfg = _make_bot_config()
        mgr.upsert_config(cfg)
        ms = UniversalMemorySystem()
        mgr.set_memory_system(ms)
        assert cfg.bot_id in ms._banks

    def test_already_loaded_bots_all_registered(self, tmp_path):
        mgr = _make_manager(tmp_path)
        for i in range(3):
            mgr.upsert_config(_make_bot_config(f"bot_{i}", f"Bot{i}"))
        ms = UniversalMemorySystem()
        mgr.set_memory_system(ms)
        for i in range(3):
            assert f"bot_{i}" in ms._banks


class TestUpsertConfigRegistration:
    def test_upsert_with_memory_system_registers(self, tmp_path):
        mgr = _make_manager(tmp_path)
        ms = UniversalMemorySystem()
        mgr.set_memory_system(ms)
        cfg = _make_bot_config()
        mgr.upsert_config(cfg)
        assert cfg.bot_id in ms._banks

    def test_upsert_without_memory_system_does_not_raise(self, tmp_path):
        mgr = _make_manager(tmp_path)
        assert mgr._memory_system is None
        cfg = _make_bot_config()
        try:
            mgr.upsert_config(cfg)
        except Exception as e:
            pytest.fail(f"upsert_config without memory_system raised: {e}")

    def test_upsert_creates_bank_in_memory_system(self, tmp_path):
        mgr = _make_manager(tmp_path)
        ms = UniversalMemorySystem()
        mgr.set_memory_system(ms)
        cfg = _make_bot_config(bot_id="unique_bot_x")
        mgr.upsert_config(cfg)
        assert "unique_bot_x" in ms._banks

    def test_profile_name_correct(self, tmp_path):
        mgr = _make_manager(tmp_path)
        ms = UniversalMemorySystem()
        mgr.set_memory_system(ms)
        cfg = _make_bot_config(bot_id="named_bot", name="Sir Purfluous")
        mgr.upsert_config(cfg)
        assert "named_bot" in ms._profiles
        assert ms._profiles["named_bot"].name == "Sir Purfluous"


class TestRegisterCharacter:
    def test_noop_when_no_memory_system(self, tmp_path):
        mgr = _make_manager(tmp_path)
        cfg = _make_bot_config()
        try:
            mgr._register_character(cfg)
        except Exception as e:
            pytest.fail(f"_register_character raised with no memory_system: {e}")

    def test_logs_warning_on_failure(self, tmp_path):
        mgr = _make_manager(tmp_path)
        bad_ms = MagicMock()
        bad_ms.register_character.side_effect = RuntimeError("boom")
        mgr._memory_system = bad_ms
        cfg = _make_bot_config()
        try:
            mgr._register_character(cfg)
        except Exception as e:
            pytest.fail(f"_register_character raised instead of logging warning: {e}")

    def test_does_not_raise_on_bad_config(self, tmp_path):
        mgr = _make_manager(tmp_path)
        ms = UniversalMemorySystem()
        mgr.set_memory_system(ms)
        bad_cfg = MagicMock()
        bad_cfg.bot_id = None  # will cause CharacterProfile to fail
        try:
            mgr._register_character(bad_cfg)
        except Exception as e:
            pytest.fail(f"_register_character raised on bad config: {e}")
