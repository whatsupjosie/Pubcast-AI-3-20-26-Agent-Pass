"""
tests/test_07_bone_converter.py
Tests for modules/bone_converter.py
"""
import pytest
from modules.bone_converter import (
    BoneNameFormat,
    PUBCAST_BONES,
    convert_bone_name,
    convert_pose,
    list_supported_bones,
)


# ── convert_bone_name — known bones ──────────────────────────────────────────

class TestMixamoKnown:
    def test_hips_to_pelvis(self):
        assert convert_bone_name("Hips", BoneNameFormat.MIXAMO) == "Pelvis"

    def test_spine_chain(self):
        assert convert_bone_name("Spine",  BoneNameFormat.MIXAMO) == "Spine_01"
        assert convert_bone_name("Spine1", BoneNameFormat.MIXAMO) == "Spine_02"
        assert convert_bone_name("Spine2", BoneNameFormat.MIXAMO) == "Spine_03"

    def test_left_arm(self):
        assert convert_bone_name("LeftShoulder",  BoneNameFormat.MIXAMO) == "Clavicle_L"
        assert convert_bone_name("LeftArm",       BoneNameFormat.MIXAMO) == "UpperArm_L"
        assert convert_bone_name("LeftForeArm",   BoneNameFormat.MIXAMO) == "LowerArm_L"
        assert convert_bone_name("LeftHand",      BoneNameFormat.MIXAMO) == "Hand_L"

    def test_right_arm(self):
        assert convert_bone_name("RightShoulder", BoneNameFormat.MIXAMO) == "Clavicle_R"
        assert convert_bone_name("RightArm",      BoneNameFormat.MIXAMO) == "UpperArm_R"
        assert convert_bone_name("RightForeArm",  BoneNameFormat.MIXAMO) == "LowerArm_R"
        assert convert_bone_name("RightHand",     BoneNameFormat.MIXAMO) == "Hand_R"

    def test_left_leg(self):
        assert convert_bone_name("LeftUpLeg",   BoneNameFormat.MIXAMO) == "Thigh_L"
        assert convert_bone_name("LeftLeg",     BoneNameFormat.MIXAMO) == "Calf_L"
        assert convert_bone_name("LeftFoot",    BoneNameFormat.MIXAMO) == "Foot_L"
        assert convert_bone_name("LeftToeBase", BoneNameFormat.MIXAMO) == "Ball_L"

    def test_right_leg(self):
        assert convert_bone_name("RightUpLeg",   BoneNameFormat.MIXAMO) == "Thigh_R"
        assert convert_bone_name("RightLeg",     BoneNameFormat.MIXAMO) == "Calf_R"
        assert convert_bone_name("RightFoot",    BoneNameFormat.MIXAMO) == "Foot_R"
        assert convert_bone_name("RightToeBase", BoneNameFormat.MIXAMO) == "Ball_R"

    def test_neck_head(self):
        assert convert_bone_name("Neck", BoneNameFormat.MIXAMO) == "Neck_01"
        assert convert_bone_name("Head", BoneNameFormat.MIXAMO) == "Head"

    def test_left_fingers(self):
        assert convert_bone_name("LeftHandThumb1",  BoneNameFormat.MIXAMO) == "Thumb_01_L"
        assert convert_bone_name("LeftHandIndex1",  BoneNameFormat.MIXAMO) == "Index_01_L"
        assert convert_bone_name("LeftHandMiddle1", BoneNameFormat.MIXAMO) == "Middle_01_L"
        assert convert_bone_name("LeftHandRing1",   BoneNameFormat.MIXAMO) == "Ring_01_L"
        assert convert_bone_name("LeftHandPinky1",  BoneNameFormat.MIXAMO) == "Pinky_01_L"

    def test_mixamo_prefix_variant(self):
        assert convert_bone_name("mixamorig:Hips",     BoneNameFormat.MIXAMO) == "Pelvis"
        assert convert_bone_name("mixamorig:LeftArm",  BoneNameFormat.MIXAMO) == "UpperArm_L"
        assert convert_bone_name("mixamorig:RightLeg", BoneNameFormat.MIXAMO) == "Calf_R"


class TestRigifyKnown:
    def test_spine(self):
        assert convert_bone_name("DEF-spine",     BoneNameFormat.RIGIFY) == "Pelvis"
        assert convert_bone_name("DEF-spine.001", BoneNameFormat.RIGIFY) == "Spine_01"
        assert convert_bone_name("DEF-spine.002", BoneNameFormat.RIGIFY) == "Spine_02"
        assert convert_bone_name("DEF-spine.003", BoneNameFormat.RIGIFY) == "Spine_03"

    def test_left_arm(self):
        assert convert_bone_name("DEF-shoulder.L",  BoneNameFormat.RIGIFY) == "Clavicle_L"
        assert convert_bone_name("DEF-upper_arm.L", BoneNameFormat.RIGIFY) == "UpperArm_L"
        assert convert_bone_name("DEF-forearm.L",   BoneNameFormat.RIGIFY) == "LowerArm_L"
        assert convert_bone_name("DEF-hand.L",      BoneNameFormat.RIGIFY) == "Hand_L"

    def test_right_arm(self):
        assert convert_bone_name("DEF-shoulder.R",  BoneNameFormat.RIGIFY) == "Clavicle_R"
        assert convert_bone_name("DEF-upper_arm.R", BoneNameFormat.RIGIFY) == "UpperArm_R"
        assert convert_bone_name("DEF-forearm.R",   BoneNameFormat.RIGIFY) == "LowerArm_R"
        assert convert_bone_name("DEF-hand.R",      BoneNameFormat.RIGIFY) == "Hand_R"

    def test_left_leg(self):
        assert convert_bone_name("DEF-thigh.L", BoneNameFormat.RIGIFY) == "Thigh_L"
        assert convert_bone_name("DEF-shin.L",  BoneNameFormat.RIGIFY) == "Calf_L"
        assert convert_bone_name("DEF-foot.L",  BoneNameFormat.RIGIFY) == "Foot_L"
        assert convert_bone_name("DEF-toe.L",   BoneNameFormat.RIGIFY) == "Ball_L"

    def test_right_leg(self):
        assert convert_bone_name("DEF-thigh.R", BoneNameFormat.RIGIFY) == "Thigh_R"
        assert convert_bone_name("DEF-shin.R",  BoneNameFormat.RIGIFY) == "Calf_R"
        assert convert_bone_name("DEF-foot.R",  BoneNameFormat.RIGIFY) == "Foot_R"

    def test_neck_head(self):
        assert convert_bone_name("DEF-neck", BoneNameFormat.RIGIFY) == "Neck_01"
        assert convert_bone_name("DEF-head", BoneNameFormat.RIGIFY) == "Head"

    def test_fingers(self):
        assert convert_bone_name("DEF-thumb.01.L",   BoneNameFormat.RIGIFY) == "Thumb_01_L"
        assert convert_bone_name("DEF-f_index.01.L", BoneNameFormat.RIGIFY) == "Index_01_L"
        assert convert_bone_name("DEF-f_pinky.03.R", BoneNameFormat.RIGIFY) == "Pinky_03_R"

    def test_org_prefix(self):
        assert convert_bone_name("ORG-spine",       BoneNameFormat.RIGIFY) == "Pelvis"
        assert convert_bone_name("ORG-upper_arm.L", BoneNameFormat.RIGIFY) == "UpperArm_L"


class TestRokokoKnown:
    def test_core(self):
        assert convert_bone_name("Hip",     BoneNameFormat.ROKOKO) == "Pelvis"
        assert convert_bone_name("Stomach", BoneNameFormat.ROKOKO) == "Spine_01"
        assert convert_bone_name("Chest",   BoneNameFormat.ROKOKO) == "Spine_02"
        assert convert_bone_name("Neck",    BoneNameFormat.ROKOKO) == "Neck_01"
        assert convert_bone_name("Head",    BoneNameFormat.ROKOKO) == "Head"

    def test_left_arm(self):
        assert convert_bone_name("LeftShoulderBlade", BoneNameFormat.ROKOKO) == "Clavicle_L"
        assert convert_bone_name("LeftShoulder",      BoneNameFormat.ROKOKO) == "UpperArm_L"
        assert convert_bone_name("LeftElbow",         BoneNameFormat.ROKOKO) == "LowerArm_L"
        assert convert_bone_name("LeftWrist",         BoneNameFormat.ROKOKO) == "Hand_L"

    def test_right_arm(self):
        assert convert_bone_name("RightShoulderBlade", BoneNameFormat.ROKOKO) == "Clavicle_R"
        assert convert_bone_name("RightShoulder",      BoneNameFormat.ROKOKO) == "UpperArm_R"
        assert convert_bone_name("RightElbow",         BoneNameFormat.ROKOKO) == "LowerArm_R"
        assert convert_bone_name("RightWrist",         BoneNameFormat.ROKOKO) == "Hand_R"

    def test_legs(self):
        assert convert_bone_name("LeftHip",    BoneNameFormat.ROKOKO) == "Thigh_L"
        assert convert_bone_name("LeftKnee",   BoneNameFormat.ROKOKO) == "Calf_L"
        assert convert_bone_name("LeftAnkle",  BoneNameFormat.ROKOKO) == "Foot_L"
        assert convert_bone_name("RightHip",   BoneNameFormat.ROKOKO) == "Thigh_R"
        assert convert_bone_name("RightKnee",  BoneNameFormat.ROKOKO) == "Calf_R"
        assert convert_bone_name("RightAnkle", BoneNameFormat.ROKOKO) == "Foot_R"

    def test_fingers(self):
        assert convert_bone_name("LeftHandThumb1",  BoneNameFormat.ROKOKO) == "Thumb_01_L"
        assert convert_bone_name("RightHandPinky3", BoneNameFormat.ROKOKO) == "Pinky_03_R"


class TestPubcastPassthrough:
    def test_valid_pubcast_bone(self):
        assert convert_bone_name("Pelvis",    BoneNameFormat.PUBCAST) == "Pelvis"
        assert convert_bone_name("Hand_L",    BoneNameFormat.PUBCAST) == "Hand_L"
        assert convert_bone_name("Spine_01",  BoneNameFormat.PUBCAST) == "Spine_01"
        assert convert_bone_name("Thigh_R",   BoneNameFormat.PUBCAST) == "Thigh_R"
        assert convert_bone_name("Neck_01",   BoneNameFormat.PUBCAST) == "Neck_01"

    def test_invalid_pubcast_bone_returns_none(self):
        assert convert_bone_name("Forearm_L", BoneNameFormat.PUBCAST) is None
        assert convert_bone_name("Wrist_L",   BoneNameFormat.PUBCAST) is None
        assert convert_bone_name("spine",     BoneNameFormat.PUBCAST) is None


# ── Unknown bones return None, never raise ────────────────────────────────────

class TestUnknownBones:
    def test_mixamo_unknown_returns_none(self):
        assert convert_bone_name("NonExistentBone", BoneNameFormat.MIXAMO) is None

    def test_rigify_unknown_returns_none(self):
        assert convert_bone_name("DEF-fantasy.bone", BoneNameFormat.RIGIFY) is None

    def test_rokoko_unknown_returns_none(self):
        assert convert_bone_name("MadeUpBone", BoneNameFormat.ROKOKO) is None

    def test_pubcast_unknown_returns_none(self):
        assert convert_bone_name("NotABone", BoneNameFormat.PUBCAST) is None

    def test_empty_string_returns_none(self):
        for fmt in BoneNameFormat:
            result = convert_bone_name("", fmt)
            assert result is None or isinstance(result, str)  # never raises

    def test_none_like_input_does_not_raise(self):
        # Should not raise even with unexpected input types
        try:
            result = convert_bone_name("!!!@#$", BoneNameFormat.MIXAMO)
            assert result is None
        except Exception:
            pytest.fail("convert_bone_name raised on weird input")


# ── convert_pose ──────────────────────────────────────────────────────────────

class TestConvertPose:
    def _make_transform(self, val: float = 1.0):
        return {"pos": [val, val, val], "rot": [0.0, 0.0, 0.0, 1.0]}

    def test_mixamo_pose_known_bones_appear(self):
        pose = {
            "Hips":        self._make_transform(1.0),
            "LeftArm":     self._make_transform(2.0),
            "RightForeArm": self._make_transform(3.0),
        }
        result = convert_pose(pose, BoneNameFormat.MIXAMO)
        assert "Pelvis"    in result
        assert "UpperArm_L" in result
        assert "LowerArm_R" in result

    def test_unknown_bones_dropped(self):
        pose = {
            "Hips":      self._make_transform(),
            "GhostBone": self._make_transform(),
            "FakePart":  self._make_transform(),
        }
        result = convert_pose(pose, BoneNameFormat.MIXAMO)
        assert "Pelvis"    in result
        assert "GhostBone" not in result
        assert "FakePart"  not in result

    def test_rigify_pose_conversion(self):
        pose = {
            "DEF-spine":     self._make_transform(),
            "DEF-thigh.L":  self._make_transform(),
            "DEF-hand.R":   self._make_transform(),
        }
        result = convert_pose(pose, BoneNameFormat.RIGIFY)
        assert "Pelvis"  in result
        assert "Thigh_L" in result
        assert "Hand_R"  in result

    def test_rokoko_pose_conversion(self):
        pose = {
            "Hip":       self._make_transform(),
            "LeftKnee":  self._make_transform(),
            "RightWrist": self._make_transform(),
        }
        result = convert_pose(pose, BoneNameFormat.ROKOKO)
        assert "Pelvis"  in result
        assert "Calf_L"  in result
        assert "Hand_R"  in result

    def test_pubcast_passthrough_keeps_valid(self):
        pose = {
            "Pelvis":      self._make_transform(),
            "Hand_L":      self._make_transform(),
            "NotABone":    self._make_transform(),
        }
        result = convert_pose(pose, BoneNameFormat.PUBCAST)
        assert "Pelvis"   in result
        assert "Hand_L"   in result
        assert "NotABone" not in result

    def test_empty_pose_returns_empty(self):
        for fmt in BoneNameFormat:
            assert convert_pose({}, fmt) == {}

    def test_transform_values_preserved(self):
        t = self._make_transform(7.5)
        pose = {"Hips": t}
        result = convert_pose(pose, BoneNameFormat.MIXAMO)
        assert result["Pelvis"] == t

    def test_does_not_raise_on_bad_input(self):
        try:
            convert_pose({"Hips": None}, BoneNameFormat.MIXAMO)
        except Exception:
            pytest.fail("convert_pose raised on None transform value")


# ── Full pose round-trips ─────────────────────────────────────────────────────

class TestRoundTrip:
    def _full_mixamo_pose(self):
        bones = [
            "Hips", "Spine", "Spine1", "Spine2", "Neck", "Head",
            "LeftShoulder", "LeftArm", "LeftForeArm", "LeftHand",
            "RightShoulder", "RightArm", "RightForeArm", "RightHand",
            "LeftUpLeg", "LeftLeg", "LeftFoot",
            "RightUpLeg", "RightLeg", "RightFoot",
        ]
        return {b: {"pos": [1.0, 2.0, 3.0], "rot": [0.0, 0.0, 0.0, 1.0]} for b in bones}

    def _full_rigify_pose(self):
        bones = [
            "DEF-spine", "DEF-spine.001", "DEF-spine.002", "DEF-neck", "DEF-head",
            "DEF-shoulder.L", "DEF-upper_arm.L", "DEF-forearm.L", "DEF-hand.L",
            "DEF-shoulder.R", "DEF-upper_arm.R", "DEF-forearm.R", "DEF-hand.R",
            "DEF-thigh.L", "DEF-shin.L", "DEF-foot.L",
            "DEF-thigh.R", "DEF-shin.R", "DEF-foot.R",
        ]
        return {b: {"pos": [0.0, 1.0, 0.0], "rot": [0.0, 0.0, 0.0, 1.0]} for b in bones}

    def _full_rokoko_pose(self):
        bones = [
            "Hip", "Stomach", "Chest", "Neck", "Head",
            "LeftShoulderBlade", "LeftShoulder", "LeftElbow", "LeftWrist",
            "RightShoulderBlade", "RightShoulder", "RightElbow", "RightWrist",
            "LeftHip", "LeftKnee", "LeftAnkle",
            "RightHip", "RightKnee", "RightAnkle",
        ]
        return {b: {"pos": [0.0, 0.0, 1.0], "rot": [0.0, 0.0, 0.0, 1.0]} for b in bones}

    def test_mixamo_round_trip(self):
        pose = self._full_mixamo_pose()
        result = convert_pose(pose, BoneNameFormat.MIXAMO)
        assert len(result) == len(pose)  # all bones have mappings
        for pubcast_name in result:
            assert pubcast_name in PUBCAST_BONES

    def test_rigify_round_trip(self):
        pose = self._full_rigify_pose()
        result = convert_pose(pose, BoneNameFormat.RIGIFY)
        assert len(result) == len(pose)
        for pubcast_name in result:
            assert pubcast_name in PUBCAST_BONES

    def test_rokoko_round_trip(self):
        pose = self._full_rokoko_pose()
        result = convert_pose(pose, BoneNameFormat.ROKOKO)
        assert len(result) == len(pose)
        for pubcast_name in result:
            assert pubcast_name in PUBCAST_BONES


# ── list_supported_bones ──────────────────────────────────────────────────────

class TestListSupportedBones:
    def test_mixamo_non_empty(self):
        bones = list_supported_bones(BoneNameFormat.MIXAMO)
        assert len(bones) > 0
        assert "Hips" in bones

    def test_rigify_non_empty(self):
        bones = list_supported_bones(BoneNameFormat.RIGIFY)
        assert len(bones) > 0
        assert "DEF-spine" in bones

    def test_rokoko_non_empty(self):
        bones = list_supported_bones(BoneNameFormat.ROKOKO)
        assert len(bones) > 0
        assert "Hip" in bones

    def test_pubcast_returns_all_canonical_bones(self):
        bones = list_supported_bones(BoneNameFormat.PUBCAST)
        assert len(bones) > 0
        assert "Pelvis" in bones
        assert "Hand_L" in bones
        assert "Spine_01" in bones
        assert set(bones) == PUBCAST_BONES

    def test_returns_list_type(self):
        for fmt in BoneNameFormat:
            result = list_supported_bones(fmt)
            assert isinstance(result, list)
