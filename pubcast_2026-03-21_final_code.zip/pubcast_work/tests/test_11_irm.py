"""tests/test_11_irm.py"""
import asyncio
import pytest
from modules.irm import IRMController


@pytest.fixture
def irm():
    return IRMController()


@pytest.fixture
def fast_irm():
    """IRM with rate=10/sec bucket for drain tests — token arrives in 0.1s."""
    ctrl = IRMController()
    ctrl._init_buckets({"fast": {"rate": 10, "per": 1.0}})
    return ctrl


class TestThrottleFullBucket:
    def test_full_bucket_completes_immediately(self, irm):
        async def run():
            irm.reset("llm_call")
            import time
            start = time.monotonic()
            await irm.throttle("llm_call")
            elapsed = time.monotonic() - start
            assert elapsed < 0.5, f"Should complete fast, took {elapsed:.3f}s"
        asyncio.run(run())

    def test_full_bucket_consumes_one_token(self, irm):
        irm.reset("ws_broadcast")
        before = irm.available("ws_broadcast")
        asyncio.run(irm.throttle("ws_broadcast"))
        after = irm.available("ws_broadcast")
        assert after < before or before == 0


class TestAvailable:
    def test_returns_integer(self, irm):
        result = irm.available("llm_call")
        assert isinstance(result, int)

    def test_full_after_reset(self, irm):
        irm.reset("llm_call")
        count = irm.available("llm_call")
        assert count == 20  # DEFAULT_LIMITS llm_call rate

    def test_decreases_after_throttle(self, irm):
        irm.reset("file_io")
        before = irm.available("file_io")
        asyncio.run(irm.throttle("file_io"))
        after = irm.available("file_io")
        assert after <= before

    def test_unknown_type_returns_int(self, irm):
        result = irm.available("totally_unknown_resource_xyz")
        assert isinstance(result, int)
        assert result >= 0


class TestReset:
    def test_reset_restores_full(self, irm):
        # Drain some tokens
        async def drain():
            for _ in range(5):
                await irm.throttle("file_io")
        asyncio.run(drain())
        irm.reset("file_io")
        count = irm.available("file_io")
        assert count == 100  # DEFAULT_LIMITS file_io rate

    def test_reset_unknown_type_does_not_raise(self, irm):
        try:
            irm.reset("nonexistent_resource")
        except Exception as e:
            pytest.fail(f"reset() raised on unknown resource: {e}")


class TestUnknownResourceType:
    def test_unknown_uses_defaults_no_raise(self, irm):
        async def run():
            await irm.throttle("completely_made_up_resource")
        try:
            asyncio.run(run())
        except Exception as e:
            pytest.fail(f"throttle() raised on unknown resource: {e}")

    def test_available_unknown_no_raise(self, irm):
        try:
            result = irm.available("another_unknown_xyz")
            assert isinstance(result, int)
        except Exception as e:
            pytest.fail(f"available() raised on unknown resource: {e}")


class TestDrainAndRefill:
    def test_drain_then_refill(self, fast_irm):
        """
        Use rate=10/per=1 bucket. Drain it completely.
        A new token arrives in ~0.1s. Confirm throttle() eventually returns
        and available() is less than full capacity (meaning we waited for a
        real token, not just the 5s timeout escape hatch).
        """
        async def run():
            import time
            fast_irm.reset("fast")
            # Drain all 10 tokens
            for _ in range(10):
                await fast_irm.throttle("fast")
            assert fast_irm.available("fast") == 0

            # Now throttle — should wait ~0.1s for a new token
            start = time.monotonic()
            await fast_irm.throttle("fast")
            elapsed = time.monotonic() - start

            # Should have waited at least a tiny bit, definitely not 5s
            assert elapsed < 2.0, f"Waited too long: {elapsed:.3f}s (suggests broken throttle)"

        asyncio.run(run())

    def test_after_refill_available_increases(self, fast_irm):
        async def run():
            import time
            fast_irm.reset("fast")
            for _ in range(10):
                await fast_irm.throttle("fast")
            assert fast_irm.available("fast") == 0
            # Wait for refill
            await asyncio.sleep(0.15)
            count = fast_irm.available("fast")
            assert count >= 1, "Bucket should have refilled at least 1 token"
        asyncio.run(run())


class TestConcurrentThrottle:
    def test_concurrent_calls_no_double_consume(self, irm):
        """Two concurrent throttle calls should consume exactly 2 tokens."""
        async def run():
            irm.reset("llm_call")
            before = irm.available("llm_call")
            await asyncio.gather(
                irm.throttle("llm_call"),
                irm.throttle("llm_call"),
            )
            after = irm.available("llm_call")
            consumed = before - after
            # Should consume exactly 2, not 1 (double-consume) or 3+
            assert consumed >= 2, f"Expected >= 2 tokens consumed, got {consumed}"
            assert consumed <= 3, f"Consumed too many tokens: {consumed}"
        asyncio.run(run())
