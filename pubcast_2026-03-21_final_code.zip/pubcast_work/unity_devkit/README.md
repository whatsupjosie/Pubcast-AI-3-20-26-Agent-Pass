# PubCast AI — Unity Devkit

## Scripts

| File | Purpose |
|------|---------|
| `PubCastBridge.cs` | **Start here.** WebSocket bridge client. Connects to PubCast AI, syncs WorldBrain state, routes EventBus events bidirectionally. |
| `WorldBrain.cs` | Singleton key-value state store. PubCastBridge auto-applies server state to it. |
| `EventBus.cs` | Simple pub/sub event system. PubCastBridge triggers remote events into it. |
| `Interactable.cs` | Abstract base for all interactive objects. |
| `PlayerInteractor.cs` | Raycast-based E-key interaction. |
| `BarkDoor.cs` | Dog bark interactable — bridges DogBarked event to PubCast. |
| `Jukebox.cs` | Music toggle — bridges MusicStarted/MusicStopped to PubCast. |
| `StageShowController.cs` | Responds to ShowStarted/ShowEnded from PubCast. |

## Setup (5 minutes)

**1. Install NativeWebSocket**
Window → Package Manager → + → Add package from git URL:
```
https://github.com/endel/NativeWebSocket.git#upm
```

**2. Add PubCastBridge to your scene**
- Create an empty GameObject named `PubCastManager`
- Add PubCastBridge.cs component
- Set Server URL: `ws://YOUR_SERVER:8000/ws/unity`
- Set Scene Name: your Unity scene name

**3. Wire your existing scripts**
In any script that calls `EventBus.Trigger("SomeEvent")` and you want PubCast to know about it:
```csharp
// Add to the same place you call EventBus.Trigger:
PubCastBridge.Instance.SendEvent("SomeEvent");
```

Or subscribe at Start():
```csharp
EventBus.Subscribe("MusicStarted", () => PubCastBridge.Instance.BridgeEvent("MusicStarted"));
```

**4. Press Play** — bridge connects automatically and syncs WorldBrain state on connect.

## Event Reference

### PubCast → Unity (server fires these into EventBus)
| Event | Trigger |
|-------|---------|
| `ShowStarted` | Recording session started |
| `ShowEnded` | Recording session stopped |
| `CameraChanged` | Program camera cut |
| `LightingChanged` | Lighting preset applied |
| `AvatarChanged` | User changed avatar |
| `ProductionStateChanged` | Any production state update |

### Unity → PubCast (call SendEvent or BridgeEvent)
| Event | What PubCast does |
|-------|-----------------|
| `MusicStarted` | Broadcasts to all hub rooms |
| `MusicStopped` | Broadcasts to all hub rooms |
| `DogBarked` | Broadcasts to all hub rooms |
| `PlayerEnteredRoom` | Logs room_enter with CurrentRoom WorldBrain state |
| Any string | Forwarded as unity_event to all WebSocket clients |

## WorldBrain State Sync

State set on the server auto-applies to WorldBrain.Instance on all connected Unity clients:
```csharp
// Read server state:
bool isOnAir = WorldBrain.Instance.GetBool("IsOnAir");
string preset = WorldBrain.Instance.GetString("LightingPreset");

// Push local state to server (syncs to all other Unity clients):
PubCastBridge.Instance.SetState("CurrentRoom", "Bar");
PubCastBridge.Instance.SetState("PlayerScore", 42);
```

## API Endpoints
```
WS  /ws/unity              — Unity WebSocket connection
GET /api/unity/status      — Bridge connection status + WorldBrain snapshot
GET /api/unity/world-brain — Full WorldBrain state snapshot
POST /api/unity/event      — Inject an event from HTTP (testing/automation)
```
