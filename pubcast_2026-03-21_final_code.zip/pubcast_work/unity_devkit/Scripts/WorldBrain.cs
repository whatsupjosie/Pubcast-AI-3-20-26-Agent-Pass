using System.Collections.Generic;
using UnityEngine;

public class WorldBrain : MonoBehaviour
{
    public static WorldBrain Instance;

    Dictionary<string, bool> boolStates = new Dictionary<string, bool>();
    Dictionary<string, int> intStates = new Dictionary<string, int>();
    Dictionary<string, float> floatStates = new Dictionary<string, float>();
    Dictionary<string, string> stringStates = new Dictionary<string, string>();

    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    public void SetBool(string key, bool value) => boolStates[key] = value;
    public bool GetBool(string key) => boolStates.ContainsKey(key) ? boolStates[key] : false;

    public void SetInt(string key, int value) => intStates[key] = value;
    public int GetInt(string key) => intStates.ContainsKey(key) ? intStates[key] : 0;

    public void SetFloat(string key, float value) => floatStates[key] = value;
    public float GetFloat(string key) => floatStates.ContainsKey(key) ? floatStates[key] : 0f;

    public void SetString(string key, string value) => stringStates[key] = value;
    public string GetString(string key) => stringStates.ContainsKey(key) ? stringStates[key] : "";
}