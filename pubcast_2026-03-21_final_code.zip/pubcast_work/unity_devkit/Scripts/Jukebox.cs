using UnityEngine;

public class Jukebox : Interactable
{
    public AudioSource music;

    public override void Interact()
    {
        if (!music.isPlaying)
        {
            music.Play();
            EventBus.Trigger("MusicStarted");
        }
        else
        {
            music.Stop();
            EventBus.Trigger("MusicStopped");
        }
    }
}