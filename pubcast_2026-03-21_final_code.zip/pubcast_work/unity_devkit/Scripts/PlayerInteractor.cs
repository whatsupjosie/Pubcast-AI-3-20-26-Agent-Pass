using UnityEngine;

public class PlayerInteractor : MonoBehaviour
{
    public float range = 3f;
    public LayerMask interactLayer;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.E))
        {
            Ray ray = new Ray(Camera.main.transform.position, Camera.main.transform.forward);
            RaycastHit hit;

            if (Physics.Raycast(ray, out hit, range, interactLayer))
            {
                Interactable interactable = hit.collider.GetComponent<Interactable>();

                if (interactable != null)
                    interactable.Interact();
            }
        }
    }
}