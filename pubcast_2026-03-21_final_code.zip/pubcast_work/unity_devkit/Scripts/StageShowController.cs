using UnityEngine;

public class StageShowController : MonoBehaviour
{
    public Light stageLight;
    public AudioSource applause;

    void Start()
    {
        EventBus.Subscribe("ShowStarted", StartShow);
        EventBus.Subscribe("ShowEnded", EndShow);
    }

    void StartShow()
    {
        stageLight.enabled = true;
        applause.Play();
    }

    void EndShow()
    {
        stageLight.enabled = false;
    }
}