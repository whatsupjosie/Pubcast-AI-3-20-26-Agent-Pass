using UnityEngine;

public class BarkDoor : Interactable
{
    public AudioSource barkSound;

    public override void Interact()
    {
        if (!WorldBrain.Instance.GetBool("DogBarked"))
        {
            barkSound.Play();
            WorldBrain.Instance.SetBool("DogBarked", true);
            EventBus.Trigger("DogBarked");
        }
    }
}