using UnityEngine;

public abstract class Interactable : MonoBehaviour
{
    public string prompt = "Interact";

    public virtual void Interact()
    {
        Debug.Log("Interacted with " + gameObject.name);
    }
}