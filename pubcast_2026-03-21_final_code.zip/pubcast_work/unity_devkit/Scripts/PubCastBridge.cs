/*
 * PubCastBridge.cs — Unity ↔ PubCast AI WebSocket Bridge Client
 * =============================================================
 * Drop this MonoBehaviour into your scene (e.g. on a PubCastManager GameObject).
 * It connects to the PubCast AI server and syncs WorldBrain state and EventBus
 * events bidirectionally — no changes to your existing scripts required.
 *
 * Requirements:
 *   - Unity 2021.3+ (uses System.Net.WebSockets or NativeWebSocket package)
 *   - NativeWebSocket package recommended: https://github.com/endel/NativeWebSocket
 *     Install via Package Manager → Add package from git URL:
 *     https://github.com/endel/NativeWebSocket.git#upm
 *
 * Setup:
 *   1. Add PubCastBridge.cs to a persistent GameObject (DontDestroyOnLoad)
 *   2. Set serverUrl in Inspector: ws://YOUR_SERVER_IP:8000/ws/unity
 *   3. Press Play — bridge connects automatically
 *
 * How it works:
 *   - All EventBus.Trigger() calls you want bridged: call
 *       PubCastBridge.Instance.SendEvent("EventName")
 *     or hook BridgeEvent() into your existing EventBus subscriptions.
 *   - WorldBrain state changes from the server auto-apply to WorldBrain.Instance.
 *   - PubCast production events (ShowStarted, ShowEnded, CameraChanged, etc.)
 *     fire into your local EventBus automatically.
 */

using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using NativeWebSocket;

[RequireComponent(typeof(DontDestroyOnLoad))]
public class PubCastBridge : MonoBehaviour
{
    // ── Inspector ─────────────────────────────────────────────────────────────
    [Header("Connection")]
    [Tooltip("PubCast AI WebSocket URL — e.g. ws://localhost:8000/ws/unity")]
    public string serverUrl = "ws://localhost:8000/ws/unity";

    [Tooltip("Scene name to report to PubCast on connect")]
    public string sceneName = "PubCastWorld";

    [Tooltip("Seconds between reconnect attempts after disconnect")]
    public float reconnectDelay = 3f;

    [Tooltip("Log all sent/received frames to console")]
    public bool verboseLogging = false;

    // ── Singleton ─────────────────────────────────────────────────────────────
    public static PubCastBridge Instance { get; private set; }

    // ── State ─────────────────────────────────────────────────────────────────
    private WebSocket _ws;
    private bool      _shouldReconnect = true;
    private string    _clientId;

    // Queue of events to send (filled from any thread, drained on main thread)
    private readonly Queue<string> _outboundQueue = new Queue<string>();
    private readonly object        _queueLock     = new object();

    public bool IsConnected => _ws != null && _ws.State == WebSocketState.Open;

    // ── Unity lifecycle ───────────────────────────────────────────────────────

    void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
        DontDestroyOnLoad(gameObject);
        _clientId = $"unity-{SystemInfo.deviceUniqueIdentifier.Substring(0, 8)}";
    }

    void Start()
    {
        StartCoroutine(ConnectLoop());
    }

    void Update()
    {
#if !UNITY_WEBGL || UNITY_EDITOR
        _ws?.DispatchMessageQueue();
#endif
        // Drain outbound queue on main thread
        lock (_queueLock)
        {
            while (_outboundQueue.Count > 0 && IsConnected)
            {
                var json = _outboundQueue.Dequeue();
                _ = _ws.SendText(json);
            }
        }
    }

    void OnDestroy()
    {
        _shouldReconnect = false;
        _ws?.Close();
    }

    // ── Connection loop ───────────────────────────────────────────────────────

    private IEnumerator ConnectLoop()
    {
        while (_shouldReconnect)
        {
            yield return ConnectOnce();
            if (_shouldReconnect)
            {
                Debug.Log($"[PubCastBridge] Reconnecting in {reconnectDelay}s…");
                yield return new WaitForSeconds(reconnectDelay);
            }
        }
    }

    private IEnumerator ConnectOnce()
    {
        _ws = new WebSocket(serverUrl);

        _ws.OnOpen += () =>
        {
            Debug.Log("[PubCastBridge] Connected to " + serverUrl);
            // Introduce ourselves
            SendRaw(new Dictionary<string, object>
            {
                ["type"]      = "hello",
                ["client_id"] = _clientId,
                ["scene"]     = sceneName,
            });
        };

        _ws.OnMessage += (bytes) =>
        {
            var text = Encoding.UTF8.GetString(bytes);
            if (verboseLogging) Debug.Log("[PubCastBridge] ← " + text);
            try   { HandleMessage(text); }
            catch (Exception ex) { Debug.LogWarning("[PubCastBridge] Parse error: " + ex.Message); }
        };

        _ws.OnError += (err) =>
        {
            Debug.LogWarning("[PubCastBridge] Error: " + err);
        };

        _ws.OnClose += (code) =>
        {
            Debug.Log("[PubCastBridge] Disconnected (code " + code + ")");
        };

        // Start connecting
        var connectTask = _ws.Connect();

        // Wait for connection to open or fail (max 10s)
        float elapsed = 0f;
        while (_ws.State == WebSocketState.Connecting && elapsed < 10f)
        {
            elapsed += Time.deltaTime;
            yield return null;
        }

        if (_ws.State != WebSocketState.Open)
        {
            Debug.LogWarning("[PubCastBridge] Failed to connect.");
            yield break;
        }

        // Keep alive until disconnect
        while (_ws.State == WebSocketState.Open)
            yield return new WaitForSeconds(0.05f);
    }

    // ── Inbound message handler ───────────────────────────────────────────────

    private void HandleMessage(string text)
    {
        var msg = MiniJSON.Deserialize(text) as Dictionary<string, object>;
        if (msg == null) return;

        var mtype = msg.ContainsKey("type") ? msg["type"].ToString() : "";

        switch (mtype)
        {
            case "state_sync":
                // Full WorldBrain state dump on connect
                if (msg.ContainsKey("state") && msg["state"] is Dictionary<string, object> stateDict)
                    ApplyStateDict(stateDict);
                break;

            case "state_set":
                ApplySingleState(msg);
                break;

            case "event":
                // Server is triggering an EventBus event in our Unity world
                if (msg.ContainsKey("name"))
                {
                    var evtName = msg["name"].ToString();
                    if (verboseLogging) Debug.Log("[PubCastBridge] Remote event: " + evtName);
                    EventBus.Trigger(evtName);
                }
                break;

            case "ping":
                SendRaw(new Dictionary<string, object> { ["type"] = "pong" });
                break;

            case "pong":
                break;

            case "ack":
                break;

            case "error":
                var errMsg = msg.ContainsKey("message") ? msg["message"].ToString() : "unknown";
                Debug.LogWarning("[PubCastBridge] Server error: " + errMsg);
                break;
        }
    }

    private void ApplyStateDict(Dictionary<string, object> stateDict)
    {
        foreach (var kv in stateDict)
        {
            if (kv.Value is Dictionary<string, object> entry)
                ApplySingleStateEntry(kv.Key, entry);
        }
    }

    private void ApplySingleState(Dictionary<string, object> msg)
    {
        var key   = msg.ContainsKey("key")   ? msg["key"].ToString()   : "";
        var dtype = msg.ContainsKey("dtype") ? msg["dtype"].ToString() : "string";
        var value = msg.ContainsKey("value") ? msg["value"]            : null;
        if (string.IsNullOrEmpty(key) || value == null) return;

        ApplySingleStateEntry(key, new Dictionary<string, object>
            { ["dtype"] = dtype, ["value"] = value });
    }

    private void ApplySingleStateEntry(string key, Dictionary<string, object> entry)
    {
        if (!entry.ContainsKey("dtype") || !entry.ContainsKey("value")) return;
        var dtype = entry["dtype"].ToString();
        var value = entry["value"];

        // Null guard
        if (WorldBrain.Instance == null) return;

        switch (dtype)
        {
            case "bool":
                WorldBrain.Instance.SetBool(key, Convert.ToBoolean(value));
                break;
            case "int":
                WorldBrain.Instance.SetInt(key, Convert.ToInt32(value));
                break;
            case "float":
                WorldBrain.Instance.SetFloat(key, Convert.ToSingle(value));
                break;
            default:
                WorldBrain.Instance.SetString(key, value.ToString());
                break;
        }

        if (verboseLogging)
            Debug.Log($"[PubCastBridge] WorldBrain.Set {dtype} {key} = {value}");
    }

    // ── Outbound API ──────────────────────────────────────────────────────────

    /// <summary>
    /// Forward an EventBus event name to PubCast AI.
    /// Call this from your existing scripts or EventBus subscriptions.
    /// Example: PubCastBridge.Instance.SendEvent("MusicStarted");
    /// </summary>
    public void SendEvent(string eventName, Dictionary<string, object> payload = null)
    {
        var frame = new Dictionary<string, object>
        {
            ["type"] = "event",
            ["name"] = eventName,
        };
        if (payload != null)
            frame["payload"] = payload;
        Enqueue(frame);
    }

    /// <summary>
    /// Push a WorldBrain state value to the PubCast server.
    /// Server will sync it to all other connected Unity clients.
    /// </summary>
    public void SetState(string key, bool value)   => Enqueue(MakeStateSet(key, "bool",   value));
    public void SetState(string key, int value)    => Enqueue(MakeStateSet(key, "int",    value));
    public void SetState(string key, float value)  => Enqueue(MakeStateSet(key, "float",  value));
    public void SetState(string key, string value) => Enqueue(MakeStateSet(key, "string", value));

    private static Dictionary<string, object> MakeStateSet(string key, string dtype, object value)
        => new Dictionary<string, object>
           { ["type"] = "state_set", ["key"] = key, ["dtype"] = dtype, ["value"] = value };

    private void Enqueue(Dictionary<string, object> frame)
    {
        var json = MiniJSON.Serialize(frame);
        if (verboseLogging) Debug.Log("[PubCastBridge] → " + json);
        lock (_queueLock)
            _outboundQueue.Enqueue(json);
    }

    private void SendRaw(Dictionary<string, object> frame)
    {
        var json = MiniJSON.Serialize(frame);
        if (IsConnected)
            _ = _ws.SendText(json);
    }

    // ── Convenience hook for existing EventBus subscribers ───────────────────

    /// <summary>
    /// Subscribe this to EventBus events you want mirrored to PubCast.
    /// Example in Start(): EventBus.Subscribe("DogBarked", () => BridgeEvent("DogBarked"));
    /// </summary>
    public void BridgeEvent(string eventName)
        => SendEvent(eventName);
}
