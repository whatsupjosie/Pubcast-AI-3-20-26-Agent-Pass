/**
 * PubCast AI — bots.js
 * AI co-host management panel.
 * Self-contained. Inject into any page via <script src="/static/bots.js">
 * then call BotsPanel.mount(containerEl).
 */

(function (root) {
  'use strict';

  // ── Provider catalogue ────────────────────────────────────────────────────

  const PROVIDER_MODELS = {
    openai: [
      { value: 'gpt-4o',      label: 'GPT-4o' },
      { value: 'gpt-4o-mini', label: 'GPT-4o mini' },
      { value: 'gpt-4-turbo', label: 'GPT-4 Turbo' },
      { value: 'o1-mini',     label: 'o1-mini' },
    ],
    gemini: [
      { value: 'gemini-1.5-pro',   label: 'Gemini 1.5 Pro' },
      { value: 'gemini-1.5-flash', label: 'Gemini 1.5 Flash' },
      { value: 'gemini-pro',       label: 'Gemini Pro' },
    ],
  };

  const DEFAULT_ENV = { openai: 'OPENAI_API_KEY', gemini: 'GEMINI_API_KEY' };
  const PROVIDER_COLOR = { openai: '#7b68ee', gemini: '#3ddad7' };
  const PROVIDER_INITIAL = { openai: 'AI', gemini: 'G' };
  const POLL_MS = 8000;

  // ── CSS ───────────────────────────────────────────────────────────────────

  const CSS = `
.bp-wrap{--g:#c9a84c;--gd:rgba(201,168,76,.18);--gb:rgba(201,168,76,.28);
  --n:#0d0d0b;--s1:#141410;--s2:#1a1915;--s3:#222018;
  --tc:rgba(201,168,76,.9);--tw:#e8e0cc;--tm:rgba(201,168,76,.38);
  --mono:'DM Mono','Courier Prime',monospace;--sans:'DM Sans',system-ui,sans-serif;
  font-family:var(--sans);color:var(--tw);}
.bp-header{display:flex;align-items:center;justify-content:space-between;
  padding:0 0 1.2rem;border-bottom:1px solid var(--gb);margin-bottom:1.4rem;}
.bp-title{font-family:var(--mono);font-size:.7rem;letter-spacing:.3em;
  text-transform:uppercase;color:var(--tm);}
.bp-title b{display:block;font-family:var(--sans);font-size:1.1rem;
  letter-spacing:.02em;font-weight:500;color:var(--tw);margin-top:2px;}
.bp-add{font-family:var(--mono);font-size:.68rem;letter-spacing:.2em;
  text-transform:uppercase;color:var(--g);background:var(--gd);
  border:1px solid var(--gb);border-radius:4px;padding:.5rem 1.1rem;
  cursor:pointer;transition:all .2s;}
.bp-add:hover{background:rgba(201,168,76,.28);border-color:var(--g);}
.bp-empty{text-align:center;padding:4rem 2rem;font-family:var(--mono);
  font-size:.78rem;letter-spacing:.15em;color:var(--tm);}
.bp-empty-icon{font-size:2.4rem;display:block;margin-bottom:1rem;opacity:.4;}
.bp-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(290px,1fr));gap:1rem;}
.bp-card{background:var(--s2);border:1px solid var(--gb);border-radius:4px;
  padding:1.1rem 1.2rem 1rem;transition:border-color .2s,box-shadow .2s;}
.bp-card:hover{border-color:rgba(201,168,76,.5);box-shadow:0 2px 18px rgba(0,0,0,.4);}
.bp-card.busy{border-color:var(--g);box-shadow:0 0 10px rgba(201,168,76,.12);}
.bp-head{display:flex;align-items:flex-start;gap:.75rem;margin-bottom:.8rem;}
.bp-av{width:36px;height:36px;border-radius:50%;display:flex;align-items:center;
  justify-content:center;font-family:var(--mono);font-size:.85rem;font-weight:500;
  flex-shrink:0;border:1px solid rgba(255,255,255,.1);}
.bp-info{flex:1;min-width:0;}
.bp-name{font-size:1rem;font-weight:500;color:var(--tw);line-height:1.2;
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.bp-badge{font-family:var(--mono);font-size:.6rem;letter-spacing:.16em;
  text-transform:uppercase;padding:1px 7px;border-radius:20px;
  border:1px solid currentColor;opacity:.7;margin-top:3px;display:inline-block;}
.bp-dot{width:7px;height:7px;border-radius:50%;background:rgba(201,168,76,.25);
  margin-left:auto;margin-top:4px;flex-shrink:0;transition:background .4s;}
.bp-dot.busy{background:var(--g);box-shadow:0 0 6px var(--g);
  animation:bpdot 1.2s ease-in-out infinite;}
@keyframes bpdot{0%,100%{box-shadow:0 0 0 0 rgba(201,168,76,.5);}
  50%{box-shadow:0 0 0 4px rgba(201,168,76,0);}}
.bp-model{font-family:var(--mono);font-size:.7rem;color:var(--tm);
  margin-bottom:.5rem;letter-spacing:.08em;}
.bp-rooms{display:flex;flex-wrap:wrap;gap:4px;margin-bottom:.6rem;}
.bp-room{font-family:var(--mono);font-size:.6rem;letter-spacing:.12em;
  color:var(--tm);background:rgba(201,168,76,.07);
  border:1px solid rgba(201,168,76,.15);border-radius:2px;padding:1px 7px;}
.bp-noroom{font-family:var(--mono);font-size:.6rem;color:rgba(201,168,76,.2);
  font-style:italic;letter-spacing:.1em;}
.bp-flags{display:flex;gap:.4rem;flex-wrap:wrap;margin-bottom:.8rem;}
.bp-flag{font-family:var(--mono);font-size:.58rem;letter-spacing:.14em;
  text-transform:uppercase;padding:1px 6px;border-radius:2px;
  border:1px solid rgba(201,168,76,.15);color:rgba(201,168,76,.35);}
.bp-flag.on{border-color:rgba(201,168,76,.4);color:rgba(201,168,76,.8);
  background:rgba(201,168,76,.06);}
.bp-actions{display:flex;gap:.5rem;border-top:1px solid rgba(201,168,76,.1);
  padding-top:.7rem;}
.bp-btn{font-family:var(--mono);font-size:.63rem;letter-spacing:.18em;
  text-transform:uppercase;background:transparent;
  border:1px solid rgba(201,168,76,.18);border-radius:3px;
  color:rgba(201,168,76,.5);padding:.3rem .6rem;cursor:pointer;
  transition:all .18s;flex:1;}
.bp-btn:hover{color:var(--g);border-color:rgba(201,168,76,.5);background:var(--gd);}
.bp-btn.del:hover{color:#e05555;border-color:rgba(224,85,85,.4);
  background:rgba(224,85,85,.08);}
.bp-btn.nudge:hover{color:var(--g);border-color:var(--g);
  box-shadow:0 0 8px rgba(201,168,76,.15);}
.bp-btn:disabled{opacity:.3;cursor:not-allowed;}
/* ── modal ── */
.bp-overlay{position:fixed;inset:0;z-index:1000;background:rgba(0,0,0,.72);
  display:flex;align-items:center;justify-content:center;padding:1rem;
  backdrop-filter:blur(3px);animation:bpfade .18s ease;}
@keyframes bpfade{from{opacity:0;}to{opacity:1;}}
.bp-modal{background:#141410;border:1px solid var(--gb);border-radius:4px;
  width:100%;max-width:540px;max-height:90vh;overflow-y:auto;
  box-shadow:0 24px 80px rgba(0,0,0,.7);animation:bpslide .2s ease;}
@keyframes bpslide{from{transform:translateY(-14px);opacity:0;}
  to{transform:translateY(0);opacity:1;}}
.bp-mhead{padding:1.3rem 1.5rem 1rem;border-bottom:1px solid var(--gb);
  display:flex;align-items:center;justify-content:space-between;}
.bp-mtitle{font-family:var(--mono);font-size:.68rem;letter-spacing:.26em;
  text-transform:uppercase;color:var(--tm);}
.bp-mtitle b{display:block;font-family:var(--sans);font-size:1.1rem;
  letter-spacing:.02em;color:var(--tw);margin-top:2px;font-weight:500;}
.bp-mclose{background:transparent;border:none;color:var(--tm);
  font-size:1.2rem;cursor:pointer;padding:.2rem .4rem;border-radius:3px;
  transition:color .15s;line-height:1;}
.bp-mclose:hover{color:var(--g);}
.bp-mbody{padding:1.3rem 1.5rem;}
.bp-field{margin-bottom:.95rem;}
.bp-field label{display:block;font-family:var(--mono);font-size:.65rem;
  letter-spacing:.2em;text-transform:uppercase;color:var(--tm);margin-bottom:.3rem;}
.bp-field label em{font-style:normal;color:rgba(201,168,76,.25);
  font-size:.58rem;margin-left:.4rem;}
.bp-field input,.bp-field select,.bp-field textarea{width:100%;
  background:#0d0d0b;border:1px solid var(--gb);border-radius:3px;
  color:var(--tw);font-family:var(--mono);font-size:.82rem;
  padding:.48rem .7rem;outline:none;transition:border-color .15s,box-shadow .15s;}
.bp-field input:focus,.bp-field select:focus,.bp-field textarea:focus{
  border-color:rgba(201,168,76,.6);box-shadow:0 0 0 2px rgba(201,168,76,.08);}
.bp-field textarea{resize:vertical;min-height:72px;line-height:1.5;}
.bp-field select option{background:#141410;}
.bp-row{display:grid;grid-template-columns:1fr 1fr;gap:.7rem;}
.bp-range-row{display:flex;align-items:center;gap:.7rem;}
.bp-range-row input[type=range]{flex:1;-webkit-appearance:none;height:3px;
  background:linear-gradient(90deg,var(--g) var(--pct,85%),rgba(201,168,76,.15) var(--pct,85%));
  border:none;border-radius:2px;padding:0;}
.bp-range-row input[type=range]::-webkit-slider-thumb{-webkit-appearance:none;
  width:13px;height:13px;border-radius:50%;background:var(--g);cursor:pointer;
  border:2px solid #0d0d0b;box-shadow:0 0 5px rgba(201,168,76,.4);}
.bp-rval{font-family:var(--mono);font-size:.78rem;color:var(--g);min-width:2.4rem;text-align:right;}
.bp-toggles{display:grid;grid-template-columns:repeat(3,1fr);gap:.45rem;margin-bottom:.95rem;}
.bp-toggle{display:flex;flex-direction:column;align-items:center;gap:.3rem;
  padding:.6rem .4rem;border:1px solid rgba(201,168,76,.15);border-radius:3px;
  cursor:pointer;background:transparent;transition:all .2s;user-select:none;}
.bp-toggle.on{border-color:rgba(201,168,76,.5);background:var(--gd);}
.bp-toggle-lbl{font-family:var(--mono);font-size:.58rem;letter-spacing:.14em;
  text-transform:uppercase;color:rgba(201,168,76,.4);transition:color .2s;}
.bp-toggle.on .bp-toggle-lbl{color:var(--g);}
.bp-toggle-ico{font-size:.95rem;}
.bp-chips-wrap{display:flex;flex-wrap:wrap;gap:5px;padding:.45rem;
  background:#0d0d0b;border:1px solid var(--gb);border-radius:3px;
  min-height:40px;cursor:text;transition:border-color .15s;}
.bp-chips-wrap:focus-within{border-color:rgba(201,168,76,.6);
  box-shadow:0 0 0 2px rgba(201,168,76,.08);}
.bp-chip{display:flex;align-items:center;gap:4px;background:rgba(201,168,76,.12);
  border:1px solid rgba(201,168,76,.25);border-radius:2px;
  padding:1px 8px;font-family:var(--mono);font-size:.7rem;color:var(--g);}
.bp-chip-del{cursor:pointer;opacity:.5;font-size:.78rem;line-height:1;
  background:none;border:none;color:inherit;padding:0;}
.bp-chip-del:hover{opacity:1;}
.bp-chips-wrap input{background:transparent;border:none;outline:none;
  color:var(--tw);font-family:var(--mono);font-size:.78rem;
  padding:1px 2px;min-width:70px;flex:1;}
.bp-suggests{display:flex;flex-wrap:wrap;gap:4px;margin-top:.35rem;}
.bp-sugg{font-family:var(--mono);font-size:.58rem;letter-spacing:.1em;
  color:rgba(201,168,76,.38);border:1px solid rgba(201,168,76,.15);
  border-radius:2px;padding:1px 6px;cursor:pointer;background:transparent;transition:all .15s;}
.bp-sugg:hover{color:var(--g);border-color:rgba(201,168,76,.4);background:var(--gd);}
.bp-divider{border:none;border-top:1px solid rgba(201,168,76,.1);margin:1.1rem 0;}
.bp-mfoot{display:flex;justify-content:flex-end;gap:.55rem;
  padding:.9rem 1.5rem 1.3rem;border-top:1px solid rgba(201,168,76,.1);}
.bp-cancel{font-family:var(--mono);font-size:.65rem;letter-spacing:.2em;
  text-transform:uppercase;background:transparent;
  border:1px solid rgba(201,168,76,.2);border-radius:3px;
  color:rgba(201,168,76,.4);padding:.42rem 1rem;cursor:pointer;transition:all .18s;}
.bp-cancel:hover{color:var(--g);border-color:var(--gb);}
.bp-save{font-family:var(--mono);font-size:.65rem;letter-spacing:.2em;
  text-transform:uppercase;background:var(--gd);
  border:1px solid rgba(201,168,76,.55);border-radius:3px;
  color:var(--g);padding:.42rem 1.3rem;cursor:pointer;transition:all .18s;}
.bp-save:hover{background:rgba(201,168,76,.28);border-color:var(--g);}
.bp-save:disabled{opacity:.4;cursor:not-allowed;}
.bp-err{font-family:var(--mono);font-size:.7rem;color:#e05555;
  background:rgba(224,85,85,.08);border:1px solid rgba(224,85,85,.25);
  border-radius:3px;padding:.45rem .75rem;margin-bottom:.75rem;}
`;

  // ── Helpers ───────────────────────────────────────────────────────────────

  function injectCSS() {
    if (document.getElementById('_bots_css')) return;
    const s = document.createElement('style');
    s.id = '_bots_css';
    s.textContent = CSS;
    document.head.appendChild(s);
  }

  function h(tag, attrs, ...kids) {
    const el = document.createElement(tag);
    if (attrs) Object.entries(attrs).forEach(([k, v]) => {
      if (k === 'cls') el.className = v;
      else if (k.startsWith('on')) el.addEventListener(k.slice(2).toLowerCase(), v);
      else el.setAttribute(k, v);
    });
    kids.forEach(k => {
      if (k == null) return;
      el.appendChild(typeof k === 'string' ? document.createTextNode(k) : k);
    });
    return el;
  }

  function uid() {
    return 'bot-' + Math.random().toString(36).slice(2, 10);
  }

  function initials(name) {
    return (name || '?').split(/\s+/).map(w => w[0]).join('').toUpperCase().slice(0, 2);
  }

  // ── API ───────────────────────────────────────────────────────────────────

  async function api(path, opts = {}) {
    const r = await fetch(path, {
      headers: { 'Content-Type': 'application/json' },
      ...opts,
    });
    let body;
    try { body = await r.json(); } catch { body = {}; }
    if (!r.ok) throw new Error(body.error || `HTTP ${r.status}`);
    return body;
  }

  async function loadBots()           { return (await api('/api/bots')).bots || []; }
  async function saveBot(b, isNew)    {
    if (isNew) return api('/api/bots', { method: 'POST', body: JSON.stringify(b) });
    return api('/api/bots/' + b.bot_id, { method: 'PUT', body: JSON.stringify(b) });
  }
  async function deleteBot(id)        { return api('/api/bots/' + id, { method: 'DELETE' }); }
  async function nudgeBot(id, room, hint) {
    return api('/api/bots/' + id + '/nudge', {
      method: 'POST', body: JSON.stringify({ room, hint }),
    });
  }
  async function loadRooms() {
    try { return Object.keys((await api('/api/health')).ws_rooms || {}); }
    catch { return ['main']; }
  }

  // ── State ─────────────────────────────────────────────────────────────────

  let _container = null;
  let _bots = [];
  let _rooms = ['main'];
  let _timer = null;

  // ── Render ────────────────────────────────────────────────────────────────

  function render() {
    if (!_container) return;
    _container.innerHTML = '';
    const wrap = h('div', { cls: 'bp-wrap' });

    // Header
    const hd = h('div', { cls: 'bp-header' });
    const title = h('div', { cls: 'bp-title' }, 'AI Co-hosts');
    const boldName = document.createElement('b');
    boldName.textContent = 'Bot Management';
    title.appendChild(boldName);
    const addBtn = h('button', { cls: 'bp-add', onClick: () => openModal(null) }, '+ New Bot');
    hd.append(title, addBtn);
    wrap.appendChild(hd);

    if (_bots.length === 0) {
      const empty = h('div', { cls: 'bp-empty' });
      const icon = h('span', { cls: 'bp-empty-icon' }, '🤖');
      empty.appendChild(icon);
      empty.appendChild(document.createTextNode('No bots configured yet.'));
      empty.appendChild(h('br'));
      empty.appendChild(document.createTextNode('Add an AI co-host to bring the studio to life.'));
      wrap.appendChild(empty);
    } else {
      const grid = h('div', { cls: 'bp-grid' });
      _bots.forEach(b => grid.appendChild(renderCard(b)));
      wrap.appendChild(grid);
    }

    _container.appendChild(wrap);
  }

  function renderCard(b) {
    const color = PROVIDER_COLOR[b.provider] || '#888';
    const card = h('div', { cls: 'bp-card' });

    // Head row
    const head = h('div', { cls: 'bp-head' });
    const av = h('div', { cls: 'bp-av' }, initials(b.name));
    av.style.background = color + '22';
    av.style.color = color;
    const info = h('div', { cls: 'bp-info' });
    info.appendChild(h('div', { cls: 'bp-name' }, b.name));
    const badge = h('span', { cls: 'bp-badge' }, b.provider || '');
    badge.style.color = color;
    info.appendChild(badge);
    const dot = h('div', { cls: 'bp-dot' });
    head.append(av, info, dot);
    card.appendChild(head);

    // Model
    card.appendChild(h('div', { cls: 'bp-model' }, b.model || '—'));

    // Rooms
    const rooms = h('div', { cls: 'bp-rooms' });
    const roomList = Array.isArray(b.rooms) ? b.rooms : [];
    if (roomList.length === 0) {
      rooms.appendChild(h('span', { cls: 'bp-noroom' }, 'no rooms assigned'));
    } else {
      roomList.forEach(r => rooms.appendChild(h('span', { cls: 'bp-room' }, r)));
    }
    card.appendChild(rooms);

    // Flags
    const flags = h('div', { cls: 'bp-flags' });
    const flagDefs = [
      ['auto', b.auto_reply],
      ['mention', b.mention_only],
      ['shadow', b.shadow_presence],
    ];
    flagDefs.forEach(([lbl, on]) => {
      const f = h('span', { cls: 'bp-flag' + (on ? ' on' : '') }, lbl);
      flags.appendChild(f);
    });
    card.appendChild(flags);

    // Actions
    const actions = h('div', { cls: 'bp-actions' });
    const editBtn = h('button', { cls: 'bp-btn', onClick: () => openModal(b) }, 'Edit');
    const nudgeBtn = h('button', { cls: 'bp-btn nudge', onClick: () => doNudge(b, nudgeBtn) }, 'Nudge');
    if (!roomList.length) nudgeBtn.disabled = true;
    nudgeBtn.title = roomList.length ? 'Ask bot to speak' : 'Assign a room first';
    const delBtn = h('button', { cls: 'bp-btn del', onClick: () => confirmDelete(b) }, 'Delete');
    actions.append(editBtn, nudgeBtn, delBtn);
    card.appendChild(actions);

    return card;
  }

  async function doNudge(b, btn) {
    const room = Array.isArray(b.rooms) && b.rooms.length ? b.rooms[0] : null;
    if (!room) return;
    btn.disabled = true;
    btn.textContent = '…';
    try {
      await nudgeBot(b.bot_id, room, '');
      btn.textContent = '✓';
      setTimeout(() => { btn.textContent = 'Nudge'; btn.disabled = false; }, 1800);
    } catch (e) {
      btn.textContent = 'Err';
      setTimeout(() => { btn.textContent = 'Nudge'; btn.disabled = false; }, 2000);
    }
  }

  async function confirmDelete(b) {
    if (!confirm(`Delete "${b.name}"? This cannot be undone.`)) return;
    try {
      await deleteBot(b.bot_id);
      _bots = _bots.filter(x => x.bot_id !== b.bot_id);
      render();
    } catch (e) { alert('Delete failed: ' + e.message); }
  }

  // ── Modal ─────────────────────────────────────────────────────────────────

  function openModal(existing) {
    const isNew = !existing;
    const data = existing ? JSON.parse(JSON.stringify(existing)) : {
      bot_id: uid(),
      name: '',
      provider: 'openai',
      model: PROVIDER_MODELS.openai[0].value,
      api_key_env: DEFAULT_ENV.openai,
      rooms: [],
      system_prompt: '',
      auto_reply: true,
      mention_only: false,
      shadow_presence: true,
      max_history: 20,
      temperature: 0.85,
    };

    const overlay = h('div', { cls: 'bp-overlay', onClick: (e) => {
      if (e.target === overlay) closeModal(overlay);
    }});

    const modal = h('div', { cls: 'bp-modal' });

    // Header
    const mhead = h('div', { cls: 'bp-mhead' });
    const mtitle = h('div', { cls: 'bp-mtitle' }, isNew ? 'New Co-host' : 'Edit Co-host');
    const boldTitle = document.createElement('b');
    boldTitle.textContent = isNew ? 'Configure Bot' : data.name;
    mtitle.appendChild(boldTitle);
    const closeBtn = h('button', { cls: 'bp-mclose', onClick: () => closeModal(overlay) }, '✕');
    mhead.append(mtitle, closeBtn);
    modal.appendChild(mhead);

    // Body
    const mbody = h('div', { cls: 'bp-mbody' });
    const errBanner = h('div', { cls: 'bp-err', style: 'display:none' });
    mbody.appendChild(errBanner);

    function showErr(msg) {
      errBanner.textContent = msg;
      errBanner.style.display = '';
    }

    // Name
    const nameInput = h('input', { type: 'text', placeholder: 'e.g. Lumen', value: data.name || '' });
    const nameField = h('div', { cls: 'bp-field' });
    nameField.appendChild(h('label', {}, 'Display Name'));
    nameField.appendChild(nameInput);
    mbody.appendChild(nameField);

    // Provider + Model row
    const provField = h('div', { cls: 'bp-field' });
    provField.appendChild(h('label', {}, 'Provider'));
    const provSel = h('select', {});
    ['openai', 'gemini'].forEach(p => {
      const o = h('option', { value: p }, p === 'openai' ? 'OpenAI' : 'Google Gemini');
      if (data.provider === p) o.setAttribute('selected', '');
      provSel.appendChild(o);
    });
    provField.appendChild(provSel);

    const modelField = h('div', { cls: 'bp-field' });
    modelField.appendChild(h('label', {}, 'Model'));
    const modelSel = h('select', {});
    function rebuildModels(prov) {
      modelSel.innerHTML = '';
      (PROVIDER_MODELS[prov] || []).forEach(m => {
        const o = h('option', { value: m.value }, m.label);
        if (data.model === m.value) o.setAttribute('selected', '');
        modelSel.appendChild(o);
      });
    }
    rebuildModels(data.provider);
    modelField.appendChild(modelSel);

    provSel.addEventListener('change', () => {
      const prov = provSel.value;
      rebuildModels(prov);
      if (envInput.value === DEFAULT_ENV[data.provider] || !envInput.value) {
        envInput.value = DEFAULT_ENV[prov] || '';
      }
      data.provider = prov;
    });

    const provModelRow = h('div', { cls: 'bp-row' });
    provModelRow.append(provField, modelField);
    mbody.appendChild(provModelRow);

    // API key env var
    const envField = h('div', { cls: 'bp-field' });
    const envLabel = h('label', {}, 'API Key Env Var');
    const envNote = h('em', {}, '  env var name, not the key itself');
    envLabel.appendChild(envNote);
    const envInput = h('input', { type: 'text', placeholder: 'OPENAI_API_KEY', value: data.api_key_env || '' });
    envField.append(envLabel, envInput);
    mbody.appendChild(envField);

    // Rooms
    const roomsField = h('div', { cls: 'bp-field' });
    roomsField.appendChild(h('label', {}, 'Active Rooms'));
    const chipsWrap = h('div', { cls: 'bp-chips-wrap' });
    let roomList = Array.isArray(data.rooms) ? [...data.rooms] : [];

    function renderChips() {
      chipsWrap.innerHTML = '';
      roomList.forEach(r => {
        const chip = h('div', { cls: 'bp-chip' }, r);
        const del = h('button', { cls: 'bp-chip-del', onClick: () => {
          roomList = roomList.filter(x => x !== r);
          renderChips();
        }});
        del.textContent = '×';
        chip.appendChild(del);
        chipsWrap.appendChild(chip);
      });
      const inp = h('input', { type: 'text', placeholder: roomList.length ? '' : 'type room name…' });
      inp.addEventListener('keydown', (e) => {
        const val = inp.value.trim();
        if ((e.key === 'Enter' || e.key === ',') && val) {
          e.preventDefault();
          if (!roomList.includes(val)) roomList.push(val);
          renderChips();
        }
        if (e.key === 'Backspace' && !val && roomList.length) {
          roomList.pop();
          renderChips();
        }
      });
      chipsWrap.appendChild(inp);
      chipsWrap.addEventListener('click', () => inp.focus(), { once: true });
    }
    renderChips();
    roomsField.appendChild(chipsWrap);

    // Room suggestions
    const suggests = h('div', { cls: 'bp-suggests' });
    const knownRooms = [...new Set(['main', 'greenroom', 'bar', ..._rooms])];
    knownRooms.forEach(r => {
      const s = h('button', { cls: 'bp-sugg', onClick: () => {
        if (!roomList.includes(r)) { roomList.push(r); renderChips(); }
      }}, r);
      suggests.appendChild(s);
    });
    roomsField.appendChild(suggests);
    mbody.appendChild(roomsField);

    mbody.appendChild(h('hr', { cls: 'bp-divider' }));

    // System prompt
    const sysField = h('div', { cls: 'bp-field' });
    const sysLabel = h('label', {}, 'System Prompt');
    const sysNote = h('em', {}, '  optional');
    sysLabel.appendChild(sysNote);
    const sysTA = h('textarea', { placeholder: 'You are a witty AI co-host for PubCast…' });
    sysTA.value = data.system_prompt || '';
    sysField.append(sysLabel, sysTA);
    mbody.appendChild(sysField);

    // Behaviour toggles
    mbody.appendChild(h('label', { style: 'display:block;font-family:var(--mono);font-size:.65rem;letter-spacing:.2em;text-transform:uppercase;color:rgba(201,168,76,.38);margin-bottom:.5rem;' }, 'Behaviour'));
    const toggleData = [
      { key: 'auto_reply',      icon: '⚡', label: 'Auto Reply' },
      { key: 'mention_only',    icon: '@',  label: 'Mention Only' },
      { key: 'shadow_presence', icon: '👁', label: 'Shadow' },
    ];
    const toggles = h('div', { cls: 'bp-toggles' });
    toggleData.forEach(td => {
      const tog = h('div', { cls: 'bp-toggle' + (data[td.key] ? ' on' : '') });
      tog.appendChild(h('span', { cls: 'bp-toggle-ico' }, td.icon));
      tog.appendChild(h('span', { cls: 'bp-toggle-lbl' }, td.label));
      tog.addEventListener('click', () => {
        data[td.key] = !data[td.key];
        tog.classList.toggle('on', data[td.key]);
      });
      toggles.appendChild(tog);
    });
    mbody.appendChild(toggles);

    // Temperature
    const tempField = h('div', { cls: 'bp-field' });
    tempField.appendChild(h('label', {}, 'Temperature'));
    const tempRow = h('div', { cls: 'bp-range-row' });
    const tempInput = h('input', { type: 'range', min: '0', max: '1', step: '0.05', value: data.temperature || 0.85 });
    const tempVal = h('span', { cls: 'bp-rval' }, String(parseFloat(tempInput.value).toFixed(2)));
    function updateTempGrad() {
      const pct = (parseFloat(tempInput.value) * 100).toFixed(0) + '%';
      tempInput.style.setProperty('--pct', pct);
      tempVal.textContent = parseFloat(tempInput.value).toFixed(2);
    }
    updateTempGrad();
    tempInput.addEventListener('input', updateTempGrad);
    tempRow.append(tempInput, tempVal);
    tempField.appendChild(tempRow);
    mbody.appendChild(tempField);

    // History
    const histField = h('div', { cls: 'bp-field' });
    const histLabel = h('label', {}, 'Max History');
    const histNote = h('em', {}, '  messages of context');
    histLabel.appendChild(histNote);
    const histInput = h('input', { type: 'text', value: String(data.max_history || 20) });
    histField.append(histLabel, histInput);
    mbody.appendChild(histField);

    modal.appendChild(mbody);

    // Footer
    const mfoot = h('div', { cls: 'bp-mfoot' });
    const cancelBtn = h('button', { cls: 'bp-cancel', onClick: () => closeModal(overlay) }, 'Cancel');
    const saveBtn = h('button', { cls: 'bp-save' }, isNew ? 'Create Bot' : 'Save Changes');
    saveBtn.addEventListener('click', async () => {
      const name = nameInput.value.trim();
      if (!name) { showErr('Name is required.'); return; }
      const envVal = envInput.value.trim();
      if (!envVal) { showErr('API key env var is required.'); return; }
      saveBtn.disabled = true;
      saveBtn.textContent = 'Saving…';
      errBanner.style.display = 'none';
      const payload = {
        bot_id: data.bot_id,
        name,
        provider: provSel.value,
        model: modelSel.value,
        api_key_env: envVal,
        rooms: [...roomList],
        system_prompt: sysTA.value.trim(),
        auto_reply: data.auto_reply,
        mention_only: data.mention_only,
        shadow_presence: data.shadow_presence,
        temperature: parseFloat(tempInput.value),
        max_history: parseInt(histInput.value, 10) || 20,
      };
      try {
        await saveBot(payload, isNew);
        closeModal(overlay);
        await refresh();
      } catch (e) {
        showErr(e.message);
        saveBtn.disabled = false;
        saveBtn.textContent = isNew ? 'Create Bot' : 'Save Changes';
      }
    });
    mfoot.append(cancelBtn, saveBtn);
    modal.appendChild(mfoot);

    overlay.appendChild(modal);
    document.body.appendChild(overlay);
    setTimeout(() => nameInput.focus(), 80);
  }

  function closeModal(overlay) {
    overlay.style.animation = 'bpfade .15s ease reverse';
    setTimeout(() => overlay.remove(), 140);
  }

  // ── Poll ──────────────────────────────────────────────────────────────────

  async function refresh() {
    try { _bots = await loadBots(); } catch { _bots = []; }
    render();
  }

  function startPoll() {
    if (_timer) clearInterval(_timer);
    _timer = setInterval(refresh, POLL_MS);
  }

  function stopPoll() {
    if (_timer) { clearInterval(_timer); _timer = null; }
  }

  // ── Public API ────────────────────────────────────────────────────────────

  const BotsPanel = {
    async mount(container) {
      injectCSS();
      _container = container;
      _container.classList.add('bp-wrap');
      _rooms = await loadRooms();
      await refresh();
      startPoll();
    },
    unmount() {
      stopPoll();
      if (_container) _container.innerHTML = '';
    },
  };

  root.BotsPanel = BotsPanel;

}(window));
