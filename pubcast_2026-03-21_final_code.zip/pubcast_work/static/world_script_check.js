
'use strict';

// ══════════════════════════════════════════════════════
//  POLYFILL
// ══════════════════════════════════════════════════════
if (!CanvasRenderingContext2D.prototype.roundRect) {
  CanvasRenderingContext2D.prototype.roundRect = function(x,y,w,h,r){
    const rv=Math.min(Array.isArray(r)?r[0]:r||0,w/2,h/2);
    this.moveTo(x+rv,y);this.lineTo(x+w-rv,y);this.arcTo(x+w,y,x+w,y+rv,rv);
    this.lineTo(x+w,y+h-rv);this.arcTo(x+w,y+h,x+w-rv,y+h,rv);
    this.lineTo(x+rv,y+h);this.arcTo(x,y+h,x,y+h-rv,rv);
    this.lineTo(x,y+rv);this.arcTo(x,y,x+rv,y,rv);this.closePath();return this;
  };
}

// ══════════════════════════════════════════════════════
//  CURSOR
// ══════════════════════════════════════════════════════
const cur = document.getElementById('cur');
document.addEventListener('mousemove', e => { cur.style.left=e.clientX+'px'; cur.style.top=e.clientY+'px'; });
document.addEventListener('mouseover', e => {
  cur.classList.toggle('big', e.target.matches('.dr-btn,.door-glow,.feature,.feature-glow'));
});

// ══════════════════════════════════════════════════════
//  ROOM DEFINITIONS
// ══════════════════════════════════════════════════════
// Each room defines:
//   bg: image filename (relative)
//   bgPos: background-position
//   name: display name
//   walkY: bottom % where sprite walks
//   spriteScale: size of sprite in this room
//   mmDot: minimap dot position {cx,cy}
//   doors: array of door hotspot objects

const ROOMS = {

  lobby: {
    bg: '/assets/rooms/lobby_polish.jpg',
    bgPos: 'center 54%',
    name: 'THE LOBBY — GRAND ENTRY',
    subtitle: 'A faded movie-palace threshold with the whole 2.5D studio tucked deeper inside.',
    atlas: 'From here the route narrows into the backstage hallway, then opens out into the green room, dressing room, and set path.',
    routes: ['HALLWAY', 'GREEN ROOM', 'DRESSING ROUTE'],
    fx: 'lobby',
    walkY: 74,
    spriteScale: 1.0,
    mmDot: {cx:80, cy:11},
    features: [
      {
        id:'feature-plaque', label:'HOUSE PLAQUE', left:8, bottom:41, width:76, height:120,
        title:'HOUSE PLAQUE',
        body:'The lobby carries the rules of the house: pause, orient yourself, and only then move inward. It makes the whole studio feel like a hidden theater instead of a generic menu.'
      },
      {
        id:'feature-boxoffice', label:'BOX OFFICE', left:26, bottom:28, width:150, height:94,
        title:'BOX OFFICE',
        body:'A little relic station to suggest tickets, call-times, and arrivals. It turns the lobby into an actual threshold instead of just another hallway backdrop.'
      }
    ],
    doors: [
      {
        id:'door-hallway',
        label:'INTO THE HOUSE →',
        left:63, bottom:30,
        width:90, height:110,
        target:'hallway',
        prompt:'HEAD DEEPER INTO THE STUDIO — PRESS <span class="key">E</span> TO ENTER THE HALLWAY'
      }
    ]
  },

  hallway: {
    bg: '/assets/rooms/hallway_polish.jpg',
    bgPos: '73% 48%',
    bgSize: '168%',
    name: 'HALLWAY',
    subtitle: 'The tight turn between the public face of the building and the working backstage rooms.',
    atlas: 'Use the hallway to braid together the lobby, writers room, green room, and dressing flow.',
    routes: ['LOBBY', 'WRITERS', 'GREEN ROOM'],
    fx: 'hallway',
    walkY: 76,
    spriteScale: 0.85,
    mmDot: {cx:80, cy:22},
    doors: [
      {
        id:'door-lobby',
        label:'← LOBBY',
        left:10, bottom:20,
        width:60, height:80,
        target:'lobby',
        edge:'left'
      },
      {
        id:'door-writers',
        label:'WRITERS ROOM',
        left:35, bottom:24,
        width:55, height:75,
        target:'writers',
        facing:'right'
      },
      {
        id:'door-greenroom',
        label:'GREEN ROOM →',
        left:80, bottom:20,
        width:70, height:90,
        target:'greenroom',
        edge:'right'
      }
    ]
  },

  writers: {
    bg: '/assets/rooms/writers.jpg',
    bgPos: 'center 46%',
    bgSize: 'cover',
    name: 'WRITERS ROOM — STORY CIRCLE',
    subtitle: 'A soft art-nouveau conference chamber where scripts, structure, and odd sparks of inspiration can all sit at the same table.',
    atlas: 'The writers room should feel intelligent and hospitable: equal parts salon, story lab, and conference nook tucked just off the main hallway.',
    routes: ['HALLWAY', 'GREEN ROOM', 'STORY TABLE', 'COFFEE NICHE'],
    fx: 'writers',
    walkY: 78,
    spriteScale: 0.9,
    mmDot: {cx:17, cy:33},
    features: [
      {
        id:'feature-writers-table', label:'STORY TABLE', left:41, bottom:12, width:274, height:198,
        title:'STORY TABLE', image:'/assets/details/writers_story_table.png',
        body:'This is the room\'s true center of gravity: the round table where outlines, scene beats, revisions, and impossible ideas all get a fair hearing.'
      },
      {
        id:'feature-writers-orrery', label:'IDEA ORRERY', left:8, bottom:26, width:166, height:212,
        title:'IDEA ORRERY', image:'/assets/details/writers_idea_orrery.png',
        body:'A sculptural little symbol for how this room should work — thoughts circling each other until one of them suddenly locks into place.'
      },
      {
        id:'feature-writers-coffee', label:'COFFEE NICHE', left:73, bottom:30, width:168, height:176,
        title:'COFFEE NICHE', image:'/assets/details/writers_coffee_niche.png',
        body:'No real writers room feels finished without somewhere to stand, sip, stall, and pretend a breakthrough is about to happen any second now.'
      }
    ],
    doors: [
      {
        id:'door-back-hallway',
        label:'← HALLWAY',
        left:9, bottom:25,
        width:72, height:176,
        target:'hallway',
        edge:'left',
        prompt:'PRESS <span class="key">E</span> TO STEP BACK INTO THE HALLWAY'
      }
    ]
  },

  greenroom: {
    bg: '/assets/rooms/greenroom_polish.jpg',
    bgPos: 'center 34%',
    name: 'GREEN ROOM — BACKSTAGE HUB',
    subtitle: 'Warm, lived-in, and connected — this is the heart of the 2.5D side before you step out onto the studio path.',
    atlas: 'The green room is the connective tissue of PubCast 2.5D: lounge, regroup, then branch toward dressing, studio, control, or the bar.',
    routes: ['DRESSING ROOM', 'STUDIO SET', 'CONTROL ROOM', 'VORTEX BAR', 'WRITERS'],
    fx: 'greenroom',
    walkY: 80,
    spriteScale: 1.0,
    mmDot: {cx:80, cy:35},
    features: [
      {
        id:'feature-makeup', label:'MAKEUP STATION', left:49, bottom:41, width:146, height:92,
        title:'MAKEUP STATION', image:'/assets/details/makeup_station.png',
        body:'A more intimate backstage detail. This should feel like the place where a performer pauses, resets, powders off, and gets ready to step back into the show.'
      },
      {
        id:'feature-callboard', label:'CALL BOARD', left:73, bottom:33, width:152, height:96,
        title:'CALL BOARD', image:'/assets/details/call_board.png',
        body:'A practical little anchor for notes, lineup reminders, and backstage texture. It makes the green room feel inhabited, not merely navigable.'
      }
    ],
    doors: [
      {
        id:'door-writers-gr',
        label:'CONFERENCE / WRITERS',
        left:22, bottom:44,
        width:58, height:78,
        target:'writers',
        facing:'up'
      },
      {
        id:'door-studio-overlook',
        label:'STUDIO SET',
        left:55, bottom:24,
        width:84, height:54,
        target:'studio_overlook',
        facing:'up',
        prompt:'PRESS <span class="key">E</span> TO LEAVE THE LOUNGE AND WALK TOWARD THE STUDIO SET'
      },
      {
        id:'door-controlroom',
        label:'CONTROL ROOM',
        left:93, bottom:44,
        width:64, height:82,
        target:'controlroom',
        facing:'up'
      },
      {
        id:'door-dressing',
        label:'DRESSING ROOM',
        left:8, bottom:46,
        width:56, height:78,
        target:'dressing',
        edge:'left'
      },
      {
        id:'door-vortex',
        label:'COCKTAIL RING / VORTEX',
        left:72, bottom:45,
        width:58, height:76,
        target:'vortex',
        edge:'right'
      },
      {
        id:'door-hallway-gr',
        label:'← HALLWAY',
        left:36, bottom:18,
        width:66, height:44,
        target:'hallway',
        edge:'bottom'
      }
    ]
  },

  studio_overlook: {
    bg: '/assets/rooms/studio.jpg',
    bgPos: 'center 30%',
    bgSize: 'cover',
    name: 'STUDIO SET — OVERLOOK',
    walkY: 78,
    spriteScale: 0.9,
    mmDot: {cx:68, cy:57},
    doors: [
      {
        id:'door-greenroom-s',
        label:'← GREEN ROOM',
        left:15, bottom:22,
        width:60, height:80,
        target:'greenroom',
        edge:'left'
      },
      {
        id:'door-fixed-sets',
        label:'FIXED SETS CLOSE-UP →',
        left:77, bottom:26,
        width:66, height:84,
        target:'studio_fixedsets',
        edge:'right',
        prompt:'WALK THE SET — PRESS <span class="key">E</span> TO MOVE TOWARD THE FIXED SETS'
      },
      {
        id:'door-controlroom-s',
        label:'CONTROL ROOM',
        left:55, bottom:43,
        width:62, height:76,
        target:'controlroom',
        facing:'up'
      }
    ]
  },

  studio_fixedsets: {
    bg: '/assets/rooms/studio.jpg',
    bgPos: '68% 34%',
    bgSize: '148%',
    name: 'FIXED SETS — CLOSE VIEW',
    walkY: 79,
    spriteScale: 0.88,
    mmDot: {cx:73, cy:57},
    doors: [
      {
        id:'door-director-threshold',
        label:'← DIRECTOR CHAIR IMAGE',
        left:12, bottom:24,
        width:68, height:88,
        target:'studio_director',
        edge:'left',
        prompt:'ON THE FAR LEFT: <span class="key">E</span> TO MOVE TO THE DIRECTOR CHAIR VIEW'
      },
      {
        id:'door-studio-overlook-return',
        label:'OVERLOOK →',
        left:88, bottom:24,
        width:62, height:84,
        target:'studio_overlook',
        edge:'right'
      }
    ]
  },

  studio_director: {
    bg: '/assets/rooms/studio.jpg',
    bgPos: '34% 34%',
    bgSize: '165%',
    name: 'DIRECTOR CHAIR — PUBWORLD THRESHOLD',
    walkY: 80,
    spriteScale: 0.88,
    mmDot: {cx:78, cy:57},
    doors: [
      {
        id:'door-fixedsets-return',
        label:'FIXED SETS →',
        left:86, bottom:25,
        width:62, height:82,
        target:'studio_fixedsets',
        edge:'right'
      },
      {
        id:'door-pubworld-portal',
        label:'PUBCAST 3D STAGE',
        left:56, bottom:46,
        width:92, height:86,
        href:'/stage?room=studio&entry=pubworld&from=director-chair',
        kind:'portal',
        prompt:'WALK TOWARD THE BACK — <span class="key">E</span> TO CROSS INTO PUBCAST 3D',
        edge:'center'
      }
    ]
  },

  controlroom: {
    bg: '/assets/rooms/controlroom.jpg',
    bgPos: 'center 58%',
    name: 'CONTROL ROOM — BROADCAST NERVE CENTER',
    subtitle: 'Warm wood, live glass, and blinking monitors — the control room should feel like the place the whole house quietly pivots around.',
    atlas: 'The control room is where the show becomes intentional: watch the set through the glass, check the multiview wall, then step into the live console without breaking the 2.5D flow.',
    routes: ['GREEN ROOM', 'STUDIO SET', 'LIVE CONSOLE', 'MULTIVIEW WALL'],
    fx: 'controlroom',
    walkY: 76,
    spriteScale: 1.0,
    mmDot: {cx:119, cy:57},
    features: [
      {
        id:'feature-control-switcher', label:'LIVE CONSOLE', left:49, bottom:27, width:244, height:184,
        title:'LIVE CONSOLE', image:'/assets/details/control_switcher.png',
        body:'The heart of the room: switching, pacing, and all the invisible judgement calls that make a show feel effortless. This should feel like a beautiful place to run the whole house from.',
        buttons:[{label:'OPEN CONTROL UI', href:'/control'}]
      },
      {
        id:'feature-control-multiview', label:'MULTIVIEW WALL', left:74, bottom:45, width:218, height:126,
        title:'MULTIVIEW WALL', image:'/assets/details/control_multiview.png',
        body:'Program, preview, and all the little live anxieties. The multiview wall makes the room feel operational instead of merely decorative — a real broadcast brain with a pulse.'
      },
      {
        id:'feature-control-window', label:'STAGE WINDOW', left:31, bottom:38, width:286, height:190,
        title:'STAGE WINDOW', image:'/assets/details/control_stage_window.png',
        body:'A literal line of sight into the set. From here the control room still belongs to the theater around it — not a disconnected bunker, but a backstage chamber with eyes on the stage.'
      },
      {
        id:'feature-control-notes', label:'RUN SHEET DESK', left:10, bottom:18, width:126, height:144,
        title:'RUN SHEET DESK', image:'/assets/details/control_scriptdesk.png',
        body:'Cue sheets, last-minute rewrites, and timing notes. This little desk is a human reminder that every polished show still depends on paper, pencils, and someone keeping the chaos legible.'
      }
    ],
    doors: [
      {
        id:'door-greenroom-cr',
        label:'← GREEN ROOM',
        left:10, bottom:22,
        width:60, height:80,
        target:'greenroom',
        edge:'left'
      },
      {
        id:'door-studio-cr',
        label:'STUDIO SET',
        left:30, bottom:26,
        width:55, height:75,
        target:'studio_overlook',
        facing:'left'
      }
    ]
  },

  vortex: {
    bg: '/assets/rooms/vortex.jpg',
    bgPos: 'center 44%',
    bgSize: 'cover',
    name: 'THE VORTEX BAR — AFTER HOURS THRESHOLD',
    subtitle: 'Part cocktail lounge, part dimensional bruise — the bar is where the 2.5D house gets glamorous, strange, and just a little dangerous.',
    atlas: 'The Vortex Bar should feel like a stylish side chamber for decompression, gossip, and theatrical mystery before you drift back into the practical backstage rooms.',
    routes: ['GREEN ROOM', 'BAR RAIL', 'VORTEX FLOOR', 'BOOTHS'],
    fx: 'vortex',
    walkY: 76,
    spriteScale: 1.0,
    mmDot: {cx:143, cy:33},
    features: [
      {
        id:'feature-vortex-bar', label:'BAR RAIL', left:77, bottom:18, width:220, height:220,
        title:'BAR RAIL', image:'/assets/details/vortex_bar_rail.png',
        body:'The bar keeps the room from becoming only a gimmick. It grounds the surreal floor with something social, familiar, and temptingly well lit.'
      },
      {
        id:'feature-vortex-floor', label:'VORTEX FLOOR', left:34, bottom:4, width:240, height:204,
        title:'VORTEX FLOOR', image:'/assets/details/vortex_floor_portal.png',
        body:'This is the room\'s signature danger: a visual whirlpool worked into the floor so elegantly that it reads as both design statement and dimensional warning.'
      },
      {
        id:'feature-vortex-booths', label:'SHADOW BOOTHS', left:8, bottom:18, width:170, height:214,
        title:'SHADOW BOOTHS', image:'/assets/details/vortex_booths.png',
        body:'The booths make the bar playable instead of merely scenic — private corners for scheming, cooling down, or disappearing into a conversation after the show.'
      },
      {
        id:'feature-vortex-door', label:'BACK DOOR', left:49, bottom:30, width:118, height:176,
        title:'BACK DOOR', image:'/assets/details/vortex_back_door.png',
        body:'A promising little door at the back of the room that makes the bar feel connected to a larger mythos, even before the rest of that myth is fully built.'
      }
    ],
    doors: [
      {
        id:'door-greenroom-v',
        label:'← GREEN ROOM',
        left:11, bottom:24,
        width:74, height:186,
        target:'greenroom',
        edge:'left',
        prompt:'PRESS <span class="key">E</span> TO LEAVE THE VORTEX AND RETURN TO THE GREEN ROOM'
      }
    ]
  },

  dressing: {
    bg: null,
    name: 'DRESSING ROOM',
    walkY: 75,
    spriteScale: 1.0,
    mmDot: {cx:17, cy:57},
    doors: [
      {
        id:'door-greenroom-d',
        label:'← GREEN ROOM',
        left:50, bottom:18,
        width:65, height:85,
        target:'greenroom',
        edge:'bottom'
      }
    ]
  }

};

// ══════════════════════════════════════════════════════
//  GAME STATE
// ══════════════════════════════════════════════════════
let currentRoom   = 'dressing';
let sx            = 50;
let sdir          = 1;
let walking       = false;
let wt            = 0;
let nearDoor      = null;
let transitioning = false;
let edgeCooldown  = false; // prevent edge trigger firing every frame
const keys        = {};

// ══════════════════════════════════════════════════════
//  SPRITE
// ══════════════════════════════════════════════════════
const sprWrap = document.getElementById('spr');
const sprCV   = document.getElementById('spr-cv');
const sprCtx  = sprCV.getContext('2d');
const sprShad = document.getElementById('spr-shadow');

function drawSprite(walk, dir, t, scale=1.0) {
  const W=48, H=80;
  sprCV.width=W; sprCV.height=H;
  sprCV.style.width  = Math.round(W*scale)+'px';
  sprCV.style.height = Math.round(H*scale)+'px';
  sprShad.style.width  = Math.round(54*scale)+'px';
  sprShad.style.height = Math.round(9*scale)+'px';

  sprCtx.clearRect(0,0,W,H);
  const cx=24, C='#00e5cc', CF='rgba(0,229,204,';
  const bob = walk ? Math.abs(Math.sin(t*6))*2 : 0;
  const leg = walk ? Math.sin(t*6)*14 : 0;
  const arm = walk ? Math.sin(t*6)*10 : 0;

  if (dir===-1){sprCtx.save();sprCtx.translate(W,0);sprCtx.scale(-1,1);}
  sprCtx.shadowBlur=16; sprCtx.shadowColor=C;
  // Legs
  sprCtx.strokeStyle=C;sprCtx.lineWidth=4;sprCtx.lineCap='round';
  sprCtx.beginPath();sprCtx.moveTo(cx-5,46+bob);sprCtx.lineTo(cx-5+leg,66+bob);sprCtx.stroke();
  sprCtx.beginPath();sprCtx.moveTo(cx+5,46+bob);sprCtx.lineTo(cx+5-leg,66+bob);sprCtx.stroke();
  // Body
  sprCtx.beginPath();sprCtx.roundRect(cx-9,22+bob,18,26,4);
  sprCtx.strokeStyle=C;sprCtx.lineWidth=2;sprCtx.stroke();
  sprCtx.fillStyle=CF+'0.07)';sprCtx.fill();
  sprCtx.strokeStyle=CF+'0.22)';sprCtx.lineWidth=1;
  for(let i=0;i<4;i++){sprCtx.beginPath();sprCtx.moveTo(cx-7,28+i*5+bob);sprCtx.lineTo(cx+7,28+i*5+bob);sprCtx.stroke();}
  // Arms
  sprCtx.strokeStyle=C;sprCtx.lineWidth=3;
  sprCtx.beginPath();sprCtx.moveTo(cx-9,26+bob);sprCtx.lineTo(cx-17+arm,40+bob);sprCtx.stroke();
  sprCtx.beginPath();sprCtx.moveTo(cx+9,26+bob);sprCtx.lineTo(cx+17-arm,40+bob);sprCtx.stroke();
  // Neck
  sprCtx.beginPath();sprCtx.moveTo(cx,22+bob);sprCtx.lineTo(cx,16+bob);sprCtx.lineWidth=3;sprCtx.stroke();
  // Head
  sprCtx.beginPath();sprCtx.roundRect(cx-8,4+bob,16,13,3);
  sprCtx.strokeStyle=C;sprCtx.lineWidth=2;sprCtx.stroke();sprCtx.fillStyle=CF+'0.08)';sprCtx.fill();
  // Eyes
  sprCtx.fillStyle=C;sprCtx.shadowBlur=8;
  sprCtx.beginPath();sprCtx.arc(cx-3,11+bob,1.8,0,Math.PI*2);sprCtx.fill();
  sprCtx.beginPath();sprCtx.arc(cx+3,11+bob,1.8,0,Math.PI*2);sprCtx.fill();
  if(dir===-1)sprCtx.restore();
}

// ══════════════════════════════════════════════════════
//  ROOM LOADING
// ══════════════════════════════════════════════════════
const roomBg       = document.getElementById('room-bg');
const roomFx       = document.getElementById('room-fx');
const roomName     = document.getElementById('room-name');
const doorsLayer   = document.getElementById('doors-layer');
const featureLayer = document.getElementById('feature-layer');
const promptEl     = document.getElementById('prompt');
const mmDot        = document.getElementById('mm-dot');
const dressingOv   = document.getElementById('dressing-room');
const atlasTitle   = document.getElementById('atlas-title');
const atlasCopy    = document.getElementById('atlas-copy');
const atlasKicker  = document.getElementById('atlas-kicker');
const atlasRoutes  = document.getElementById('atlas-routes');

function loadRoom(roomId, spawnX=50) {
  const room = ROOMS[roomId];
  if (!room) return;
  currentRoom = roomId;
  sx = spawnX;

  // Update HUD
  roomName.textContent = room.name;

  // Update BG
  if (room.bg) {
    roomBg.style.backgroundImage  = `url('${room.bg}')`;
    roomBg.style.backgroundSize   = room.bgSize || 'cover';
    roomBg.style.backgroundPosition = room.bgPos || 'center bottom';
    roomBg.style.display = '';
    document.getElementById('dressing-room-bg').style.display='none';
  } else {
    // Procedural room (dressing room)
    roomBg.style.display='none';
    document.getElementById('dressing-room-bg').style.display='block';
  }

  // Update minimap dot
  if (mmDot && room.mmDot) {
    mmDot.setAttribute('cx', room.mmDot.cx);
    mmDot.setAttribute('cy', room.mmDot.cy);
  }

  applyRoomAtlas(room);
  applyRoomFX(room);

  // Highlight current room on minimap
  updateMinimap(roomId);

  // Build door hotspots
  buildDoors(room.doors);
  buildFeatures(room.features || []);

  // Special: dressing room opens overlay on first spawn
  if (roomId === 'dressing') {
    dressingOv.style.display='flex';
    animateMirror();
  } else {
    dressingOv.style.display='none';
  }
}

function updateMinimap(roomId) {
  // Highlight active room
  const roomMMMap = {
    lobby:{cx:80,cy:2,w:40,h:18},
    hallway:{cx:80,cy:2,w:40,h:18},
    greenroom:{cx:60,cy:26,w:40,h:18},
    writers:{cx:2,cy:26,w:30,h:14},
    vortex:{cx:128,cy:26,w:30,h:14},
    dressing:{cx:2,cy:50,w:30,h:14},
    studio_overlook:{cx:55,cy:50,w:24,h:14},
    studio_fixedsets:{cx:79,cy:50,w:18,h:14},
    studio_director:{cx:97,cy:50,w:18,h:14},
    controlroom:{cx:116,cy:50,w:22,h:14}
  };
  const svg = document.getElementById('mm-svg');
  // Remove old highlights
  svg.querySelectorAll('.mm-active').forEach(e=>e.remove());
  const rm = roomMMMap[roomId];
  if (rm) {
    const rect = document.createElementNS('http://www.w3.org/2000/svg','rect');
    rect.setAttribute('x', rm.cx);
    rect.setAttribute('y', rm.cy);
    rect.setAttribute('width', rm.w);
    rect.setAttribute('height', rm.h);
    rect.setAttribute('fill','rgba(0,229,204,.15)');
    rect.setAttribute('stroke','rgba(0,229,204,.6)');
    rect.setAttribute('stroke-width','1');
    rect.setAttribute('rx','1');
    rect.setAttribute('class','mm-active');
    svg.insertBefore(rect, svg.firstChild);
  }
}


function applyRoomAtlas(room) {
  atlasKicker.textContent = room.subtitle ? 'NOW PLAYING' : 'HOUSE GUIDE';
  atlasTitle.textContent = room.name || 'PUBWORLD';
  atlasCopy.textContent = room.atlas || room.subtitle || 'Move through the 2.5D studio and use the marked doors to change rooms.';
  atlasRoutes.innerHTML = '';
  (room.routes || []).forEach(route => {
    const chip = document.createElement('div');
    chip.className = 'atlas-route';
    chip.textContent = route;
    atlasRoutes.appendChild(chip);
  });
}

function applyRoomFX(room) {
  roomFx.className = '';
  roomFx.id = 'room-fx';
  if (room && room.fx) {
    roomFx.classList.add('active', `fx-${room.fx}`);
  }
}

function buildFeatures(features) {
  featureLayer.innerHTML = '';
  if (!features || !features.length) return;
  features.forEach(f => {
    const el = document.createElement('button');
    el.type = 'button';
    el.className = 'feature';
    el.style.left = f.left + '%';
    el.style.bottom = f.bottom + '%';
    el.style.width = f.width + 'px';
    el.style.height = f.height + 'px';
    el.style.background = 'none';
    el.style.border = 'none';
    el.style.padding = '0';

    const glow = document.createElement('div');
    glow.className = 'feature-glow';
    const label = document.createElement('div');
    label.className = 'feature-label';
    label.textContent = f.label;
    el.appendChild(glow);
    el.appendChild(label);
    el.addEventListener('click', () => {
      const imageHTML = f.image
        ? `<img src="${f.image}" alt="${f.title}" style="display:block;width:100%;max-height:220px;object-fit:cover;border:1px solid rgba(201,168,76,.18);margin-bottom:14px;">`
        : '';
      const buttons = Array.isArray(f.buttons)
        ? f.buttons.map(btn => ({
            label: btn.label,
            action: () => {
              if (btn.href) window.location.href = btn.href;
            }
          }))
        : [];
      showNookModal(f.title, `${imageHTML}<p>${f.body}</p>`, buttons);
    });
    featureLayer.appendChild(el);
  });
}

function buildDoors(doors) {
  doorsLayer.innerHTML = '';
  if (!doors) return;
  doors.forEach(d => {
    const el = document.createElement('div');
    el.className = 'door';
    el.id = d.id;
    el.style.left   = d.left   + '%';
    el.style.bottom = d.bottom + '%';
    el.dataset.target = d.target || '';
    el.dataset.href   = d.href || '';
    el.dataset.kind   = d.kind || 'door';
    el.dataset.prompt = d.prompt || '';
    el.dataset.left   = d.left;

    const glow = document.createElement('div');
    glow.className = 'door-glow';
    glow.style.width  = d.width  + 'px';
    glow.style.height = d.height + 'px';

    const label = document.createElement('div');
    label.className = 'door-label';
    label.textContent = d.label;

    el.appendChild(glow);
    el.appendChild(label);
    doorsLayer.appendChild(el);
  });
}

// ══════════════════════════════════════════════════════
//  PROXIMITY CHECK
// ══════════════════════════════════════════════════════
function checkDoors() {
  nearDoor = null;
  const doors = doorsLayer.querySelectorAll('.door');
  doors.forEach(d => {
    const doorLeft = parseFloat(d.dataset.left);
    const dist = Math.abs(sx - doorLeft);
    if (dist < 8) {
      nearDoor = d;
      d.classList.add('near');
    } else {
      d.classList.remove('near');
    }
  });
  if (nearDoor) {
    promptEl.innerHTML = nearDoor.dataset.prompt || (
      nearDoor.dataset.kind === 'portal'
        ? 'PRESS <span class="key">E</span> TO CROSS INTO THE 3D STUDIO'
        : 'PRESS <span class="key">E</span> TO ENTER'
    );
  }
  promptEl.classList.toggle('show', !!nearDoor);
}

// ══════════════════════════════════════════════════════
//  ROOM TRANSITION
// ══════════════════════════════════════════════════════
const transEl = document.getElementById('transition');

function useDoor(doorEl) {
  if (!doorEl || transitioning) return;
  if (doorEl.dataset.kind === 'portal' && doorEl.dataset.href) {
    transitioning = true;
    transEl.classList.remove('fade-out');
    void transEl.offsetWidth;
    transEl.classList.add('portal-wipe');
    setTimeout(() => { window.location.href = doorEl.dataset.href; }, 860);
    return;
  }
  const target = doorEl.dataset.target;
  if (!target) return;
  const doorLeft = parseFloat(doorEl.dataset.left);
  let spawnX = 50;
  if (doorLeft < 30) spawnX = 82;
  else if (doorLeft > 70) spawnX = 18;
  else spawnX = 50;
  goToRoom(target, spawnX);
}


function goToRoom(targetId, spawnX=50) {
  if (transitioning) return;
  transitioning = true;
  transEl.classList.add('fade-out');
  setTimeout(() => {
    loadRoom(targetId, spawnX);
    setTimeout(() => {
      transEl.classList.remove('fade-out','portal-wipe');
      transitioning = false;
      edgeCooldown  = false; // reset after transition
    }, 400);
  }, 400);
}

// ══════════════════════════════════════════════════════
//  DRESSING ROOM
// ══════════════════════════════════════════════════════
function animateMirror() {
  const cv = document.getElementById('avatar-mirror');
  if (!cv) return;
  const c = cv.getContext('2d');
  const W=cv.width, H=cv.height;
  let t=0;
  function draw(){
    c.clearRect(0,0,W,H);
    c.fillStyle='rgba(0,229,204,0.03)'; c.fillRect(0,0,W,H);
    // Draw avatar in mirror
    const cx=W/2, pulse=0.85+Math.sin(t*1.5)*0.15;
    const C='rgba(0,229,204,';
    c.shadowBlur=20*pulse; c.shadowColor='#00e5cc';
    // legs
    c.strokeStyle=`${C}${0.6*pulse})`; c.lineWidth=3; c.lineCap='round';
    c.beginPath();c.moveTo(cx-5,160);c.lineTo(cx-10,200);c.stroke();
    c.beginPath();c.moveTo(cx+5,160);c.lineTo(cx+10,200);c.stroke();
    // body
    c.beginPath();c.roundRect(cx-18,100,36,65,6);
    c.strokeStyle=`${C}${0.7*pulse})`; c.lineWidth=2; c.stroke();
    c.fillStyle=`${C}0.05)`; c.fill();
    // scanlines
    c.strokeStyle=`${C}${0.18*pulse})`; c.lineWidth=1;
    for(let i=0;i<6;i++){c.beginPath();c.moveTo(cx-15,110+i*8);c.lineTo(cx+15,110+i*8);c.stroke();}
    // arms
    c.strokeStyle=`${C}${0.55*pulse})`; c.lineWidth=2.5;
    c.beginPath();c.moveTo(cx-18,110);c.lineTo(cx-30,145);c.stroke();
    c.beginPath();c.moveTo(cx+18,110);c.lineTo(cx+30,145);c.stroke();
    // neck
    c.beginPath();c.moveTo(cx,100);c.lineTo(cx,85);c.lineWidth=2.5;c.stroke();
    // head
    c.beginPath();c.roundRect(cx-16,62,32,26,5);
    c.strokeStyle=`${C}${0.8*pulse})`; c.lineWidth=2; c.stroke();
    c.fillStyle=`${C}0.06)`; c.fill();
    // eyes
    c.fillStyle=`${C}${0.9*pulse})`; c.shadowBlur=8;
    c.beginPath();c.arc(cx-6,76,3,0,Math.PI*2);c.fill();
    c.beginPath();c.arc(cx+6,76,3,0,Math.PI*2);c.fill();
    // scanline overlay
    c.fillStyle='rgba(0,0,0,0.03)';
    for(let y=0;y<H;y+=3){c.fillRect(0,y,W,1);}
    c.shadowBlur=0; t+=0.02;
    if(dressingOv.style.display!=='none') requestAnimationFrame(draw);
  }
  draw();
}

window.exitDressingRoom = function() {
  dressingOv.style.display='none';
  // Already in dressing room state, go to green room
  goToRoom('greenroom', 12);
};

// ══════════════════════════════════════════════════════
//  INPUT
// ══════════════════════════════════════════════════════
document.addEventListener('keydown', e => {
  keys[e.key] = true;
  // Prevent arrow keys from scrolling the page
  if (['ArrowLeft','ArrowRight','ArrowUp','ArrowDown',' '].includes(e.key)) e.preventDefault();
  if ((e.key==='e'||e.key==='E') && nearDoor && !transitioning) {
    useDoor(nearDoor);
  }
  if (e.key==='Escape') {
    // Return to green room from anywhere
    if (currentRoom !== 'greenroom') goToRoom('greenroom', 50);
  }
});
document.addEventListener('keyup', e => { keys[e.key] = false; });

// ══════════════════════════════════════════════════════
//  MAIN LOOP
// ══════════════════════════════════════════════════════
const SPEED = 0.22;
let lastT = 0;

function gameLoop(now) {
  const dt = Math.min((now-lastT)/1000, 0.05); lastT=now;

  if (!transitioning && dressingOv.style.display==='none') {
    const L = keys['ArrowLeft']  || keys['a'] || keys['A'];
    const R = keys['ArrowRight'] || keys['d'] || keys['D'];

    if (R) { sx=Math.min(92,sx+SPEED*60*dt); sdir=1;  walking=true; }
    else if (L) { sx=Math.max(8,sx-SPEED*60*dt);  sdir=-1; walking=true; }
    else walking=false;

    // Auto-trigger door at screen edges — find the leftmost/rightmost door
    if (!transitioning && !edgeCooldown) {
      const allDoors = [...doorsLayer.querySelectorAll('.door')];
      if (sx >= 91 && allDoors.length) {
        const rightDoor = allDoors.reduce((best, d) =>
          parseFloat(d.dataset.left) > parseFloat(best.dataset.left) ? d : best
        );
        if (rightDoor && parseFloat(rightDoor.dataset.left) > 60 && rightDoor.dataset.kind !== 'portal' && rightDoor.dataset.target) {
          edgeCooldown = true;
          goToRoom(rightDoor.dataset.target, 12);
        }
      } else if (sx <= 9 && allDoors.length) {
        const leftDoor = allDoors.reduce((best, d) =>
          parseFloat(d.dataset.left) < parseFloat(best.dataset.left) ? d : best
        );
        if (leftDoor && parseFloat(leftDoor.dataset.left) < 40 && leftDoor.dataset.kind !== 'portal' && leftDoor.dataset.target) {
          edgeCooldown = true;
          goToRoom(leftDoor.dataset.target, 85);
        }
      }
    }
  } else {
    walking = false;
  }

  if (walking) wt+=dt;

  const room = ROOMS[currentRoom];
  const scale = room ? (room.spriteScale || 1.0) : 1.0;
  const walkY = room ? room.walkY : 76;

  sprWrap.style.left   = sx + '%';
  sprWrap.style.bottom = walkY + '%';
  drawSprite(walking, sdir, wt, scale);
  checkDoors();

  requestAnimationFrame(gameLoop);
}

// ══════════════════════════════════════════════════════
//  BACKEND INTEGRATION — PubCast WebSocket Bridge
// ══════════════════════════════════════════════════════

const CLIENT_ID  = 'pw_' + Math.random().toString(36).slice(2, 10);
let   backendWS  = null;
let   backendOK  = false;
let   reconnectT = null;

const liveBadge = document.querySelector('.badge.red');

function wsConnect() {
  clearTimeout(reconnectT);
  const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
  const url   = `${proto}//${location.host}/pubworld/ws/${CLIENT_ID}`;
  try {
    backendWS = new WebSocket(url);
  } catch(e) {
    scheduleReconnect(); return;
  }

  backendWS.onopen = () => {
    backendOK = true;
    updateHUDBadge(true);
    // Report current room immediately on reconnect
    wsSend({ type:'room_change', room:currentRoom, x:Math.round(sx) });
  };

  backendWS.onmessage = (ev) => {
    try { handleBackendMessage(JSON.parse(ev.data)); } catch(e) {}
  };

  backendWS.onclose = () => {
    backendOK = false;
    updateHUDBadge(false);
    scheduleReconnect();
  };

  backendWS.onerror = () => {
    backendOK = false;
    updateHUDBadge(false);
  };
}

function scheduleReconnect() {
  reconnectT = setTimeout(wsConnect, 4000);
}

function wsSend(obj) {
  if (backendWS && backendWS.readyState === WebSocket.OPEN) {
    backendWS.send(JSON.stringify(obj));
    return true;
  }
  return false;
}

// REST fallback when WS is down
function restFallback(endpoint, body) {
  body.client_id = CLIENT_ID;
  fetch('/pubworld/api/' + endpoint, {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify(body)
  }).catch(() => {});
}

function handleBackendMessage(msg) {
  const t = msg.type;

  if (t === 'pong') {
    // keepalive confirmed
  } else if (t === 'welcome') {
    // Got initial state from backend
    if (msg.payload && msg.payload.production_state) {
      applyProductionState(msg.payload.production_state);
    }
  } else if (t === 'production_state') {
    // Control room changed something — update PubWorld HUD
    if (msg.payload) applyProductionState(msg.payload);
  } else if (t === 'room_ack') {
    // Backend confirmed room change
  } else if (t === 'hotspot_result') {
    // Response to a hotspot action — results already handled in USE_HANDLERS
  } else if (t === 'player_moved') {
    // Another player moved — future: show presence indicator
  }
}

function applyProductionState(state) {
  // Update LIVE badge based on whether we're on-air
  if (state.on_air !== undefined) {
    if (liveBadge) {
      liveBadge.textContent = state.on_air ? '● LIVE' : '● OFF AIR';
      liveBadge.style.background = state.on_air
        ? 'rgba(139,0,0,.4)' : 'rgba(40,40,40,.4)';
    }
  }
}

function updateHUDBadge(online) {
  const badge = document.getElementById('company-badge');
  if (!badge) return;
  if (online) {
    badge.style.borderColor = '';
    badge.style.color       = '';
    badge.title             = 'Backend connected';
  } else {
    badge.style.borderColor = 'rgba(120,80,20,.4)';
    badge.style.color       = 'rgba(201,168,76,.35)';
    badge.title             = 'Backend offline — navigation still works';
  }
}

// ── Patch goToRoom to report moves to backend ────────────────────────────
const _origGoToRoom = goToRoom;
window.goToRoom = function(targetId, spawnX=50) {
  _origGoToRoom(targetId, spawnX);
  // Report the new room to backend (after transition starts)
  setTimeout(() => {
    const sent = wsSend({ type:'room_change', room:targetId, x:Math.round(spawnX) });
    if (!sent) restFallback('room-change', { room:targetId, x:Math.round(spawnX) });
  }, 450); // after fade completes
};

// ── Hotspot API caller ───────────────────────────────────────────────────
function callHotspotAPI(action, data={}) {
  return new Promise((resolve) => {
    const msg = { type:'hotspot', room:currentRoom, action, data };

    const sent = wsSend(msg);
    if (sent) {
      // Result will come back via handleBackendMessage → hotspot_result
      // For now also do REST for the return value
    }
    // Always do REST for synchronous result
    fetch('/pubworld/api/hotspot', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ client_id:CLIENT_ID, room:currentRoom, action, data })
    }).then(r=>r.json()).then(resolve).catch(() => resolve({ status:'offline' }));
  });
}

// ── USE_HANDLERS — wire hotspots to backend ──────────────────────────────
const USE_HANDLERS = {
  async typewriter() {
    const res = await callHotspotAPI('typewriter');
    showNookModal('SCRIPT EDITOR',
      `<p>Draft ID: <b>${res.result?.draft_id || 'new'}</b></p>`,
      [{ label:'WRITE SCRIPT', action: () => alert('Script editor — coming next session') },
       { label:'REVIEW SCRIPTS', action: () => callHotspotAPI('scripts').then(r => alert(r.result?.scripts?.join('\n') || 'None yet')) }]
    );
  },
  async phone() {
    const res = await callHotspotAPI('phone');
    showNookModal('CALL / SESSION',
      `<p>Session: <b>${res.result?.session_token || '—'}</b></p><p>Join: ${res.result?.join_url || '—'}</p>`,
      [{ label:'JOIN ZOOM', action: () => alert('TODO: Zoom SDK') },
       { label:'USE WEBCAM', action: () => alert('TODO: webcam + mic') }]
    );
  },
  async camera_remote() {
    const res = await callHotspotAPI('camera_remote');
    const cams = res.result?.cameras || [];
    showNookModal('CAMERA REMOTE',
      `<p>${cams.join(' &nbsp;·&nbsp; ') || 'No cameras'}</p>`,
      cams.map(c => ({ label: c, action: () => callHotspotAPI('select_camera', {camera:c}) }))
    );
  }
};

function showNookModal(title, bodyHTML, buttons=[]) {
  let modal = document.getElementById('pw-modal');
  if (!modal) {
    modal = document.createElement('div');
    modal.id = 'pw-modal';
    modal.style.cssText = `
      position:fixed; inset:0; z-index:600;
      display:flex; align-items:center; justify-content:center;
      background:rgba(0,0,0,.75);
    `;
    document.body.appendChild(modal);
  }
  modal.innerHTML = `
    <div style="
      background:#0d0a06; border:1px solid var(--gold);
      padding:32px 40px; min-width:320px; max-width:480px;
      box-shadow:0 0 40px rgba(201,168,76,.2);
      clip-path:polygon(12px 0%,100% 0%,calc(100% - 12px) 100%,0% 100%);
    ">
      <div style="font-family:'Cinzel Decorative',serif;color:var(--gold);font-size:13px;letter-spacing:5px;margin-bottom:16px">${title}</div>
      <div style="color:rgba(201,168,76,.7);font-size:10px;letter-spacing:2px;line-height:2;margin-bottom:20px">${bodyHTML}</div>
      <div style="display:flex;gap:10px;flex-wrap:wrap">
        ${buttons.map((b,i) => `<button id="pw-mb-${i}" style="
          padding:8px 20px;border:1px solid var(--gold-d);color:var(--gold);
          background:rgba(201,168,76,.06);font-family:var(--font);
          font-size:9px;letter-spacing:3px;cursor:pointer
        ">${b.label}</button>`).join('')}
        <button id="pw-mb-close" style="
          padding:8px 20px;border:1px solid rgba(201,168,76,.3);color:rgba(201,168,76,.4);
          background:none;font-family:var(--font);font-size:9px;letter-spacing:3px;cursor:pointer
        ">CLOSE</button>
      </div>
    </div>
  `;
  modal.style.display = 'flex';
  buttons.forEach((b,i) => {
    document.getElementById(`pw-mb-${i}`)?.addEventListener('click', () => { b.action(); modal.style.display='none'; });
  });
  document.getElementById('pw-mb-close')?.addEventListener('click', () => { modal.style.display='none'; });
  modal.addEventListener('click', e => { if (e.target === modal) modal.style.display='none'; });
}

// ── WS keepalive ping every 25s ──────────────────────────────────────────
setInterval(() => { wsSend({ type:'ping' }); }, 25000);

// ── ESC also closes modal ─────────────────────────────────────────────────
const _origKeydown = document.onkeydown;
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') {
    const modal = document.getElementById('pw-modal');
    if (modal && modal.style.display !== 'none') {
      modal.style.display = 'none';
      e.stopImmediatePropagation();
    }
  }
}, true); // capture so it fires before the room ESC handler

// ── Start backend connection ──────────────────────────────────────────────
// Small delay so the page renders first
setTimeout(wsConnect, 800);

// ══════════════════════════════════════════════════════
//  INIT
// ══════════════════════════════════════════════════════

// Update image paths to use the backend asset route
// (allows serving from /pubworld/assets/* when running under PubCast)
const _origLoadRoom = loadRoom;
(function patchImagePaths() {
  // If we're running under PubCast (/pubworld URL), prefix image paths
  const isEmbedded = location.pathname.startsWith('/pubworld');
  if (!isEmbedded) return;
  Object.values(ROOMS).forEach(room => {
    if (room.bg) room.bg = '/pubworld/assets/' + room.bg;
  });
})();

// Load starting room
const _worldParams = new URLSearchParams(location.search);
const _startRoom = _worldParams.get('room');
const _startSpawn = Number(_worldParams.get('spawn') || 50);
loadRoom(ROOMS[_startRoom] ? _startRoom : 'dressing', Number.isFinite(_startSpawn) ? _startSpawn : 50);
transEl.classList.remove('fade-out','portal-wipe');
drawSprite(false,1,0,1.0);

// Start loop
requestAnimationFrame(t => { lastT=t; requestAnimationFrame(gameLoop); });
