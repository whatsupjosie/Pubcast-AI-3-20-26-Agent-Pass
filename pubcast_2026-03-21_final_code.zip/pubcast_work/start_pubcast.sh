#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════════════════
# PubCast AI v2.0 — Unified Startup Script
# Starts the Rust animation bridge first, then the FastAPI server.
# Ctrl+C shuts both down cleanly.
# ═══════════════════════════════════════════════════════════════════════════════

set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

PYTHON_PORT="${PUBCAST_PORT:-8000}"
WS_PORT="${PUBCAST_WS_PORT:-8765}"
RENDER_FPS="${PUBCAST_RENDER_FPS:-60}"
LOG_LEVEL="${RUST_LOG:-pubcast=info}"
WS_BINARY="$SCRIPT_DIR/bin/ws_renderer"

CYAN='\033[0;36m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'

echo -e "${CYAN}"
echo "  ██████╗ ██╗   ██╗██████╗  ██████╗ █████╗ ███████╗████████╗"
echo "  ██╔══██╗██║   ██║██╔══██╗██╔════╝██╔══██╗██╔════╝╚══██╔══╝"
echo "  ██████╔╝██║   ██║██████╔╝██║     ███████║███████╗   ██║   "
echo "  ██╔═══╝ ██║   ██║██╔══██╗██║     ██╔══██║╚════██║   ██║   "
echo "  ██║     ╚██████╔╝██████╔╝╚██████╗██║  ██║███████║   ██║   "
echo "  ╚═╝      ╚═════╝ ╚═════╝  ╚═════╝╚═╝  ╚═╝╚══════╝   ╚═╝  v2.0"
echo -e "${NC}"
echo -e "${CYAN}  Feic Mo Chroí — Technology Serving Human Storytelling${NC}"
echo -e "${CYAN}  Copyright © 2024–2026 Rear View Foresight LLC${NC}"
echo ""

WS_PID=""; PYTHON_PID=""

cleanup() {
    echo ""
    echo -e "${YELLOW}Shutting down PubCast AI...${NC}"
    [ -n "$PYTHON_PID" ] && kill "$PYTHON_PID" 2>/dev/null && echo -e "  ${GREEN}✓${NC} FastAPI stopped"
    [ -n "$WS_PID"     ] && kill "$WS_PID"     2>/dev/null && echo -e "  ${GREEN}✓${NC} Rust bridge stopped"
    echo -e "${GREEN}Done.${NC}"
    exit 0
}
trap cleanup SIGINT SIGTERM

# ── Rust WebSocket animation bridge ───────────────────────────────────────────
if [ -x "$WS_BINARY" ]; then
    echo -e "${GREEN}▶ Rust animation bridge${NC} → ws://localhost:${WS_PORT} @ ${RENDER_FPS}fps"
    PUBCAST_WS_PORT="$WS_PORT" PUBCAST_RENDER_FPS="$RENDER_FPS" RUST_LOG="$LOG_LEVEL" \
        "$WS_BINARY" &
    WS_PID=$!
    sleep 0.5
    if ! kill -0 "$WS_PID" 2>/dev/null; then
        echo -e "${YELLOW}  ⚠ Bridge failed to start — avatar animation in fallback mode${NC}"
        WS_PID=""
    else
        echo -e "  ${GREEN}✓${NC} PID $WS_PID"
    fi
else
    echo -e "${YELLOW}⚠ bin/ws_renderer not found — skipping animation bridge${NC}"
    echo -e "  Rebuild: cd rust_crate && cargo build --release && cp target/release/ws_renderer ../bin/"
fi

echo ""

# ── Python deps ───────────────────────────────────────────────────────────────
python3 -c "import fastapi, uvicorn" 2>/dev/null || pip install -r requirements.txt -q

# ── FastAPI server ─────────────────────────────────────────────────────────────
echo -e "${GREEN}▶ PubCast AI server${NC} → http://localhost:${PYTHON_PORT}"
python3 -m uvicorn main:app --host 0.0.0.0 --port "$PYTHON_PORT" \
    --log-level info --no-access-log &
PYTHON_PID=$!

sleep 1
if ! kill -0 "$PYTHON_PID" 2>/dev/null; then
    echo -e "${RED}✗ Server failed to start${NC}"; cleanup; exit 1
fi
echo -e "  ${GREEN}✓${NC} PID $PYTHON_PID"
echo ""
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "  ${GREEN}PubCast AI v2.0 is live${NC}"
echo -e "  Lobby:       http://localhost:${PYTHON_PORT}"
echo -e "  Control:     http://localhost:${PYTHON_PORT}/control"
echo -e "  Studio Ctrl: http://localhost:${PYTHON_PORT}/studio"
echo -e "  BYOK:        http://localhost:${PYTHON_PORT}/byok"
echo -e "  Health:      http://localhost:${PYTHON_PORT}/api/health"
echo -e "  Rust WS:     ws://localhost:${WS_PORT}"
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "  ${YELLOW}Ctrl+C${NC} to stop all services"
echo ""

wait "$PYTHON_PID"
echo -e "${RED}Server exited.${NC}"
cleanup
