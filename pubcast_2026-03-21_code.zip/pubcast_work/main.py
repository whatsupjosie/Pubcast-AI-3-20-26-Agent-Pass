"""
PubCast AI â€” main.py
â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
Phase 1 complete + Phase 2 PubWorld/Voxel additions.

Start:  uvicorn main:app --reload --port 8000
Health: curl http://localhost:8000/api/health
"""

from __future__ import annotations

import asyncio
import logging
import os
import time
import uuid
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any, Dict, List, Optional

import uvicorn
from fastapi import FastAPI, File, Form, Request, Response, UploadFile, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
from starlette.websockets import WebSocketState

# â”€â”€ Module imports â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
from modules.hub import Hub
from modules.persistence import (
    allowed_upload_extension,
    append_jsonl,
    ensure_dirs,
    read_json,
    sanitize_filename,
    write_json,
)
from modules.models import BotConfig, ProductionState, UserState
from modules.cameras import CameraManager, CameraSource, CameraStatus, CameraTransport, create_default_cameras
from modules.recording import RecordingService, EncodingProfile, ContainerFormat
from modules.avatar import AvatarState, list_presets, load_avatar, save_avatar
from modules.bots import BotManager
from modules.credentials import CredentialStore
from modules.byok_manager import BYOKManager
from modules.byok_routes import mount_byok_routes
from modules.studio_control import StudioControl
from modules.studio_websocket import create_studio_websocket_endpoint
from modules.voxel_asset_manager import VoxelAssetManager
from modules.avatar_performer import AvatarPerformerManager
from modules.unity_bridge import UnityBridge
from modules.mocap_integration import MocapStreamManager
from modules.voxel_studio import (
    VoxelStudio, VoxelObject, VoxelPrimitive, VoxelShape, VoxelSize,
    LODLevel, DestructionProfile, DetonationType, PivotGroup,
)
from modules.pete import (
    Pete, SceneMarker as PeteSceneMarker, AutoCutCue as PeteAutoCutCue,
    CueType, CueAction,
)
from modules.pubworld_router import router as pubworld_ws_router, push_production_state_to_pubworld
from modules.mic_routes import router as mic_router
from modules.audio_devices import router as audio_devices_router
from modules.purfluous import SirPurfluous
from modules.jeremy_cricket import CricketKeeper
from modules.room_conductor import RoomConductor, create_room_conductor, RoomConductorConfig
from modules.universal_memory_system import UniversalMemorySystem, CharacterProfile
from modules.rooms import RoomManager
import modules.pubworld_blocks as pwb
import modules.voxel_llm_adapter as vla

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")
logger = logging.getLogger("pubcast.main")

# â”€â”€ Paths â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
BASE_DIR   = Path(__file__).resolve().parent
DATA_DIR   = BASE_DIR / "data"
ASSETS_DIR = BASE_DIR / "assets"
STATIC_DIR = BASE_DIR / "static"

# -------------------------------------------------------------------------
# Lifespan proxy
#
# The actual lifespan context manager, defined later in this module, cannot be
# referenced here directly because Python requires names to exist before they
# are used.  To avoid rearranging the file, we wrap the call to ``lifespan``
# in a proxy context manager.  The proxy will resolve the global name
# ``lifespan`` at runtime when the application starts, by which time
# ``lifespan`` has been defined.
from contextlib import asynccontextmanager as _lifespan_ctx

@_lifespan_ctx
async def _proxy_lifespan(app: "FastAPI"):
    # Defer to the real lifespan defined later in this module.  The global name
    # ``lifespan`` will be resolved at runtime.
    async with lifespan(app):  # type: ignore[name-defined]  # noqa: F821
        yield

# â”€â”€ FastAPI app â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
app = FastAPI(
    title="PubCast AI",
    version="2.0.0",
    description="Virtual broadcast studio with AI co-hosts, voxel world-building, and live production.",
    # Provide our proxy rather than referring to ``lifespan`` before it is defined
    lifespan=_proxy_lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.mount("/static",  StaticFiles(directory=str(STATIC_DIR)),  name="static")
app.mount("/assets",  StaticFiles(directory=str(ASSETS_DIR)),  name="assets")

templates = Jinja2Templates(directory=str(STATIC_DIR))

# Include the PubWorld websocket and API router at module import time.  This
# ensures that world endpoints (e.g., /pubworld/api/room-change) exist even
# when the FastAPI lifespan context is not invoked (for example during unit
# testing).  The router is idempotent; including it here does not prevent
# re‑inclusion in the lifespan function below for further setup.
app.include_router(pubworld_ws_router)
app.include_router(mic_router)
app.include_router(audio_devices_router)

# â”€â”€ Service singletons (created at startup) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
hub:               Optional[Hub]                   = None
cam:               Optional[CameraManager]            = None
rec:               Optional[RecordingService]         = None
bot_mgr:           Optional[BotManager]               = None
room_mgr:          Optional[RoomManager]              = None
cred_store:        Optional[CredentialStore]          = None
byok_mgr:          Optional[BYOKManager]              = None
studio_ctrl:       Optional[StudioControl]            = None
studio_ws_handler: Optional[Any]                      = None
voxel_asset_mgr:   Optional[VoxelAssetManager]       = None
performer_mgr:     Optional[AvatarPerformerManager]  = None
unity_bridge_mgr:  Optional[UnityBridge]               = None
mocap_mgr:         Optional[MocapStreamManager]        = None
voxel_studio:      Optional[VoxelStudio]               = None
pete:              Optional[Pete]                      = None
purfluous_mgr:    Optional[SirPurfluous]             = None
cricket_keeper:   Optional[CricketKeeper]            = None
room_conductor:   Optional[RoomConductor]            = None


@asynccontextmanager
async def lifespan(app: "FastAPI"):
    """
    Application lifespan — replaces deprecated @app.on_event("startup/shutdown").
    Services are started before yield, torn down cleanly after.
    """
    global hub, cam, rec, bot_mgr, room_mgr, cred_store
    global byok_mgr, studio_ctrl, studio_ws_handler
    global voxel_asset_mgr, performer_mgr, unity_bridge_mgr
    global mocap_mgr, voxel_studio, pete
    global purfluous_mgr, cricket_keeper, room_conductor

    ensure_dirs(DATA_DIR, ASSETS_DIR)

    # ── Core services ──────────────────────────────────────────────────────────
    hub        = Hub(DATA_DIR)
    cam        = create_default_cameras()
    rec        = RecordingService(DATA_DIR / "recordings", cam)
    bot_mgr    = BotManager(DATA_DIR, hub)
    room_mgr   = RoomManager()
    cred_store = CredentialStore(DATA_DIR / "credentials")
    app.state.hub = hub
    app.state.data_dir = DATA_DIR

    # ── Encoding profiles ──────────────────────────────────────────────────────
    rec.register_profile(EncodingProfile(
        profile_id="1080p30",
        name="1080p 30fps",
        container=ContainerFormat.MP4,
        video_codec="h264",
        audio_codec="aac",
        video_bitrate="6000k",
        audio_bitrate="192k",
        resolution="1920x1080",
        frame_rate="30",
        description="Broadcast-quality HD",
    ))
    rec.register_profile(EncodingProfile(
        profile_id="480i",
        name="480i Fallback",
        container=ContainerFormat.MP4,
        video_codec="h264",
        audio_codec="aac",
        video_bitrate="2000k",
        audio_bitrate="128k",
        resolution="854x480",
        frame_rate="30",
        description="Low-bandwidth fallback",
    ))
    rec.register_profile(EncodingProfile(
        profile_id="audio_only",
        name="Audio Only",
        container=ContainerFormat.WAV,
        video_codec=None,
        audio_codec="pcm_s16le",
        video_bitrate=None,
        audio_bitrate=None,
        resolution=None,
        frame_rate=None,
        description="Raw audio recording",
        is_audio_only=True,
    ))

    # ── BYOK system ────────────────────────────────────────────────────────────
    byok_mgr = BYOKManager(data_dir=DATA_DIR / "byok")
    # Guard against double-mount on --reload.
    if not getattr(app.state, "byok_mounted", False):
        mount_byok_routes(app, byok_mgr)
        app.state.byok_mounted = True
    else:
        app.state.byok_manager = byok_mgr
    logger.info("BYOK system initialised")
    bot_mgr.set_byok_manager(byok_mgr)
    cricket_keeper = CricketKeeper(DATA_DIR / "jeremy")
    await cricket_keeper.init()
    bot_mgr.set_cricket_keeper(cricket_keeper)

    # ── Room Conductor (Jeremy Cricket — room watcher + drama director) ────
    # Watches active rooms, calculates drama necessity, fires nudges to bots.
    # Uses UniversalMemorySystem for per-character memory (separate from the
    # per-character SQLite keeper above — that handles episodic recall;
    # this handles room-level orchestration).
    _memory_system = UniversalMemorySystem()
    room_conductor = await create_room_conductor(
        memory_system    = _memory_system,
        bot_manager      = bot_mgr,
        hub              = hub,
        adapter_registry = None,   # Phase 3: wire LLM adapters for reflection
        config           = RoomConductorConfig(),
    )
    logger.info("Room Conductor (Jeremy Cricket) initialised")

    purfluous_mgr = SirPurfluous(bot_manager=bot_mgr, hub=hub)

    async def _chat_callback(payload: Dict[str, Any]) -> None:
        room_id = payload.get("room", "main")
        user_id = payload.get("user_id") or payload.get("user") or "anon"
        text = payload.get("text", "")
        if purfluous_mgr is not None:
            await purfluous_mgr.watch_room(room_id)
            await purfluous_mgr.on_message(room_id, str(user_id), text)
        if room_conductor is not None:
            # Ensure this room is being watched (idempotent)
            asyncio.create_task(room_conductor.watch_room(room_id))
            asyncio.create_task(
                room_conductor.on_message(room_id, str(user_id), text)
            )
        if bot_mgr is not None and user_id != "__purfluous__":
            await bot_mgr.on_chat_message(payload)

    hub.on_chat_callback = _chat_callback

    # ── Studio Control Room ────────────────────────────────────────────────────
    # pete=None is safe: every self.pete call in studio_control.py is commented out.
    studio_ctrl       = StudioControl(hub=hub, pete=None, data_dir=DATA_DIR)
    studio_ws_handler = create_studio_websocket_endpoint(studio_ctrl)
    logger.info("Studio Control Room initialised")

    # ── Voxel Asset Manager ────────────────────────────────────────────────────
    voxel_asset_mgr = VoxelAssetManager(
        library_path=DATA_DIR / "voxel_library",
        pete=None,
    )
    logger.info("Voxel Asset Manager initialised")

    # ── Avatar Performer Manager (Rust animation bridge) ───────────────────────
    # Connects to the Rust animation crate at ws://localhost:8765.
    # Fails gracefully if the Rust binary is not yet compiled/running —
    # every other system is completely unaffected.
    performer_mgr = AvatarPerformerManager(ws_url="ws://localhost:8765")
    try:
        await asyncio.wait_for(performer_mgr.start(), timeout=3.0)
        logger.info("Avatar Performer Manager connected to Rust animation crate")
    except Exception as exc:
        logger.warning(
            "Avatar Performer Manager could not connect (%s) — "
            "avatar animation running in fallback mode", exc
        )

    # ── Unity Bridge ──────────────────────────────────────────────────────────
    unity_bridge_mgr = UnityBridge(hub)
    # The PubWorld router has already been registered at module load time to
    # expose endpoints outside of the lifespan context.  Here we avoid
    # re‑registering it to prevent duplicate routes.  Unity bridge still
    # initialises and uses the hub for event propagation.
    logger.info("Unity bridge initialised")

    # ── Mocap Stream Manager ───────────────────────────────────────────────────
    mocap_mgr = MocapStreamManager(
        hub=hub,
        performer_mgr=performer_mgr,
        studio_ctrl=studio_ctrl,
        pete=None,
    )
    logger.info("Mocap Stream Manager initialised")

    # ── VoxelStudio ────────────────────────────────────────────────────────────
    voxel_studio = VoxelStudio(data_dir=DATA_DIR / "voxel_studio")
    logger.info(
        "VoxelStudio initialised  (%d objects, %d primitives)",
        len(voxel_studio.list_objects()),
        len(voxel_studio.list_primitives()),
    )

    # ── Pete — Production Engine ───────────────────────────────────────────────
    async def _pete_auto_cut(reason: str = "", scene_s: float = 0.0) -> None:
        logger.info("Pete auto-cut: %s at %.1fs", reason, scene_s)
        if hub:
            await hub.broadcast_system_event({
                "type":    "pete_auto_cut",
                "payload": {"reason": reason, "scene_s": scene_s},
            })

    async def _pete_auto_action(reason: str = "") -> None:
        logger.info("Pete auto-action: %s", reason)
        if hub:
            await hub.broadcast_system_event({
                "type":    "pete_auto_action",
                "payload": {"reason": reason},
            })

    irm_ctrl = None
    try:
        from modules.irm import IRMController
        irm_ctrl = IRMController()
    except Exception:
        pass

    pete = Pete(
        hub       = hub,
        irm       = irm_ctrl,
        rec       = rec,
        on_cut    = _pete_auto_cut,
        on_action = _pete_auto_action,
    )
    mocap_mgr.pete = pete
    voxel_asset_mgr.pete = pete
    logger.info("Pete initialised")

    logger.info("PubCast AI started. DATA=%s", DATA_DIR)

    yield  # ← server is live from here

    # ── Shutdown ───────────────────────────────────────────────────────────────
    if mocap_mgr:
        try:
            await mocap_mgr.stop_stream()
        except Exception:
            pass
    if pete:
        try:
            if pete.deferred_report_has_items():
                await pete._surface_report()
        except Exception:
            pass
    if room_conductor:
        try:
            await room_conductor.shutdown()
        except Exception:
            pass
    if purfluous_mgr:
        try:
            await purfluous_mgr.shutdown()
        except Exception:
            pass
    if cricket_keeper:
        try:
            await cricket_keeper.close_all()
        except Exception:
            pass
    if performer_mgr:
        try:
            await performer_mgr.stop()
        except Exception:
            pass
    logger.info("PubCast AI shut down cleanly")


# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# UTILITIES
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

def _get_or_set_uid(request: Request, response: Response) -> str:
    uid = request.cookies.get("pubcast_uid")
    if not uid:
        uid = str(uuid.uuid4())
        user_file = DATA_DIR / "users" / f"{uid}.json"
        if not user_file.exists():
            write_json(user_file, UserState(user_id=uid).dict())
        response.set_cookie("pubcast_uid", uid, max_age=60 * 60 * 24 * 365, httponly=True, samesite="lax")
    return uid


def _detect_cloud_providers() -> Dict[str, bool]:
    return {
        "anthropic": bool(os.getenv("ANTHROPIC_API_KEY", "").strip()),
        "openai":    bool(os.getenv("OPENAI_API_KEY",    "").strip()),
        "gemini":    bool(
            os.getenv("GEMINI_API_KEY",  "").strip() or
            os.getenv("GOOGLE_API_KEY",  "").strip()
        ),
    }


# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# STATIC / PAGE ROUTES
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    resp = templates.TemplateResponse("index.html", {"request": request})
    _get_or_set_uid(request, resp)
    return resp


@app.get("/control", response_class=HTMLResponse)
async def control_page(request: Request):
    return templates.TemplateResponse("control.html", {"request": request})


@app.get("/dressing", response_class=HTMLResponse)
async def dressing_page(request: Request):
    return templates.TemplateResponse("dressing.html", {"request": request})


@app.get("/stage", response_class=HTMLResponse)
async def stage_page(request: Request):
    """The 3D PubWorld stage — Three.js environment with holographic avatars."""
    return templates.TemplateResponse("stage.html", {"request": request})


@app.get("/dressing-foundry", response_class=HTMLResponse)
async def dressing_foundry_page(request: Request):
    return templates.TemplateResponse("dressing_foundry.html", {"request": request})


@app.get("/bar", response_class=HTMLResponse)
async def bar_page(request: Request):
    return templates.TemplateResponse("bar.html", {"request": request})


@app.get("/world", response_class=HTMLResponse)
async def world_page(request: Request):
    return templates.TemplateResponse("world.html", {"request": request})


@app.get("/builder", response_class=HTMLResponse)
async def builder_page(request: Request):
    return templates.TemplateResponse("builder.html", {"request": request})


@app.get("/gallery", response_class=HTMLResponse)
async def gallery_page(request: Request):
    return templates.TemplateResponse("gallery.html", {"request": request})


@app.get("/analytics", response_class=HTMLResponse)
async def analytics_page(request: Request):
    return templates.TemplateResponse("analytics.html", {"request": request})


# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# HEALTH
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

@app.get("/api/health")
async def health():
    """
    Return a basic health check for the server.  This endpoint tries to
    summarise the state of key subsystems (cameras, recording, AI providers,
    and websocket rooms) in a fault‑tolerant way.  If a subsystem is not
    initialised (for example, when running unit tests without the lifespan
    context), the health check will gracefully report null or default
    values instead of raising an exception.  This allows automated tests to
    exercise API routes even when startup routines have not run.
    """
    providers = _detect_cloud_providers()

    # Cameras: guard against cam being None or partially initialised.
    camera_info: Dict[str, Optional[Any]] = {
        "program": None,
        "preview": None,
        "count": 0,
    }
    if cam is not None:
        try:
            prog_src = cam.get_program_source()
            prev_src = cam.get_preview_source()
            camera_info["program"] = prog_src.source_id if prog_src else None
            camera_info["preview"] = prev_src.source_id if prev_src else None
            try:
                camera_info["count"] = len(cam.list_sources())
            except Exception:
                # In some test contexts list_sources may raise; fall back to 0.
                camera_info["count"] = 0
        except Exception:
            # If the camera manager is present but not fully initialised, leave defaults.
            pass

    # Recording: guard against rec being None.
    recording_info: Dict[str, Any] = {"active_sessions": 0}
    if rec is not None:
        try:
            active = sum(1 for s in rec.list_sessions() if getattr(s.state, "value", None) == "active")
            recording_info["active_sessions"] = active
        except Exception:
            recording_info["active_sessions"] = 0

    # WebSocket rooms: guard against hub being None.
    rooms_info: Dict[str, int] = {}
    if hub is not None:
        try:
            rooms_info = {r: len(conns) for r, conns in hub.rooms.items()}
        except Exception:
            rooms_info = {}

    return {
        "status": "ok",
        "timestamp": time.time(),
        "cameras": camera_info,
        "recording": recording_info,
        "ai_providers": providers,
        "ws_rooms": rooms_info,
    }


# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# USER / IDENTITY
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

@app.get("/api/me")
async def get_me(request: Request, response: Response):
    uid = _get_or_set_uid(request, response)
    f = DATA_DIR / "users" / f"{uid}.json"
    data = read_json(f) if f.exists() else {"user_id": uid, "display_name": "New User"}
    return JSONResponse(data)


@app.get("/api/state/user")
async def read_user_state(request: Request, response: Response):
    uid = _get_or_set_uid(request, response)
    f = DATA_DIR / "users" / f"{uid}.json"
    return read_json(f) if f.exists() else {"user_id": uid, "display_name": "New User"}


@app.post("/api/state/user")
async def save_user_state(request: Request, response: Response, payload: Dict[str, Any]):
    uid = _get_or_set_uid(request, response)
    user_file = DATA_DIR / "users" / f"{uid}.json"
    current = read_json(user_file) if user_file.exists() else {}
    current.update(payload or {})
    write_json(user_file, current)
    # Broadcast presence updates only when the hub is available.  When running
    # tests outside of the lifespan context, hub may be None.
    if hub is not None:
        try:
            await hub.broadcast_presence_update(uid, current.get("display_name", "User"))
        except Exception:
            logger.warning("Failed to broadcast presence update")
    return {"ok": True}


# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# PRODUCTION STATE
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

@app.get("/api/state/production")
async def get_production_state():
    if hub is None:
        # Without a hub, return an empty production state.
        return {}
    return hub.get_production_state()


@app.post("/api/state/production")
async def set_production_state(payload: Dict[str, Any]):
    if hub is None:
        # Cannot update production state without a hub.  Log and return error.
        logger.warning("Attempted to set production state with no hub available")
        return JSONResponse({"ok": False, "error": "Hub unavailable"}, status_code=503)
    updated = hub.update_production_state(payload)
    event = {"type": "production_state", "payload": updated}
    await hub.broadcast_system_event(event)
    # If the PubWorld router is available, push state to connected world clients.
    await push_production_state_to_pubworld(updated)
    if unity_bridge_mgr:
        await unity_bridge_mgr.on_pubcast_event(event)
    return {"ok": True, "state": updated}


# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# CAMERAS
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

@app.get("/api/cameras")
async def list_cameras():
    """List available camera sources and current program/preview.

    If the camera subsystem has not been initialised (cam is None), this
    endpoint returns a 503 Service Unavailable with a clear message.  This
    prevents AttributeError exceptions when running unit tests outside of
    the lifespan context.
    """
    if cam is None:
        return JSONResponse(
            {"ok": False, "error": "Camera system unavailable"}, status_code=503
        )
    sources = cam.list_sources()
    statuses = {s.source_id: s for s in cam.list_status()}
    program = cam.get_program_source()
    preview = cam.get_preview_source()
    return {
        "sources": [
            {**vars(src), "transport": src.transport.value,
             "online": statuses.get(src.source_id, {}).online if src.source_id in {s.source_id for s in cam.list_status()} else None}
            for src in sources
        ],
        "program": program.source_id if program else None,
        "preview": preview.source_id if preview else None,
    }


@app.get("/api/cameras/program")
async def get_program():
    if cam is None:
        return JSONResponse({"ok": False, "error": "Camera system unavailable"}, status_code=503)
    src = cam.get_program_source()
    return {"program": vars(src) if src else None}


@app.post("/api/cameras/program")
async def set_program(payload: Dict[str, Any]):
    if cam is None:
        return JSONResponse({"ok": False, "error": "Camera system unavailable"}, status_code=503)
    source_id = payload.get("source_id", "")
    ok = cam.set_program_source(source_id)
    if ok and hub is not None:
        await hub.broadcast_system_event({"type": "camera_program", "payload": {"source_id": source_id}})
    return {"ok": ok}


@app.get("/api/cameras/preview")
async def get_preview():
    if cam is None:
        return JSONResponse({"ok": False, "error": "Camera system unavailable"}, status_code=503)
    src = cam.get_preview_source()
    return {"preview": vars(src) if src else None}


@app.post("/api/cameras/preview")
async def set_preview(payload: Dict[str, Any]):
    if cam is None:
        return JSONResponse({"ok": False, "error": "Camera system unavailable"}, status_code=503)
    source_id = payload.get("source_id", "")
    ok = cam.set_preview_source(source_id)
    return {"ok": ok}


@app.post("/api/cameras/cut")
async def cut():
    """Swap program and preview (hard cut)."""
    # If camera subsystem is unavailable, reject cuts.
    if cam is None:
        return JSONResponse({"ok": False, "error": "Camera system unavailable"}, status_code=503)
    prog = cam.get_program_source()
    prev = cam.get_preview_source()
    if prog and prev:
        cam.set_program_source(prev.source_id)
        cam.set_preview_source(prog.source_id)
        event = {"type": "camera_cut", "payload": {"new_program": prev.source_id, "new_preview": prog.source_id}}
        if hub is not None:
            await hub.broadcast_system_event(event)
        if unity_bridge_mgr:
            await unity_bridge_mgr.on_pubcast_event(event)
        return {"ok": True, "program": prev.source_id, "preview": prog.source_id}
    return JSONResponse({"ok": False, "error": "Need both program and preview set to cut."}, status_code=400)


@app.put("/api/cameras/{source_id}/status")
async def update_camera_status(source_id: str, payload: Dict[str, Any]):
    if cam is None:
        return JSONResponse({"ok": False, "error": "Camera system unavailable"}, status_code=503)
    cam.set_status(
        source_id,
        online=bool(payload.get("online", True)),
        latency_ms=payload.get("latency_ms"),
        frame_rate=payload.get("frame_rate"),
        notes=payload.get("notes"),
    )
    return {"ok": True}


# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# RECORDING
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

@app.get("/api/recording/profiles")
async def list_recording_profiles():
    if rec is None:
        return JSONResponse({"ok": False, "error": "Recording system unavailable"}, status_code=503)
    return {"profiles": [vars(p) for p in rec.list_profiles()]}


@app.get("/api/recording/sessions")
async def list_sessions():
    if rec is None:
        return JSONResponse({"ok": False, "error": "Recording system unavailable"}, status_code=503)
    return {"sessions": [s.to_dict() for s in rec.list_sessions()]}


class _StartSessionRequest(BaseModel):
    sources: List[str]
    profile_id: str = "1080p30"
    operator: str = "host"
    session_id: Optional[str] = None
    preset: Optional[str] = None
    host_override: bool = False
    countdown_seconds: int = 5


@app.post("/api/recording/sessions")
async def start_session(payload: _StartSessionRequest):
    if rec is None:
        return JSONResponse({"ok": False, "error": "Recording system unavailable"}, status_code=503)
    session = rec.start_session(
        session_id=payload.session_id,
        sources=payload.sources,
        profile_id=payload.profile_id,
        operator=payload.operator,
        preset=payload.preset,
        host_override=payload.host_override,
        countdown_seconds=payload.countdown_seconds,
    )
    event = {"type": "recording_start", "payload": session.to_dict()}
    if hub is not None:
        await hub.broadcast_system_event(event)
    if unity_bridge_mgr:
        await unity_bridge_mgr.on_pubcast_event(event)
    return {"session": session.to_dict()}


@app.post("/api/recording/sessions/{session_id}/activate")
async def activate_session(session_id: str):
    if rec is None:
        return JSONResponse({"ok": False, "error": "Recording system unavailable"}, status_code=503)
    session = rec.activate_session(session_id)
    if hub is not None:
        await hub.broadcast_system_event({"type": "recording_active", "payload": session.to_dict()})
    return {"session": session.to_dict()}


@app.post("/api/recording/sessions/{session_id}/stop")
async def stop_session(session_id: str):
    if rec is None:
        return JSONResponse({"ok": False, "error": "Recording system unavailable"}, status_code=503)
    session = rec.stop_session(session_id)
    event = {"type": "recording_stop", "payload": session.to_dict()}
    if hub is not None:
        await hub.broadcast_system_event(event)
    if unity_bridge_mgr:
        await unity_bridge_mgr.on_pubcast_event(event)
    return {"session": session.to_dict()}


@app.post("/api/recording/sessions/{session_id}/pause")
async def pause_session(session_id: str, payload: Dict[str, Any]):
    if rec is None:
        return JSONResponse({"ok": False, "error": "Recording system unavailable"}, status_code=503)
    paused = bool(payload.get("paused", True))
    session = rec.pause_session(session_id, paused)
    return {"session": session.to_dict()}


@app.post("/api/recording/sessions/{session_id}/marker")
async def add_marker(session_id: str, payload: Dict[str, Any]):
    if rec is None:
        return JSONResponse({"ok": False, "error": "Recording system unavailable"}, status_code=503)
    marker = rec.mark_moment(
        session_id,
        label=payload.get("label", "mark"),
        operator=payload.get("operator"),
    )
    return {"marker": vars(marker)}


@app.post("/api/recording/sessions/{session_id}/archive")
async def archive_session(session_id: str):
    session = rec.archive_session(session_id)
    return {"session": session.to_dict()}


@app.get("/api/recording/sessions/{session_id}/export")
async def export_session(session_id: str, container: str = "mp4"):
    fmt = ContainerFormat(container)
    zip_path = rec.export_session(session_id, container=fmt)
    return FileResponse(str(zip_path), media_type="application/zip",
                        filename=f"session_{session_id}.zip")


@app.get("/api/recording/storage")
async def recording_storage():
    base = rec.base_dir if hasattr(rec, "base_dir") else Path("data/recordings")
    try:
        total = sum(f.stat().st_size for f in base.rglob("*") if f.is_file())
        return {"bytes": total, "mb": round(total / (1024 * 1024), 2)}
    except Exception:
        return {"bytes": 0, "mb": 0}


@app.get("/api/recording/privacy")
async def recording_privacy():
    return {"privacy": rec.privacy_matrix()}


# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# AVATARS
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

@app.get("/api/avatars/presets")
async def avatar_presets():
    return {"presets": [p.dict() for p in list_presets()]}


@app.get("/api/avatars/me")
async def get_my_avatar(request: Request, response: Response):
    uid = _get_or_set_uid(request, response)
    return load_avatar(DATA_DIR, uid).dict()


@app.post("/api/avatars/me")
async def save_my_avatar(request: Request, response: Response, payload: Dict[str, Any]):
    uid = _get_or_set_uid(request, response)
    state = save_avatar(DATA_DIR, uid, payload)
    event = {"type": "avatar_update", "payload": {"user_id": uid, **state.dict()}}
    # Only broadcast avatar updates if the hub exists.  When running tests
    # outside of the lifespan context (where hub is None), broadcasting would
    # otherwise raise an AttributeError.  Similarly, defer unity bridge
    # notifications to when the bridge is available.
    if hub is not None:
        try:
            await hub.broadcast_system_event(event)
        except Exception:
            # Log but do not crash the API call; failing to broadcast is
            # acceptable during tests or degraded modes.
            logger.warning("Failed to broadcast avatar update via hub")
    if unity_bridge_mgr is not None:
        try:
            await unity_bridge_mgr.on_pubcast_event(event)
        except Exception:
            logger.warning("Failed to forward avatar update to unity bridge")
    return state.dict()


@app.get("/api/avatars/{user_id}")
async def get_user_avatar(user_id: str):
    return load_avatar(DATA_DIR, user_id).dict()


# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# BOTS
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

@app.get("/api/bots")
async def list_bots(request: Request, response: Response):
    if bot_mgr is None:
        return JSONResponse({"error": "Bot manager not initialised"}, status_code=503)
    uid = _get_or_set_uid(request, response)
    bots = bot_mgr.list_configs()
    return {"bots": [b.dict() for b in bots if b.owner_id == uid]}


@app.post("/api/bots")
async def create_bot(request: Request, response: Response, payload: Dict[str, Any]):
    uid = _get_or_set_uid(request, response)
    payload["owner_id"] = uid
    config = BotConfig(**payload)
    bot_mgr.upsert_config(config)
    return {"ok": True, "bot": config.dict()}


@app.get("/api/bots/{bot_id}")
async def get_bot(bot_id: str, request: Request, response: Response):
    uid = _get_or_set_uid(request, response)
    config = bot_mgr.get_config(bot_id)
    if not config:
        return JSONResponse({"error": "not found"}, status_code=404)
    if config.owner_id != uid:
        return JSONResponse({"error": "forbidden"}, status_code=403)
    return config.dict()


@app.put("/api/bots/{bot_id}")
async def update_bot(bot_id: str, request: Request, response: Response, payload: Dict[str, Any]):
    uid = _get_or_set_uid(request, response)
    existing = bot_mgr.get_config(bot_id)
    if not existing:
        return JSONResponse({"error": "not found"}, status_code=404)
    if existing.owner_id != uid:
        return JSONResponse({"error": "forbidden"}, status_code=403)
    merged = {**existing.dict(), **payload, "bot_id": bot_id, "owner_id": uid}
    config = BotConfig(**merged)
    bot_mgr.upsert_config(config)
    return {"ok": True, "bot": config.dict()}


@app.delete("/api/bots/{bot_id}")
async def delete_bot(bot_id: str, request: Request, response: Response):
    uid = _get_or_set_uid(request, response)
    config = bot_mgr.get_config(bot_id)
    if not config:
        return JSONResponse({"error": "not found"}, status_code=404)
    if config.owner_id != uid:
        return JSONResponse({"error": "forbidden"}, status_code=403)
    bot_mgr.delete_config(bot_id)
    return {"ok": True}


@app.post("/api/bots/{bot_id}/nudge")
async def nudge_bot(bot_id: str, request: Request, response: Response):
    uid = _get_or_set_uid(request, response)
    config = bot_mgr.get_config(bot_id)
    if not config:
        return JSONResponse({"error": "not found"}, status_code=404)
    if config.owner_id != uid:
        return JSONResponse({"error": "forbidden"}, status_code=403)
    try:
        body = await request.json()
    except Exception:
        body = {}
    room = body.get("room") or (config.rooms[0] if config.rooms else None)
    hint = body.get("hint", "Say something interesting to the room.")
    if not room:
        return JSONResponse({"error": "no room and bot has no default room"}, status_code=400)
    fired = await bot_mgr.nudge(room, hint)
    return {"ok": fired, "room": room}



# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# CREDENTIALS (BYOK)
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

@app.post("/api/credentials")
async def store_credential(request: Request, response: Response, payload: Dict[str, Any]):
    from modules.credentials import StoredModel, SecretReference
    uid = _get_or_set_uid(request, response)
    model_id  = str(payload.get("model_id",  payload.get("key_name", "")))
    provider  = str(payload.get("provider", "custom"))
    api_key   = str(payload.get("api_key",  payload.get("key_value", "")))
    if not model_id or not api_key:
        return JSONResponse({"error": "model_id and api_key required"}, status_code=400)
    import time as _t
    model = StoredModel(
        model_id=model_id,
        provider=provider,
        model_name=str(payload.get("model_name", model_id)),
        status="active",
        created_at=_t.time(),
    )
    cred_store.upsert_model(uid, model, secrets={"api_key": api_key})
    return {"ok": True, "model_id": model_id}


@app.get("/api/credentials")
async def list_credentials(request: Request, response: Response):
    uid = _get_or_set_uid(request, response)
    models = cred_store.list_models(uid)
    return {"credentials": [
        {"model_id": m.model_id, "provider": m.provider, "model_name": m.model_name,
         "status": m.status, "created_at": m.created_at}
        for m in models
    ]}


@app.delete("/api/credentials/{model_id}")
async def delete_credential(model_id: str, request: Request, response: Response):
    uid = _get_or_set_uid(request, response)
    cred_store.delete_model(uid, model_id)
    return {"ok": True}


# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# UPLOADS / VOD
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

@app.post("/api/upload")
async def upload_file(
    request: Request,
    response: Response,
    file: UploadFile = File(...),
    target: Optional[str] = Form(None),
):
    uid = _get_or_set_uid(request, response)
    filename = sanitize_filename(file.filename)
    if not allowed_upload_extension(filename):
        return JSONResponse({"ok": False, "error": "Unsupported file type."}, status_code=400)
    content = await file.read()
    if len(content) > 5 * 1024 * 1024:
        return JSONResponse({"ok": False, "error": "File too large (limit 5 MB)."}, status_code=400)
    dst_dir = ASSETS_DIR / "vod" if target == "vod" else ASSETS_DIR / "uploads" / uid
    dst_dir.mkdir(parents=True, exist_ok=True)
    with open(dst_dir / filename, "wb") as f:
        f.write(content)
    return {"ok": True, "path": f"assets/{'vod' if target == 'vod' else f'uploads/{uid}'}/{filename}"}


@app.get("/api/vod")
async def list_vod():
    vod_dir = ASSETS_DIR / "vod"
    if not vod_dir.exists():
        return {"files": []}
    files = [
        {"name": f.name, "size": f.stat().st_size, "url": f"/assets/vod/{f.name}"}
        for f in sorted(vod_dir.iterdir()) if f.is_file() and not f.name.startswith(".")
    ]
    return {"files": files}


# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# PUBWORLD â€” SCENES
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

@app.get("/api/pubworld/scenes")
async def list_scenes():
    from modules.pubworld import list_scenes as _list_scenes
    scenes = _list_scenes(DATA_DIR)
    return {"scenes": [s.dict() for s in scenes]}


@app.post("/api/pubworld/scenes")
async def create_scene(payload: Dict[str, Any]):
    from modules.pubworld import create_scene as _create_scene
    scene = _create_scene(DATA_DIR, payload.get("name", "Untitled"), payload.get("description", ""))
    return {"scene": scene.dict()}


@app.get("/api/pubworld/scenes/{scene_id}")
async def get_scene(scene_id: str):
    from modules.pubworld import get_scene as _get_scene
    scene = _get_scene(DATA_DIR, scene_id)
    if not scene:
        return JSONResponse({"error": "not found"}, status_code=404)
    return scene.dict()


# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# PUBWORLD â€” PROPS (Voxel objects in scenes)
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

@app.get("/api/pubworld/props")
async def list_props(scene_id: Optional[str] = None):
    props = pwb.list_props(DATA_DIR, scene_id=scene_id)
    return {"props": [p.dict() for p in props]}


@app.get("/api/pubworld/props/{prop_id}")
async def get_prop(prop_id: str):
    try:
        prop = pwb.get_prop(DATA_DIR, prop_id)
        return prop.dict()
    except FileNotFoundError:
        return JSONResponse({"error": "not found"}, status_code=404)


class _CreatePropRequest(BaseModel):
    scene_id: str
    label: str
    description: str = ""
    blocks: List[Dict[str, Any]]
    variants: Optional[List[Dict[str, Any]]] = None


@app.post("/api/pubworld/props")
async def create_prop(payload: _CreatePropRequest):
    prop = pwb.create_prop(
        DATA_DIR,
        payload.scene_id,
        payload.label,
        payload.description,
        payload.blocks,
        variants=payload.variants,
    )
    return {"prop": prop.dict()}


@app.put("/api/pubworld/props/{prop_id}/variants")
async def update_variants(prop_id: str, payload: Dict[str, Any]):
    prop = pwb.update_prop_variants(DATA_DIR, prop_id, payload.get("variants", []))
    return {"prop": prop.dict()}


# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# PUBWORLD â€” PROTOTYPES (shared prop library)
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

class _SavePrototypeRequest(BaseModel):
    label: str
    description: str = ""
    blocks: List[Dict[str, Any]]
    links: Optional[List[Dict[str, Any]]] = None
    category: Optional[str] = None
    era: Optional[str] = None
    vibe: Optional[str] = None
    size: Optional[str] = None
    region: Optional[str] = None
    tags: Optional[List[str]] = None
    contributed_by: Optional[str] = None
    shared: bool = False
    source_prompt: Optional[str] = None
    generation_source: str = "manual"


@app.post("/api/pubworld/prototypes")
async def save_prototype(payload: _SavePrototypeRequest):
    proto = pwb.save_prototype(
        DATA_DIR,
        payload.label,
        payload.description,
        payload.blocks,
        links=payload.links,
        category=payload.category,
        era=payload.era,
        vibe=payload.vibe,
        size=payload.size,
        region=payload.region,
        tags=payload.tags,
        contributed_by=payload.contributed_by,
        shared=payload.shared,
        source_prompt=payload.source_prompt,
        generation_source=payload.generation_source,
    )
    return {"prototype": proto.dict()}


@app.get("/api/pubworld/prototypes")
async def list_prototypes(
    category: Optional[str] = None,
    era: Optional[str] = None,
    vibe: Optional[str] = None,
    size: Optional[str] = None,
    region: Optional[str] = None,
    tag: Optional[str] = None,
    shared_only: bool = False,
    generation_source: Optional[str] = None,
    search: Optional[str] = None,
):
    protos = pwb.list_prototypes(DATA_DIR)
    # Client-side filtering (the pubworld_blocks version is simple)
    if category:
        protos = [p for p in protos if getattr(p, "category", None) == category]
    if era:
        protos = [p for p in protos if getattr(p, "era", None) == era]
    if vibe:
        protos = [p for p in protos if getattr(p, "vibe", None) == vibe]
    if tag:
        protos = [p for p in protos if tag in getattr(p, "tags", [])]
    if search:
        q = search.lower()
        protos = [p for p in protos if q in p.label.lower() or q in (p.description or "").lower()]
    return {"prototypes": [p.dict() for p in protos]}


# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# PUBWORLD â€” VOXEL GENERATION (AI text-to-blocks)
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

@app.get("/api/pubworld/generate/status")
async def voxel_gen_status():
    providers = _detect_cloud_providers()
    return {
        "local_available": True,
        "cloud_available": any(providers.values()),
        "providers": providers,
        "default": "local",
    }


class _GenerateRequest(BaseModel):
    prompt: str
    scene_id: Optional[str] = None
    label: Optional[str] = None
    description: str = ""
    use_cloud: bool = False
    provider: str = "auto"


@app.post("/api/pubworld/generate")
async def generate_voxel(payload: _GenerateRequest):
    if payload.use_cloud and any(_detect_cloud_providers().values()):
        result, provider_used = await vla.generate_with_cloud(payload.prompt, provider=payload.provider)
        if result:
            label, blocks = result
            source = f"ai_cloud:{provider_used}"
        else:
            label, blocks_obj = pwb.generate_from_prompt(payload.prompt)
            blocks = [b.dict() for b in blocks_obj]
            source = "local_fallback"
    else:
        label, blocks_obj = pwb.generate_from_prompt(payload.prompt)
        blocks = [b.dict() for b in blocks_obj]
        source = "local"

    label = payload.label or label

    if payload.scene_id:
        prop = pwb.create_prop(DATA_DIR, payload.scene_id, label, payload.description, blocks)
        return {"prop": prop.dict(), "generated": blocks, "label": label, "source": source}
    return {"label": label, "generated": blocks, "source": source}


# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# PUBWORLD â€” TRACKERS
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

@app.post("/api/pubworld/trackers")
async def create_tracker(payload: Dict[str, Any]):
    tracker = pwb.attach_tracker(
        DATA_DIR,
        kind=payload.get("kind", "prop"),
        target_prop=payload.get("target_prop"),
        target_block_index=payload.get("target_block_index"),
    )
    return {"tracker": tracker.dict()}


@app.get("/api/pubworld/trackers/{tracker_id}")
async def get_tracker(tracker_id: str):
    try:
        return pwb.get_tracker(DATA_DIR, tracker_id).dict()
    except FileNotFoundError:
        return JSONResponse({"error": "not found"}, status_code=404)


@app.post("/api/pubworld/trackers/{tracker_id}/samples")
async def push_samples(tracker_id: str, payload: Dict[str, Any]):
    tracker = pwb.append_samples(
        DATA_DIR, tracker_id,
        samples=payload.get("samples", []),
        set_baseline=bool(payload.get("set_baseline", False)),
    )
    delta = pwb.continuity_delta(tracker)
    return {"tracker": tracker.dict(), "delta": delta}


# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# PUBWORLD â€” BUILDER PRESETS
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

@app.get("/api/pubworld/presets")
async def list_builder_presets():
    presets = pwb.list_builder_presets(DATA_DIR)
    return {"presets": [p.dict() for p in presets]}


@app.post("/api/pubworld/presets")
async def save_builder_preset(payload: Dict[str, Any]):
    preset = pwb.save_builder_preset(
        DATA_DIR,
        name=payload.get("name", "Untitled"),
        blocks_data=payload.get("blocks", []),
        links_data=payload.get("links"),
    )
    return {"preset": preset.dict()}


# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
@app.get("/api/purfluous/scenes")
async def purfluous_scenes():
    if purfluous_mgr is None:
        return {"scenes": []}
    return {"scenes": purfluous_mgr.all_scene_states()}


@app.get("/api/jeremy/health")
async def jeremy_health():
    if cricket_keeper is None:
        return {"characters": []}
    return {"characters": await cricket_keeper.health_all()}


# -- WebSocket: specific routes registered BEFORE catch-all /ws/{room} --

@app.websocket("/ws/unity")
async def websocket_unity(websocket: WebSocket):
    """Unity WebSocket connection — bidirectional PubCast ↔ Unity bridge."""
    if unity_bridge_mgr is None:
        await websocket.close(code=1013)
        return
    await unity_bridge_mgr.handle_connection(websocket)


@app.websocket("/ws/studio")
async def websocket_studio(websocket: WebSocket):
    """Dedicated WebSocket for Studio Control Room real-time events."""
    if studio_ws_handler is None:
        await websocket.close(code=1013)  # Try Again Later
        return
    await studio_ws_handler.connect(websocket)
    try:
        while True:
            data = await websocket.receive_json()
            await studio_ws_handler.handle_message(websocket, data)
    except WebSocketDisconnect:
        await studio_ws_handler.disconnect(websocket)
    except Exception:
        if websocket.application_state == WebSocketState.CONNECTED:
            await websocket.close(code=1011)
        await studio_ws_handler.disconnect(websocket)



# WEBSOCKET â€” main event bus
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

@app.websocket("/ws/{room}")
async def websocket_endpoint(ws: WebSocket, room: str):
    # If the hub is not initialised (running outside the lifespan), immediately close the WebSocket.
    # Without the hub, PubCast cannot handle room connections.
    if hub is None:
        await ws.close(code=1011)
        return
    await hub.connect(ws, room)
    try:
        while True:
            msg = await ws.receive_text()
            await hub.handle_message(ws, room, msg)
    except WebSocketDisconnect:
        await hub.disconnect(ws, room)
    except Exception:
        if ws.application_state == WebSocketState.CONNECTED:
            await ws.close(code=1011)
        await hub.disconnect(ws, room)


# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# ENTRYPOINT
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=False, log_level="info")


# ═══════════════════════════════════════════════════════════════════════════════
# LIGHTING SYSTEM
# ═══════════════════════════════════════════════════════════════════════════════

from modules.lighting import LightingManager as _LightingManager
_lighting_mgr: Optional[_LightingManager] = None


def _get_lighting() -> _LightingManager:
    global _lighting_mgr
    if _lighting_mgr is None:
        _lighting_mgr = _LightingManager()
    return _lighting_mgr


@app.get("/api/lighting/presets")
async def lighting_list_presets():
    """List all available lighting presets."""
    presets = []
    for pid in _get_lighting().list_presets():
        p = _get_lighting().get_preset(pid)
        if p:
            presets.append({"preset_id": p.preset_id, "name": p.name, "description": p.description})
    return {"presets": presets}


@app.get("/api/lighting/active")
async def lighting_get_active():
    """Get the currently active lighting preset."""
    p = _get_lighting().get_active()
    if not p:
        return {"active": None}
    return {"active": p.to_dict()}


@app.post("/api/lighting/apply/{preset_id}")
async def lighting_apply(preset_id: str):
    """Apply a lighting preset and broadcast to all rooms."""
    result = await _get_lighting().apply_preset(preset_id)
    if result.get("ok"):
        event = {"type": "lighting_update", "preset_id": preset_id, "preset": result.get("preset")}
        if hub is not None:
            await hub.broadcast_system_event(event)
        if unity_bridge_mgr:
            await unity_bridge_mgr.on_pubcast_event(event)
    return result


# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# VOXEL BRIDGE (Twin Engine â€” C++ renderer connection)
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

_bridge: Optional[Any] = None  # VoxelBridge instance, lazy-init


def _get_bridge():
    global _bridge
    if _bridge is None:
        from modules.bridge import VoxelBridge
        _bridge = VoxelBridge(DATA_DIR)
    return _bridge


@app.get("/api/bridge/status")
async def bridge_status():
    """Connection status of the twin-engine C++ bridge."""
    try:
        b = _get_bridge()
        metrics = b._metrics
        return {
            "status":          b._status.value,
            "commands_sent":   metrics.commands_sent,
            "commands_failed": metrics.commands_failed,
            "avg_latency_ms":  metrics.avg_latency_ms,
            "fps":             metrics.fps,
            "gpu_health":      metrics.gpu_health,
            "queue_depth":     metrics.queue_depth,
        }
    except Exception as exc:
        return {"status": "unavailable", "error": str(exc)}


@app.post("/api/bridge/connect")
async def bridge_connect(payload: Dict[str, Any]):
    """Attempt to connect the Python â†” C++ bridge."""
    try:
        b = _get_bridge()
        create = bool(payload.get("create_shared", False))
        ok = b.connect(create_shared=create)
        return {"ok": ok, "status": b._status.value}
    except Exception as exc:
        return JSONResponse({"ok": False, "error": str(exc)}, status_code=500)


@app.post("/api/bridge/command")
async def bridge_command(payload: Dict[str, Any]):
    """Send a command to the C++ engine via the bridge."""
    try:
        cmd_type_str = str(payload.get("command", "HEARTBEAT")).upper()
        b = _get_bridge()
        success = b.send_command(cmd_type_str, payload.get("payload", {}), int(payload.get("priority", 0)))
        return {"ok": success, "command": cmd_type_str}
    except Exception as exc:
        return JSONResponse({"ok": False, "error": str(exc)}, status_code=500)


@app.post("/api/bridge/ptz")
async def bridge_ptz(payload: Dict[str, Any]):
    """PTZ (pan/tilt/zoom) control command to the C++ renderer."""
    try:
        b = _get_bridge()
        ok = b.send_command("PTZ", {
            "camera_id": payload.get("camera_id", "main"),
            "pan":       float(payload.get("pan",  0.0)),
            "tilt":      float(payload.get("tilt", 0.0)),
            "zoom":      float(payload.get("zoom", 1.0)),
        }, priority=1)
        return {"ok": ok}
    except Exception as exc:
        return JSONResponse({"ok": False, "error": str(exc)}, status_code=500)


# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# CIRCUIT BREAKER STATUS (system health endpoint)
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

@app.get("/api/health/breakers")
async def breaker_health():
    """Returns the state of all registered circuit breakers."""
    from modules.circuit_breaker import all_breaker_stats
    return {"breakers": all_breaker_stats()}


# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# ADVANCED CAMERAS (cameras_advanced.py â€” full PTZ + monitoring)
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

_adv_cam: Optional[Any] = None  # AdvancedCameraManager, lazy-init


def _get_adv_cam():
    global _adv_cam
    if _adv_cam is None:
        from modules.cameras_advanced import create_default_cameras as _create_adv
        _adv_cam = _create_adv()
    return _adv_cam


@app.get("/api/cameras/advanced")
async def advanced_cameras():
    """Full camera stats from the advanced camera manager (PTZ, health, etc.)"""
    try:
        mgr = _get_adv_cam()
        return mgr.get_all_stats()
    except Exception as exc:
        return JSONResponse({"error": str(exc)}, status_code=500)


@app.post("/api/cameras/advanced/cut/{camera_id}")
async def advanced_cut(camera_id: str):
    """Hard cut to camera via advanced manager."""
    try:
        mgr = _get_adv_cam()
        ok = await mgr.cut_to_camera(camera_id)
        if ok and hub is not None:
            # Broadcast the cut event only when the hub is available.
            try:
                await hub.broadcast_system_event({"type": "camera_cut", "payload": {"camera_id": camera_id}})
            except Exception:
                logger.warning("Failed to broadcast camera_cut event")
        return {"ok": ok}
    except Exception as exc:
        return JSONResponse({"ok": False, "error": str(exc)}, status_code=500)


@app.post("/api/cameras/advanced/transition")
async def advanced_transition(payload: Dict[str, Any]):
    """Auto-transition (dissolve) to preview camera."""
    try:
        mgr = _get_adv_cam()
        duration = float(payload.get("duration_seconds", 1.0))
        ok = await mgr.auto_transition(duration)
        return {"ok": ok, "duration": duration}
    except Exception as exc:
        return JSONResponse({"ok": False, "error": str(exc)}, status_code=500)


# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# MOTION CAPTURE / AVATAR SYSTEM (avatar_motion.py)
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

@app.get("/api/motion/avatars")
async def list_motion_avatars():
    """List available motion-capture avatar presets."""
    try:
        from modules.avatar_motion import AvatarPreset
        return {"presets": [p.value for p in AvatarPreset]}
    except Exception as exc:
        return JSONResponse({"error": str(exc)}, status_code=500)


@app.post("/api/motion/frame")
async def push_motion_frame(payload: Dict[str, Any]):
    """Ingest a live motion-capture frame and broadcast it to all rooms."""
    # Broadcast motion frames only if the hub is initialised; otherwise, drop silently.
    if hub is not None:
        try:
            await hub.broadcast_system_event({"type": "motion_frame", "payload": payload})
        except Exception:
            logger.warning("Failed to broadcast motion_frame event")
    return {"ok": True}


# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# SURFACES (placeable media surfaces in PubWorld rooms)
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

_surface_mgr: Optional[Any] = None

def _get_surfaces():
    global _surface_mgr
    if _surface_mgr is None:
        from modules.surfaces import SurfaceManager
        _surface_mgr = SurfaceManager(DATA_DIR)
    return _surface_mgr


@app.get("/api/surfaces")
async def list_surfaces(room_id: Optional[str] = None):
    mgr = _get_surfaces()
    surfaces = await mgr.list_surfaces(room_id=room_id)
    return {"surfaces": [s.dict() for s in surfaces]}


@app.post("/api/surfaces")
async def create_surface(payload: Dict[str, Any]):
    mgr = _get_surfaces()
    try:
        surface = await mgr.create_surface(
            room_id=str(payload.get("room_id", "default")),
            label=str(payload.get("label", "Surface")),
            kind=str(payload.get("kind", "custom")),
            quad=payload.get("quad", [[0,0,0],[1,0,0],[1,1,0],[0,1,0]]),
            creator_id=payload.get("creator_id"),
            media_mode=str(payload.get("media_mode", "video")),
            locked=bool(payload.get("locked", False)),
            expires_at=payload.get("expires_at"),
            metadata=payload.get("metadata"),
        )
        # Only broadcast when the hub is available
        if hub is not None:
            try:
                await hub.broadcast_system_event({"type": "surface_created", "payload": surface.dict()})
            except Exception:
                logger.warning("Failed to broadcast surface_created event")
        return surface.dict()
    except Exception as exc:
        return JSONResponse({"error": str(exc)}, status_code=400)


@app.get("/api/surfaces/{surface_id}")
async def get_surface(surface_id: str):
    mgr = _get_surfaces()
    s = await mgr.get_surface(surface_id)
    if not s:
        return JSONResponse({"error": "Not found"}, status_code=404)
    return s.dict()


@app.post("/api/surfaces/{surface_id}/bind")
async def bind_surface_stream(surface_id: str, payload: Dict[str, Any]):
    mgr = _get_surfaces()
    try:
        surface = await mgr.bind_stream(
            surface_id,
            stream_id=payload.get("stream_id"),
            stream_uri=payload.get("stream_uri"),
            metadata=payload.get("metadata"),
        )
        # Broadcast only if hub is available
        if hub is not None:
            try:
                await hub.broadcast_system_event({"type": "surface_bound", "payload": surface.dict()})
            except Exception:
                logger.warning("Failed to broadcast surface_bound event")
        return surface.dict()
    except KeyError:
        return JSONResponse({"error": "Surface not found"}, status_code=404)


@app.patch("/api/surfaces/{surface_id}")
async def update_surface_state(surface_id: str, payload: Dict[str, Any]):
    mgr = _get_surfaces()
    try:
        surface = await mgr.update_surface_state(surface_id, changes=payload)
        # Broadcast only if hub is available
        if hub is not None:
            try:
                await hub.broadcast_system_event({"type": "surface_updated", "payload": surface.dict()})
            except Exception:
                logger.warning("Failed to broadcast surface_updated event")
        return surface.dict()
    except (KeyError, ValueError) as exc:
        return JSONResponse({"error": str(exc)}, status_code=400)


@app.delete("/api/surfaces/{surface_id}")
async def delete_surface(surface_id: str):
    mgr = _get_surfaces()
    await mgr.delete_surface(surface_id)
    # Broadcast the deletion only when the hub is available
    if hub is not None:
        try:
            await hub.broadcast_system_event({"type": "surface_deleted", "payload": {"surface_id": surface_id}})
        except Exception:
            logger.warning("Failed to broadcast surface_deleted event")
    return {"ok": True}


# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# CHOREOGRAPHY CONTROLLER (server-side avatar animation tick)
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

_choreo_ctrl: Optional[Any] = None

def _get_choreo():
    global _choreo_ctrl
    if _choreo_ctrl is None:
        from modules.choreography_controller import ChoreoController
        _choreo_ctrl = ChoreoController(hub, tick_hz=30.0)
    return _choreo_ctrl


@app.get("/api/choreo/status")
async def choreo_status():
    return _get_choreo().status()


@app.post("/api/choreo/start")
async def choreo_start(payload: Dict[str, Any]):
    ctrl = _get_choreo()
    result = await ctrl.start(
        room=str(payload.get("room", "studio")),
        avatars=payload.get("avatars"),
        steps=payload.get("steps", []),
        tick_hz=payload.get("tick_hz"),
    )
    return result


@app.post("/api/choreo/stop")
async def choreo_stop():
    await _get_choreo().stop()
    return {"ok": True}


# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# PROJECTS (autosave & restore for builder sessions)
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

@app.get("/api/projects/{slug}/autosaves")
async def list_project_autosaves(slug: str):
    from modules.projects import list_autosaves
    return {"autosaves": list_autosaves(DATA_DIR, slug)}


@app.post("/api/projects/{slug}/autosave")
async def project_autosave(slug: str, payload: Dict[str, Any]):
    from modules.projects import save_autosave_snapshot
    path = await save_autosave_snapshot(DATA_DIR, slug, payload)
    return {"ok": True, "path": str(path)}


@app.get("/api/projects/{slug}/autosave/latest")
async def project_latest_autosave(slug: str):
    from modules.projects import latest_autosave_path
    from modules.persistence import read_json
    path = latest_autosave_path(DATA_DIR, slug)
    if not path or not path.exists():
        return JSONResponse({"error": "No autosave found"}, status_code=404)
    data = read_json(path)
    return {"data": data, "path": str(path)}


# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# INFERENCE MANAGER (LLM / STT / TTS worker process)
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

_inference: Optional[Any] = None

def _get_inference():
    global _inference
    if _inference is None:
        from modules.inference import InferenceManager
        _inference = InferenceManager()
    return _inference


@app.get("/api/inference/status")
async def inference_status():
    return _get_inference().status()


@app.post("/api/inference/generate")
async def inference_generate(payload: Dict[str, Any]):
    mgr = _get_inference()
    if not mgr.status()["worker_alive"]:
        await mgr.startup()
    try:
        result = await mgr.generate_text(
            str(payload.get("prompt", "")),
            temperature=float(payload.get("temperature", 0.7)),
            max_tokens=int(payload.get("max_tokens", 256)),
        )
        return result
    except Exception as exc:
        return JSONResponse({"error": str(exc)}, status_code=500)


@app.post("/api/inference/tts")
async def inference_tts(payload: Dict[str, Any]):
    mgr = _get_inference()
    if not mgr.status()["worker_alive"]:
        await mgr.startup()
    try:
        result = await mgr.synthesize_speech(
            str(payload.get("text", "")),
            voice=str(payload.get("voice", "default")),
        )
        return result
    except Exception as exc:
        return JSONResponse({"error": str(exc)}, status_code=500)


# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# DISTRIBUTED ENGINE STATUS
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

@app.get("/api/engine/status")
async def engine_status():
    """Health and mode of distributed engine nodes."""
    from modules.irm import IRMController
    ctrl = IRMController()
    report = ctrl.check()
    bridge_stat = "unavailable"
    try:
        b = _get_bridge()
        bridge_stat = b._status.value
    except Exception:
        pass
    return {
        "engine":    "distributed_v1",
        "health":    report.to_dict(),
        "bridge":    bridge_stat,
    }


# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# AVATAR ASSETS (GLB manifest)
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

# ══════════════════════════════════════════════════════════════════════════════
# UNITY BRIDGE — WebSocket + REST endpoints
# ══════════════════════════════════════════════════════════════════════════════

@app.get("/api/unity/status")
async def unity_status():
    """Unity bridge connection status and WorldBrain state snapshot."""
    if unity_bridge_mgr is None:
        return JSONResponse({"error": "Unity bridge not initialised"}, status_code=503)
    status = unity_bridge_mgr.status()
    snapshot = await unity_bridge_mgr._world_brain.snapshot()
    return {"bridge": status, "world_brain": snapshot}


@app.get("/api/unity/world-brain")
async def unity_world_brain():
    """Full WorldBrain state snapshot."""
    if unity_bridge_mgr is None:
        return JSONResponse({"error": "Unity bridge not initialised"}, status_code=503)
    return {"state": await unity_bridge_mgr._world_brain.snapshot()}


@app.post("/api/unity/event")
async def unity_inject_event(payload: Dict[str, Any]):
    """Inject a PubCast event and forward it to all Unity clients. Useful for testing."""
    if unity_bridge_mgr is None:
        return JSONResponse({"error": "Unity bridge not initialised"}, status_code=503)
    event = {"type": str(payload.get("type", "custom")), **payload}
    await unity_bridge_mgr.on_pubcast_event(event)
    return {"ok": True, "event": event}


@app.get("/api/avatars/assets")
async def list_avatar_assets():
    from modules.avatar_assets import load_manifest, refresh_manifest_cache
    manifest = load_manifest(DATA_DIR)
    return {"packs": [p.dict() for p in manifest.packs]}


@app.post("/api/avatars/assets/refresh")
async def refresh_avatar_assets():
    from modules.avatar_assets import refresh_manifest_cache
    refresh_manifest_cache()
    return {"ok": True}


# ══════════════════════════════════════════════════════════════════════════════
# BYOK PAGE
# ══════════════════════════════════════════════════════════════════════════════

@app.get("/launch", response_class=HTMLResponse)
async def launch_page(request: Request):
    """The ON button — system health dashboard and broadcast launcher."""
    return templates.TemplateResponse("launch.html", {"request": request})


@app.get("/byok", response_class=HTMLResponse)
async def byok_page(request: Request):
    """Serve the BYOK key-management UI."""
    return templates.TemplateResponse("byok.html", {"request": request})


# ══════════════════════════════════════════════════════════════════════════════
# STUDIO CONTROL ROOM — page + WebSocket
# ══════════════════════════════════════════════════════════════════════════════

@app.get("/studio", response_class=HTMLResponse)
async def studio_page(request: Request):
    """Serve the Studio Control Room UI."""
    return templates.TemplateResponse("studio_control_room.html", {"request": request})


@app.get("/bots", response_class=HTMLResponse)
async def bots_page(request: Request):
    """AI co-host management panel."""
    return templates.TemplateResponse("bots.html", {"request": request})


@app.get("/mocap", response_class=HTMLResponse)
async def mocap_page(request: Request):
    """Motion capture control panel."""
    return templates.TemplateResponse("mocap.html", {"request": request})


@app.get("/voxels", response_class=HTMLResponse)
async def voxels_page(request: Request):
    """VoxelStudio browser and scene control."""
    return templates.TemplateResponse("voxels.html", {"request": request})



@app.get("/api/studio/status")
async def studio_status():
    """Current Studio Control Room state."""
    if studio_ctrl is None:
        return JSONResponse({"error": "Studio not initialised"}, status_code=503)
    return {
        "state":       studio_ctrl.state.value,
        "audio_matrix": studio_ctrl.audio_matrix.to_dict()
                        if hasattr(studio_ctrl.audio_matrix, "to_dict")
                        else str(studio_ctrl.audio_matrix),
    }


@app.post("/api/studio/preflight")
async def studio_preflight():
    """Run the 5-second preflight countdown."""
    if studio_ctrl is None:
        return JSONResponse({"error": "Studio not initialised"}, status_code=503)
    ok = await studio_ctrl.run_preflight_sequence()
    return {"ok": ok, "state": studio_ctrl.state.value}


# ══════════════════════════════════════════════════════════════════════════════
# AVATAR PERFORMER (Rust animation bridge)
# ══════════════════════════════════════════════════════════════════════════════

@app.get("/api/performer/status")
async def performer_status():
    """Connection status of the Rust animation bridge."""
    if performer_mgr is None:
        return {"running": False, "reason": "not_initialised"}
    return {
        "running":    performer_mgr._running,
        "performers": list(performer_mgr._performers.keys()),
        "count":      len(performer_mgr._performers),
    }


@app.post("/api/performer/avatars/{avatar_id}")
async def performer_create(avatar_id: str, payload: Dict[str, Any]):
    """Create an avatar performer instance bound to the Rust crate."""
    if performer_mgr is None or not performer_mgr._running:
        return JSONResponse(
            {"error": "Rust animation bridge not connected — compile and run the Rust crate first"},
            status_code=503,
        )
    preset = str(payload.get("preset", "MANNY"))
    performer = performer_mgr.create_performer(avatar_id, preset=preset)
    return {"ok": True, "avatar_id": avatar_id, "preset": preset}


@app.delete("/api/performer/avatars/{avatar_id}")
async def performer_remove(avatar_id: str):
    """Remove an avatar performer instance."""
    if performer_mgr is None:
        return JSONResponse({"error": "not initialised"}, status_code=503)
    performer_mgr.remove_performer(avatar_id)
    return {"ok": True}


# ══════════════════════════════════════════════════════════════════════════════
# MOCAP STREAM MANAGER
# ══════════════════════════════════════════════════════════════════════════════

class _MocapStartRequest(BaseModel):
    source_url: str       # e.g. "udp://127.0.0.1:9001" or "ws://localhost:8080/mocap"
    avatar_id: str        # which avatar skeleton receives the data
    preset: str = "MANNY" # AvatarBinding preset used if performer doesn't exist yet

class _MocapAvatarRequest(BaseModel):
    preset: str = "MANNY"


@app.get("/api/mocap/status")
async def mocap_status():
    """Return mocap stream status, metrics, and active avatar."""
    if mocap_mgr is None:
        return JSONResponse({"error": "Mocap manager not initialised"}, status_code=503)
    return mocap_mgr.get_status()


@app.post("/api/mocap/start")
async def mocap_start(req: _MocapStartRequest):
    """
    Start a mocap stream from the given source URL.
    Also sets the target avatar — creating a performer if needed.

    Supported URLs:
      - udp://127.0.0.1:9001
      - ws://hostname:port/path
      - wss://hostname:port/path
    """
    if mocap_mgr is None:
        return JSONResponse({"error": "Mocap manager not initialised"}, status_code=503)

    # Bind avatar first so the first frame isn't dropped
    mocap_mgr.set_active_avatar(req.avatar_id, preset=req.preset)

    ok = await mocap_mgr.start_stream(req.source_url)
    if not ok:
        return JSONResponse(
            {"error": "Failed to start mocap stream — check source URL and logs"},
            status_code=400,
        )
    return {"ok": True, "source": req.source_url, "avatar_id": req.avatar_id}


@app.post("/api/mocap/stop")
async def mocap_stop():
    """Stop the active mocap stream."""
    if mocap_mgr is None:
        return JSONResponse({"error": "Mocap manager not initialised"}, status_code=503)
    await mocap_mgr.stop_stream()
    return {"ok": True}


@app.put("/api/mocap/avatar/{avatar_id}")
async def mocap_set_avatar(avatar_id: str, req: _MocapAvatarRequest):
    """
    Reassign mocap data to a different avatar mid-stream.
    Creates a performer for the new avatar if one doesn't exist.
    """
    if mocap_mgr is None:
        return JSONResponse({"error": "Mocap manager not initialised"}, status_code=503)
    mocap_mgr.set_active_avatar(avatar_id, preset=req.preset)
    return {"ok": True, "avatar_id": avatar_id}



# ══════════════════════════════════════════════════════════════════════════════
# VOXEL STUDIO
# ══════════════════════════════════════════════════════════════════════════════

class _VSPlaceRequest(BaseModel):
    object_id:       str
    world_position:  List[float] = [0.0, 0.0, 0.0]
    world_rotation:  List[float] = [0.0, 0.0, 0.0]
    is_destructible: bool        = False
    tags:            List[str]   = []

class _VSSlateRequest(BaseModel):
    director: str
    take:     int  = 1
    notes:    str  = ""

class _VSDetonateRequest(BaseModel):
    blast_origin:  Optional[List[float]] = None
    seed_override: Optional[int]         = None


@app.get("/api/vs/status")
async def vs_status():
    if voxel_studio is None:
        return JSONResponse({"error": "VoxelStudio not initialised"}, status_code=503)
    return voxel_studio.status()


@app.get("/api/vs/primitives")
async def vs_primitives():
    if voxel_studio is None:
        return JSONResponse({"error": "VoxelStudio not initialised"}, status_code=503)
    return {"primitives": voxel_studio.list_primitives()}


@app.get("/api/vs/lod/{lod_level}")
async def vs_lod_palette(lod_level: str):
    if voxel_studio is None:
        return JSONResponse({"error": "VoxelStudio not initialised"}, status_code=503)
    try:
        lod = LODLevel(lod_level)
    except ValueError:
        return JSONResponse({"error": f"Unknown LOD level: {lod_level}"}, status_code=400)
    return {"lod": lod_level, "palette": voxel_studio.get_lod_palette(lod)}


@app.get("/api/vs/objects")
async def vs_list_objects():
    if voxel_studio is None:
        return JSONResponse({"error": "VoxelStudio not initialised"}, status_code=503)
    return {"objects": [o.to_dict() for o in voxel_studio.list_objects()]}


@app.post("/api/vs/objects")
async def vs_save_object(request: Request):
    if voxel_studio is None:
        return JSONResponse({"error": "VoxelStudio not initialised"}, status_code=503)
    data = await request.json()
    obj  = VoxelObject.from_dict(data)
    path = voxel_studio.save_object(obj)
    return {"ok": True, "object_id": obj.object_id, "path": str(path)}


@app.post("/api/vs/objects/{object_id}/bake")
async def vs_bake_object(object_id: str):
    if voxel_studio is None:
        return JSONResponse({"error": "VoxelStudio not initialised"}, status_code=503)
    path = voxel_studio.bake_object(object_id)
    if path is None:
        return JSONResponse({"error": "Object not found or bake failed"}, status_code=404)
    return {"ok": True, "glb_path": str(path), "file_bytes": path.stat().st_size}


@app.delete("/api/vs/objects/{object_id}")
async def vs_delete_object(object_id: str):
    if voxel_studio is None:
        return JSONResponse({"error": "VoxelStudio not initialised"}, status_code=503)
    ok = voxel_studio.delete_object(object_id)
    if not ok:
        return JSONResponse({"error": "Object not found"}, status_code=404)
    return {"ok": True}


@app.post("/api/vs/scene")
async def vs_create_scene(name: str):
    if voxel_studio is None:
        return JSONResponse({"error": "VoxelStudio not initialised"}, status_code=503)
    session = voxel_studio.create_scene(name)
    return {"scene_id": session.scene_id, "scene_name": session.scene_name}


@app.post("/api/vs/scene/place")
async def vs_place_object(req: _VSPlaceRequest):
    if voxel_studio is None:
        return JSONResponse({"error": "VoxelStudio not initialised"}, status_code=503)
    inst = voxel_studio.place_object(
        object_id       = req.object_id,
        world_position  = tuple(req.world_position),  # type: ignore
        world_rotation  = tuple(req.world_rotation),  # type: ignore
        is_destructible = req.is_destructible,
        tags            = req.tags,
    )
    if inst is None:
        return JSONResponse({"error": "Failed to place object"}, status_code=400)
    return {"ok": True, "instance_id": inst.instance_id}


@app.post("/api/vs/scene/slate")
async def vs_slate(req: _VSSlateRequest):
    if voxel_studio is None:
        return JSONResponse({"error": "VoxelStudio not initialised"}, status_code=503)
    try:
        slate = voxel_studio.slate(director=req.director, take=req.take, notes=req.notes)
        return slate.to_dict()
    except RuntimeError as e:
        return JSONResponse({"error": str(e)}, status_code=400)


@app.post("/api/vs/scene/action")
async def vs_action():
    if voxel_studio is None:
        return JSONResponse({"error": "VoxelStudio not initialised"}, status_code=503)
    try:
        t = voxel_studio.action()
        return {"ok": True, "action_time": t}
    except RuntimeError as e:
        return JSONResponse({"error": str(e)}, status_code=400)


@app.post("/api/vs/scene/cut")
async def vs_cut():
    if voxel_studio is None:
        return JSONResponse({"error": "VoxelStudio not initialised"}, status_code=503)
    try:
        return voxel_studio.cut()
    except RuntimeError as e:
        return JSONResponse({"error": str(e)}, status_code=400)


@app.post("/api/vs/scene/reset")
async def vs_reset():
    if voxel_studio is None:
        return JSONResponse({"error": "VoxelStudio not initialised"}, status_code=503)
    try:
        voxel_studio.reset_to_take_1()
        return {"ok": True, "message": "Reset to Take 1"}
    except RuntimeError as e:
        return JSONResponse({"error": str(e)}, status_code=400)


@app.post("/api/vs/scene/detonate/{instance_id}")
async def vs_detonate(instance_id: str, req: _VSDetonateRequest):
    if voxel_studio is None:
        return JSONResponse({"error": "VoxelStudio not initialised"}, status_code=503)
    try:
        origin = tuple(req.blast_origin) if req.blast_origin else None  # type: ignore
        fragments = voxel_studio.detonate(
            instance_id  = instance_id,
            blast_origin = origin,
            seed_override= req.seed_override,
        )
        if hub:
            await hub.broadcast_system_event({
                "type":    "voxel_detonation",
                "payload": {"instance_id": instance_id, "fragments": fragments},
            })
        return {"ok": True, "fragment_count": len(fragments)}
    except (ValueError, RuntimeError) as e:
        return JSONResponse({"error": str(e)}, status_code=400)


# ══════════════════════════════════════════════════════════════════════════════
# PETE — PRODUCTION ENGINE
# ══════════════════════════════════════════════════════════════════════════════

class _PeteAssetRequest(BaseModel):
    instance_id:   str
    asset_name:    str
    asset_tier:    str
    triangles:     float = 0
    draw_calls:    float = 0
    texture_mb:    float = 0
    physics_count: float = 0
    materials:     float = 0

class _PeteMarkerRequest(BaseModel):
    name:      str
    position:  List[float]
    tolerance: float = 0.5
    normal:    Optional[List[float]] = None

class _PeteCueRequest(BaseModel):
    name:           str
    cue_type:       str
    action:         str
    scene_time_s:   Optional[float] = None
    character_id:   Optional[str]   = None
    marker_id:      Optional[str]   = None
    sound_name:     Optional[str]   = None
    count:          int             = 1
    chain_cue_id:   Optional[str]   = None
    delay_s:        float           = 0.0
    guard_after_s:  float           = 0.0
    camera_id:      Optional[str]   = None
    instance_id:    Optional[str]   = None

class _PeteReadinessRequest(BaseModel):
    avatar_count:     int = 0
    destructibles:    int = 0
    particle_systems: int = 0
    partial_textures: int = 0

class _PeteChunkRequest(BaseModel):
    chunk_size_s: Optional[float] = None

class _PeteAudioRequest(BaseModel):
    sound_name: str


@app.get("/api/pete/status")
async def pete_status():
    if pete is None:
        return JSONResponse({"error": "Pete not initialised"}, status_code=503)
    return await pete.status()


@app.post("/api/pete/asset")
async def pete_register_asset(req: _PeteAssetRequest):
    if pete is None:
        return JSONResponse({"error": "Pete not initialised"}, status_code=503)
    violations = pete.register_asset(
        instance_id   = req.instance_id,
        asset_name    = req.asset_name,
        asset_tier    = req.asset_tier,
        triangles     = req.triangles,
        draw_calls    = req.draw_calls,
        texture_mb    = req.texture_mb,
        physics_count = req.physics_count,
        materials     = req.materials,
    )
    return {"ok": True, "violations": violations, "clean": len(violations) == 0}


@app.delete("/api/pete/asset/{instance_id}")
async def pete_unregister_asset(instance_id: str):
    if pete is None:
        return JSONResponse({"error": "Pete not initialised"}, status_code=503)
    pete.unregister_asset(instance_id)
    return {"ok": True}


@app.post("/api/pete/marker")
async def pete_place_marker(req: _PeteMarkerRequest):
    if pete is None:
        return JSONResponse({"error": "Pete not initialised"}, status_code=503)
    marker = PeteSceneMarker(
        name      = req.name,
        position  = tuple(req.position),  # type: ignore
        tolerance = req.tolerance,
        normal    = tuple(req.normal) if req.normal else None,  # type: ignore
    )
    pete.place_marker(marker)
    return {"ok": True, "marker_id": marker.marker_id, "name": marker.name}


@app.get("/api/pete/markers")
async def pete_list_markers():
    if pete is None:
        return JSONResponse({"error": "Pete not initialised"}, status_code=503)
    return {"markers": [m.to_dict() for m in pete.list_markers()]}


@app.post("/api/pete/cue")
async def pete_add_cue(req: _PeteCueRequest):
    if pete is None:
        return JSONResponse({"error": "Pete not initialised"}, status_code=503)
    try:
        cue = PeteAutoCutCue(
            name          = req.name,
            cue_type      = CueType(req.cue_type),
            action        = CueAction(req.action),
            scene_time_s  = req.scene_time_s,
            character_id  = req.character_id,
            marker_id     = req.marker_id,
            sound_name    = req.sound_name,
            count         = req.count,
            chain_cue_id  = req.chain_cue_id,
            delay_s       = req.delay_s,
            guard_after_s = req.guard_after_s,
            camera_id     = req.camera_id,
            instance_id   = req.instance_id,
        )
        pete.add_cue(cue)
        return {"ok": True, "cue_id": cue.cue_id}
    except ValueError as e:
        return JSONResponse({"error": str(e)}, status_code=400)


@app.get("/api/pete/cues")
async def pete_list_cues():
    if pete is None:
        return JSONResponse({"error": "Pete not initialised"}, status_code=503)
    return {"cues": [c.to_dict() for c in pete.list_cues()]}


@app.delete("/api/pete/cues")
async def pete_clear_cues():
    if pete is None:
        return JSONResponse({"error": "Pete not initialised"}, status_code=503)
    pete.clear_cues()
    return {"ok": True}


@app.post("/api/pete/readiness")
async def pete_readiness(req: _PeteReadinessRequest):
    if pete is None:
        return JSONResponse({"error": "Pete not initialised"}, status_code=503)
    report = await pete.action_readiness(
        avatar_count     = req.avatar_count,
        destructibles    = req.destructibles,
        particle_systems = req.particle_systems,
        partial_textures = req.partial_textures,
    )
    return report.to_dict()


@app.post("/api/pete/action")
async def pete_on_action():
    if pete is None:
        return JSONResponse({"error": "Pete not initialised"}, status_code=503)
    await pete.on_action()
    return {"ok": True}


@app.post("/api/pete/cut")
async def pete_on_cut():
    if pete is None:
        return JSONResponse({"error": "Pete not initialised"}, status_code=503)
    report = await pete.on_cut()
    return report


@app.post("/api/pete/chunk")
async def pete_set_chunk(req: _PeteChunkRequest):
    if pete is None:
        return JSONResponse({"error": "Pete not initialised"}, status_code=503)
    pete.set_chunk_size(req.chunk_size_s)
    return {"ok": True, "chunk_size_s": req.chunk_size_s}


@app.post("/api/pete/frame_drop")
async def pete_frame_drop():
    """Called by the renderer when a frame is dropped."""
    if pete is None:
        return JSONResponse({"error": "Pete not initialised"}, status_code=503)
    pete.record_frame_drop()
    return {"ok": True}


@app.post("/api/pete/audio_event")
async def pete_audio_event(req: _PeteAudioRequest):
    """Feed a named audio trigger event to Pete's cue system."""
    if pete is None:
        return JSONResponse({"error": "Pete not initialised"}, status_code=503)
    pete.notify_audio_event(req.sound_name)
    return {"ok": True}


@app.post("/api/pete/sound_complete")
async def pete_sound_complete(req: _PeteAudioRequest):
    """Feed a sound completion event to Pete's cue system."""
    if pete is None:
        return JSONResponse({"error": "Pete not initialised"}, status_code=503)
    pete.notify_sound_complete(req.sound_name)
    return {"ok": True}


@app.get("/api/pete/blackbox")
async def pete_blackbox(last_n: Optional[int] = None, event_type: Optional[str] = None):
    if pete is None:
        return JSONResponse({"error": "Pete not initialised"}, status_code=503)
    return {"entries": pete.get_black_box(last_n=last_n, event_type=event_type)}



# ══════════════════════════════════════════════════════════════════════════════
# VOXEL ASSET MANAGER
# ══════════════════════════════════════════════════════════════════════════════

@app.get("/api/voxel/assets")
async def voxel_list_assets():
    """List all assets in the voxel asset library."""
    if voxel_asset_mgr is None:
        return JSONResponse({"error": "Voxel asset manager not initialised"}, status_code=503)
    assets = list(voxel_asset_mgr._assets.values())
    return {"assets": [a.__dict__ for a in assets], "count": len(assets)}


@app.get("/api/voxel/scenes")
async def voxel_list_scenes():
    """List all voxel scenes in the asset manager."""
    if voxel_asset_mgr is None:
        return JSONResponse({"error": "Voxel asset manager not initialised"}, status_code=503)
    scenes = list(voxel_asset_mgr._scenes.values())
    return {"scenes": [s.__dict__ for s in scenes], "count": len(scenes)}

