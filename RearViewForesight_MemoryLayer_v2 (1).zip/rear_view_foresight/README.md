# Rear View Foresight — Memory Layer
**Feic Mo Chroí™**

## Install

```
python3 install.py
```

That's it. One command. Everything wires itself in.

---

## What Gets Installed

**Part 1 — thinking_context**
PubCast AI memory layer. Characters remember. Jeremy watches rooms.
Mount in any FastAPI app in 5 lines.

**Part 2 — memory_layer**
Claude persistent session memory. Open a new Claude tab — it already
knows what you were building. You do nothing.

---

## After Install

Reload your browser extension:
`chrome://extensions` → Code Collector → reload button

Then open a new Claude tab. That's all you ever do.
