# Claude Persistent Memory — Drop-in for Code Collector

**Date:** 2026-03-15  
**Status:** Ready to integrate  
**Rear View Foresight LLC — Feic Mo Chroí**

---

## What This Does

Close a Claude session. Open a new one. It already knows what you were building.

Not because Claude remembered. Because your system does.

---

## Files

```
extractors/
  conversation.py         ← Core extractor. Turns → decisions, builds, breaks, next steps.
  conversation_server.py  ← Subprocess wrapper. Called by main.js via execFile.

extension/
  claude_scraper.js       ← Content script for claude.ai. Scrapes turns, shows context banner.
  background_session_patch.js  ← Additions to background.js. Relays captures, fetches context.
  session_endpoints.js    ← Additions to main.js. Three new routes.
```

---

## How It Works

```
Claude tab open (new conversation)
  → background.js detects /chat/new
  → GET /context/session?platform=claude
  → server returns last session context
  → claude_scraper.js shows banner: "Prior session context available"
  → user clicks "Paste into chat"
  → context injected into input
  → Claude already knows what you were building

During conversation (every 5 turns)
  → claude_scraper.js scrapes turns
  → sends CONVERSATION_CAPTURE to background.js
  → background relays to POST /collect-conversation
  → server runs conversation_server.py
  → extracts: files touched, decisions, builds, breaks, next steps
  → stores in session index

Tab close / navigate away
  → sendBeacon fires POST /collect-conversation with final state
  → same extraction pipeline
  → index updated
```

---

## Integration Steps

### 1. Drop in the extractor files
Copy `extractors/` into your project root (or wherever `collector_bridge.py` lives).

### 2. Add to main.js
Paste the three blocks from `session_endpoints.js` into your `main.js`:
- The `_sessionIndex` and `_latestByPlatform` state (module scope)
- The three route handlers into your request router
- The `_runConversationExtractor` helper (module scope)

### 3. Add to background.js
Paste the two cases from `background_session_patch.js` into your `onMessage` listener:
```js
if (message.type === "CONVERSATION_CAPTURE") {
  _relayConversationCapture(message).then(sendResponse);
  return true;
}
if (message.type === "FETCH_LAST_SESSION") {
  _fetchLastSession(message.platform).then(sendResponse);
  return true;
}
```
And call `_watchClaudeTabs()` once at startup.

### 4. Add claude_scraper.js to the extension manifest
In `manifest.json`, add to `content_scripts`:
```json
{
  "matches": ["https://claude.ai/*"],
  "js": ["claude_scraper.js"],
  "run_at": "document_idle"
}
```

### 5. Also handle SHOW_PRIOR_CONTEXT in claude_scraper.js
The tab watcher in background.js sends this message. Add to the message listener
in `claude_scraper.js`:
```js
if (message.type === "SHOW_PRIOR_CONTEXT") {
  _showContextBanner(message.context);
}
```

---

## What Gets Captured Per Session

- **Files touched** — any filename mentioned in the conversation
- **Decisions made** — sentences with decision markers ("the fix is", "use X instead", "done")
- **What was built** — sentences with build markers ("built", "created", "implemented")
- **Broken / open** — sentences with break markers ("broken", "still need", "next step")
- **Next steps** — numbered or "Next:" sentences from assistant turns

---

## Tier 2 Upgrade Path

Replace `_sessionIndex` (in-memory Map) with SQLite writes.
`session_endpoints.js` is written to make this a one-line swap per handler.
The extractor pipeline stays identical.

---

## Test the extractor directly

```bash
echo '{"session_id":"test","platform":"claude","source_url":"https://claude.ai/chat/x","source_title":"Claude","turns":[{"role":"user","content":"how do i fix bots.py","ts":1000},{"role":"assistant","content":"The import is wrong. Use JeremyCricket instead. Fix is done.","ts":1001}]}' \
  | python3 extractors/conversation_server.py
```
