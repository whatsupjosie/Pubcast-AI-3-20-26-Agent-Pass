/**
 * claude_scraper.js
 * ══════════════════
 * Content script for Claude (claude.ai).
 *
 * Two jobs:
 *   1. CAPTURE — scrape conversation turns on demand and send to /collect
 *   2. INJECT  — on new conversation start, fetch last session context
 *                from the local server and surface it to the user
 *
 * Communicates with background.js via chrome.runtime.sendMessage.
 * Background.js handles all HTTP to the local Electron server.
 *
 * CAPTURE trigger:
 *   - User clicks extension icon → background sends CAPTURE_SESSION message
 *   - On conversation end (tab close / navigate away)
 *
 * INJECT trigger:
 *   - New conversation detected (URL is /chat/new or fresh load with no turns)
 *   - Background fetches GET /context/session from server
 *   - If context exists, we surface it as a dismissible banner
 *
 * Rear View Foresight LLC — Feic Mo Chroí
 */

"use strict";

// ── Constants ─────────────────────────────────────────────────────────────────

const PLATFORM        = "claude";
const CLAUDE_ORIGIN   = "https://claude.ai";
const NEW_CHAT_PATHS  = ["/chat/new", "/new", "/"];

// Claude DOM selectors — update if Claude changes their markup
const SELECTORS = {
  // Each message bubble
  turn:          '[data-testid="user-message"], [data-testid="assistant-message"]',
  userTurn:      '[data-testid="user-message"]',
  assistantTurn: '[data-testid="assistant-message"]',
  // Text content inside a turn
  turnContent:   '.whitespace-pre-wrap, [class*="prose"]',
  // The main input box
  input:         '[data-testid="composer-input"], div[contenteditable="true"]',
  // Send button
  sendButton:    '[data-testid="send-button"]',
};

// ── State ─────────────────────────────────────────────────────────────────────

let _sessionId      = null;
let _injected       = false;
let _lastTurnCount  = 0;
let _observer       = null;

// ── Entry point ───────────────────────────────────────────────────────────────

(function init() {
  _sessionId = _extractSessionId(location.href);
  _detectAndInject();
  _observeTurns();
  _listenForMessages();
})();

// ── Capture ───────────────────────────────────────────────────────────────────

/**
 * Scrape all visible turns and send to background for relay to /collect.
 */
function captureSession() {
  const turns = _scrapeTurns();
  if (!turns.length) {
    console.debug("[code-collector] captureSession: no turns found");
    return;
  }

  chrome.runtime.sendMessage({
    type:         "CONVERSATION_CAPTURE",
    platform:     PLATFORM,
    session_id:   _sessionId,
    source_url:   location.href,
    source_title: document.title || "Claude",
    turns:        turns,
  });

  console.debug(`[code-collector] captureSession: sent ${turns.length} turns`);
}

/**
 * Scrape all turns from the DOM.
 * Returns array of { role, content, ts } objects.
 */
function _scrapeTurns() {
  const nodes = document.querySelectorAll(SELECTORS.turn);
  const turns = [];

  nodes.forEach((node) => {
    const role = node.matches(SELECTORS.userTurn) ? "user" : "assistant";
    const contentNode = node.querySelector(SELECTORS.turnContent) || node;
    const content = contentNode.innerText?.trim() || "";

    if (!content || content.length < 3) return;

    turns.push({
      role,
      content,
      ts: Date.now() / 1000,
    });
  });

  return turns;
}

// ── Inject ────────────────────────────────────────────────────────────────────

/**
 * Detect if this is a fresh conversation. If so, fetch prior context
 * from the local server and surface it.
 */
function _detectAndInject() {
  if (_injected) return;

  const isNew = _isNewConversation();
  if (!isNew) return;

  // Ask background to fetch last session context
  chrome.runtime.sendMessage(
    { type: "FETCH_LAST_SESSION", platform: PLATFORM },
    (response) => {
      if (chrome.runtime.lastError) return;
      if (!response || !response.context) return;
      _showContextBanner(response.context);
    }
  );
}

/**
 * Returns true if this looks like a new/empty conversation.
 */
function _isNewConversation() {
  // Check URL
  if (NEW_CHAT_PATHS.some((p) => location.pathname === p)) return true;
  // Check turn count — if there are no turns yet, it's fresh
  const turns = document.querySelectorAll(SELECTORS.turn);
  return turns.length === 0;
}

/**
 * Surface prior session context as a dismissible banner above the input.
 * Does not modify the conversation or auto-type anything.
 * User can click "Continue" to paste context into the input, or dismiss.
 */
function _showContextBanner(context) {
  if (_injected) return;
  _injected = true;

  const banner = document.createElement("div");
  banner.id = "cc-context-banner";
  banner.style.cssText = `
    position: fixed;
    bottom: 90px;
    left: 50%;
    transform: translateX(-50%);
    width: min(680px, 92vw);
    background: #1a1a2e;
    border: 1px solid #4a4a8a;
    border-radius: 12px;
    padding: 16px 20px;
    z-index: 99999;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
    font-size: 13px;
    color: #e0e0ff;
    box-shadow: 0 8px 32px rgba(0,0,0,0.5);
  `;

  // Format context summary for display
  const lines = context.trim().split("\n");
  const preview = lines.slice(0, 8).join("\n");
  const hasMore = lines.length > 8;

  banner.innerHTML = `
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
      <span style="font-weight:600; color:#a0a0ff;">
        📎 Prior session context available
      </span>
      <button id="cc-dismiss" style="
        background:none; border:none; cursor:pointer;
        color:#888; font-size:18px; padding:0; line-height:1;
      ">×</button>
    </div>
    <pre id="cc-preview" style="
      margin:0 0 12px 0; padding:10px 12px;
      background:rgba(255,255,255,0.05);
      border-radius:8px;
      font-size:12px; line-height:1.6;
      white-space:pre-wrap; word-break:break-word;
      max-height:160px; overflow-y:auto;
      color:#c0c0e0;
    ">${_escapeHtml(preview)}${hasMore ? "\n…" : ""}</pre>
    <div style="display:flex; gap:8px;">
      <button id="cc-continue" style="
        flex:1; padding:8px 16px;
        background:#4a4aaa; color:#fff;
        border:none; border-radius:8px;
        cursor:pointer; font-size:13px; font-weight:500;
      ">Paste into chat</button>
      <button id="cc-copy" style="
        padding:8px 16px;
        background:rgba(255,255,255,0.08); color:#c0c0e0;
        border:1px solid rgba(255,255,255,0.15); border-radius:8px;
        cursor:pointer; font-size:13px;
      ">Copy</button>
      <button id="cc-dismiss2" style="
        padding:8px 16px;
        background:none; color:#888;
        border:1px solid rgba(255,255,255,0.1); border-radius:8px;
        cursor:pointer; font-size:13px;
      ">Dismiss</button>
    </div>
  `;

  document.body.appendChild(banner);

  const dismiss = () => banner.remove();

  document.getElementById("cc-dismiss").addEventListener("click", dismiss);
  document.getElementById("cc-dismiss2").addEventListener("click", dismiss);

  document.getElementById("cc-copy").addEventListener("click", () => {
    navigator.clipboard.writeText(context);
    document.getElementById("cc-copy").textContent = "Copied!";
    setTimeout(() => {
      if (document.getElementById("cc-copy")) {
        document.getElementById("cc-copy").textContent = "Copy";
      }
    }, 2000);
  });

  document.getElementById("cc-continue").addEventListener("click", () => {
    _pasteIntoInput(context);
    dismiss();
  });
}

/**
 * Paste context string into Claude's input box.
 * Triggers input events so Claude's React state picks it up.
 */
function _pasteIntoInput(text) {
  const input = document.querySelector(SELECTORS.input);
  if (!input) return;

  input.focus();

  // Use execCommand for contenteditable — most reliable cross-browser
  document.execCommand("selectAll");
  document.execCommand("insertText", false, text);

  // Also fire input event in case React needs it
  input.dispatchEvent(new Event("input", { bubbles: true }));
}

// ── Observer ──────────────────────────────────────────────────────────────────

/**
 * Watch for new turns being added. Auto-capture when conversation grows.
 * This is how we capture without requiring the user to click anything.
 */
function _observeTurns() {
  const target = document.body;

  _observer = new MutationObserver(_debounce(() => {
    const turns = document.querySelectorAll(SELECTORS.turn);
    const count = turns.length;

    if (count > _lastTurnCount) {
      _lastTurnCount = count;
      // Capture on every 5th turn and on conversation end signal
      if (count % 5 === 0) {
        captureSession();
      }
    }
  }, 1000));

  _observer.observe(target, { childList: true, subtree: true });
}

// ── Message listener ──────────────────────────────────────────────────────────

function _listenForMessages() {
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message.type === "CAPTURE_SESSION_NOW") {
      captureSession();
      sendResponse({ ok: true });
    }
    if (message.type === "GET_TURN_COUNT") {
      const count = document.querySelectorAll(SELECTORS.turn).length;
      sendResponse({ count });
    }
  });
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function _extractSessionId(url) {
  // Claude URLs: /chat/{uuid}
  const match = url.match(/\/chat\/([a-zA-Z0-9\-]+)/);
  return match ? match[1] : _randomId();
}

function _randomId() {
  return Math.random().toString(36).slice(2, 14);
}

function _escapeHtml(s) {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function _debounce(fn, ms) {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), ms);
  };
}

// Capture on page unload — gets the final state before navigating away
window.addEventListener("beforeunload", () => {
  const turns = _scrapeTurns();
  if (turns.length > 0) {
    // Use sendBeacon for reliability on unload
    const payload = JSON.stringify({
      type:       "CONVERSATION_CAPTURE",
      platform:   PLATFORM,
      session_id: _sessionId,
      source_url: location.href,
      source_title: document.title || "Claude",
      turns,
    });
    navigator.sendBeacon(
      "http://localhost:8765/collect-conversation",
      new Blob([payload], { type: "application/json" })
    );
  }
});
